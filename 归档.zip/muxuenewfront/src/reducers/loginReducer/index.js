import h_actionTypes from '../../actions/actionTypes/h_actionTypes'
const initState = {
    loginValues: JSON.parse(sessionStorage.getItem("token")) || {
        access_token: '',
        expires_in: '',
        user_info: {
            nick: '',
            name: '',
            phone: '',
            school_name: '',
        },
        scope: ''
    }
}

export default (state = initState, action) => {
    switch(action.type) {
        case h_actionTypes.LOGIN: return {
            ...state,
            loginValues: action.payload.loginValues
        }
        case h_actionTypes.LOGINOUT: return {
            ...state,
            loginValues: {
                access_token: '',
                expires_in: '',
                user_info: {
                    nick: '',
                    name: '',
                    phone: '',
                    school_name: '',
                },
                scope: ''
            }
        }
        default: return state
    }
}