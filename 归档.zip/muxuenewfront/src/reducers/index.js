import { combineReducers } from 'redux'
import loginReducer from './loginReducer'

//导出reducers
export default combineReducers({
    loginReducer
})