import h_actionTypes from './actionTypes/h_actionTypes'
import { viewTestPaper } from '../requests'

// 下载试卷
export const viewTestPaperDispatch = (se_id, page) => {
    return (dispatch) => {
        viewTestPaper(se_id, page)
            .then(resp => {
                console.log(resp)
                if(resp.code === 200) {
                    dispatch({
                        type: h_actionTypes.VIEWTESTPAPER,
                        payload: {
                            
                        }
                    })
                }
            })
    }
}
