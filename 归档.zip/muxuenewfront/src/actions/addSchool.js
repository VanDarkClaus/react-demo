import h_actionTypes from './actionTypes/h_actionTypes'
import { addSchool } from '../requests'

// 下载试卷
export const addSchoolDispatch = (area_id, name) => {
    return (dispatch) => {
        addSchool(area_id, name)
            .then(resp => {
                console.log(resp)
                if(resp.code === 200) {
                    dispatch({
                        type: h_actionTypes.ADDSCHOOL,
                        payload: {
                            
                        }
                    })
                }
            })
    }
}
