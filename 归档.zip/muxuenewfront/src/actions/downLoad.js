import h_actionTypes from './actionTypes/h_actionTypes'
import { downLoadTextPaper } from '../requests'

// 下载试卷
export const downLoadDispatch = (se_id) => {
    return (dispatch) => {
        downLoadTextPaper(se_id)
            .then(resp => {
                console.log(resp)
                if(resp.code === 404) {
                    alert("试卷资源未找到")
                }
                if(resp.code === 200) {
                    dispatch({
                        type: h_actionTypes.DOWNLOADTEXTPAPER,
                        payload: {
                            
                        }
                    })
                }
            })
    }
}
