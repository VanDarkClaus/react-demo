import h_actionTypes from './actionTypes/h_actionTypes'
import { deleteTestPaper } from '../requests'

// 下载试卷
export const deleteTestPaperDispatch = (se_id) => {
    return (dispatch) => {
        deleteTestPaper(se_id)
            .then(resp => {
                console.log(resp)
                if(resp.code === 200) {
                    dispatch({
                        type: h_actionTypes.DELETETEXTPAPER,
                        payload: {
                           
                        }
                    })
                }
            })
    }
}
