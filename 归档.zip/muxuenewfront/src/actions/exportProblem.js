import h_actionTypes from './actionTypes/h_actionTypes'
import { exportProblem } from '../requests'

// 导出错误试卷
export const exportProblemDispatch = (knowledge_point, answer, analysis, expand, selfProposition, se_id, school_id, student_ids, class_id) => {
    return (dispatch) => {
        exportProblem(knowledge_point, answer, analysis, expand, selfProposition, se_id, school_id, student_ids, class_id)
            .then(resp => {
                console.log(resp)
                if(resp.code === 403) {
                    alert("导出错题集发生异常！")
                }
                if(resp.code === 200) {
                    dispatch({
                        type: h_actionTypes.DOWNLOADTEXTPAPER,
                        payload: {
                            
                        }
                    })
                }
            })
    }
}
