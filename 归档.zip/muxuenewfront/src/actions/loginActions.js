import h_actionTypes from './actionTypes/h_actionTypes'
import { loginRequest } from '../requests'
import {message} from 'antd'

//登录
export const loginDispatch = values => dispatch => {
    loginRequest(values)
    .then(res=> {
        if(res.code === 200){
            message.info(res.message)
            sessionStorage.setItem('token',JSON.stringify({
                ...res.body,
                username: values.username
            }))
            dispatch({
                type: h_actionTypes.LOGIN,
                payload: {
                    loginValues: {
                        ...res.body,
                        username: values.username
                    }
                }
            })
        } else {
            message.info(res.message)
        }
    })
}

//登出
export const loginoutDispatch = () => dispatch =>{
    sessionStorage.removeItem('token')
    dispatch({
        type: h_actionTypes.LOGINOUT,
    })
}