import React, { Component } from 'react'
import {withRouter} from 'react-router'
import './testheader.less'



@withRouter
class index extends Component {
    render() {
        return (
            <div className='muxue-testheader'>
                <div className='muxue-testheader-top'>
                    <div>
                        <img src='/images/createTest.png' alt='创建考试' onClick={() =>{
                            this.props.history.push('/admin/dataentry/examinationprocess/createtest')
                        }}/>
                        <div>创建考试</div>
                    </div>
                    <div style={{transform: 'translate(20px)'}}>
                        <img style={{transform: 'translateX(-40px)'}} src='/images/datasync.png' alt='数据采集' onClick={()=>{
                            const arr = window.location.href.split('/')
                            const me_id = arr[arr.length - 1].split('=')[1]
                            if(me_id){
                                this.props.history.push(`/admin/dataentry/examinationprocess/datacollection?me_id=${me_id}`)
                            }
                        }}/> 
                        <div>数据采集</div>
                    </div>
                    <div>
                        <img  src='/images/publishreports.png' alt='发布报告'/> 
                        <div>发布报告</div>
                    </div>
                </div>
                <img src={this.props.img} alt='考试流程two'/>
            </div>
        )
    }
}

export default index
