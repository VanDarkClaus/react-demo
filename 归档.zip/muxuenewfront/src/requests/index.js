import axios from 'axios'
import {message} from 'antd'

const baseURL =  'http://server.mymuxue.com/'
// const baseURL = 'http://192.168.1.60:8084'
let instance = axios.create({
  baseURL,
  headers:{
    "Content-Type": "application/json;charset=UTF-8"
  }
})

instance.interceptors.request.use(config=>{
  if(sessionStorage.getItem("token")){
    config.headers['Authorization']=JSON.parse(sessionStorage.getItem("token")).access_token
  }
  return config
})

instance.interceptors.response.use(res=>{
  //判断token是否过期
  if(res.data.code === 401) {
    message.error(res.data.message)
    sessionStorage.removeItem('token')
    window.location.href="/login"
  }
  return res.data
})

//登录请求
export const loginRequest=({username,password})=>{
  return instance.post("/v2/auth/login", {
    username,
    password,
    grant_type: 'password'
  })
}

//获取知识点类型?XDEBUG_SESSION_START=8084
export const getKnowledge = () => { 
  return instance.post('/v2/user/account-info')
}

// 优质组卷-获取知识点数
export const knowledgeTree = (id) => {
  return instance.get(`/v2/group-roll/knowledge-tree?id=${id}&XDEBUG_SESSION_START=8084`)
}

// 优质组卷-获取过滤参数详情
export const filterDetails = (id) => {
  return instance.get(`/v2/group-roll/filter-details?id=${id}`)
}

// 优质组卷-获取题库列表
export const questionLists = (grade_index, grade_id ="", course_id ="", area_id ="", diff_id ="", type_id ="", knowledge_id ="", limit = 10, point ="", page= 1 ) => {
  let offset = (page - 1) * limit
  return instance.get(`/v2/group-roll/question-list?grade_index=${grade_index}&grade_id=${grade_id}&course_id=${course_id}&area_id=${area_id}&diff_id=${diff_id}&type_id=${type_id}&knowledge_id=${knowledge_id}&offset=${offset}&limit=${limit}&point=${point}`)
}

// 优质组卷-添加试题
export const addQuestion = (id) => { 
  return instance.post('/v2/group-roll/add-question', {
    id
  })
}

// 优质组卷-试题栏-删除已组卷指定题型
export const deleteQuestion = (ids) => { 
  return instance.post('/v2/group-roll/delete-question', {
    ids
  })
}

// 优质组卷-试题栏-已经添加的试题
export const testQuestionsAlreadyAdded = () => {
  return instance.get(`/v2/group-roll/question-concise`)
}

// 优质组卷-试题栏-清空已添加试题
export const emptyQuestion = () => { 
  return instance.post('/v2/group-roll/clean-question')
}

// 预览试卷
export const paperPreview = (paper_id = 0) => {
  return instance.get(`/v2/group-roll/preview-paper?paper_id=${paper_id}`)
}

// 预览试卷-试卷分析
export const analysisPaperPreview = (paper_id = 0) => {
  return instance.get(`/v2/group-roll/analysis-paper?paper_id=${paper_id}`)
}

// 预览试卷-保存试卷
export const savePaper = (title, content, grade_index, content_list, subtitle) => { 
  return instance.post('/v2/group-roll/save-paper', {
    title, content, grade_index, content_list, subtitle
  })
}

// 预览试卷-下载试卷
export const downLoadPaper = (paper_id) => {
  return instance.get(`/v2/group-roll/download-paper?paper_id=${paper_id}`)
}

// 预览试卷-下载答题卡
export const downLoadAnswerSheet = (paper_id, content, title, is_pdf, page_size) => {
  console.log(page_size)
  instance.post(`/v2/group-roll/download-answer-sheet`, {paper_id,content,is_pdf, page_size})
  .then(res => {
    console.log(res)
    instance.get(res.body,{responseType: 'blob', charset:'UTF-8'})
      .then(resp => {
      if (!resp) {
          return
      }
      let url = window.URL.createObjectURL(new Blob([resp]))
      let link = document.createElement('a')
      link.style.display = 'none'
      link.href = url
      link.setAttribute('download', `${title}-答题卡.${is_pdf?'pdf':'doc'}`)
      document.body.appendChild(link)
      link.click()
    })
  })

}

// 保存答题卡
export const saveAnswerSheet = (paper_id,content,page_size) => {
  console.log(page_size)
  return instance.post(`/v2/group-roll/save-answer-sheet`, {paper_id,content,page_size})
}

// 校本组卷试卷列表
export const testPaperList = (paper_id) => {
  return instance.get(`/v2/dict/get-exam-list?paper_id=${paper_id}`)
}

// 校本组卷下载试卷
export const downLoadTextPaper = (se_id, name) => {
  return instance.get(`v2/exam/download-test-paper?se_id=${se_id}`, {responseType: 'string', charset:'UTF-8'})
          .then(res =>{
            if (res.code === 200) {
              
              let url = window.URL.createObjectURL(new Blob([res.body]))
              let link = document.createElement('a')
              link.style.display = 'none'
              link.href = url
              link.setAttribute('download', `${name}.doc`)
              document.body.appendChild(link)
              link.click()
            } else {
              message.info(res.message)
            }
        })
}

// 试卷分析
export const analysisPaper = (se_id) => {
  return instance.get(`v2/exam/get-analysis?se_id=${se_id}`)
}

// 学情大数据
export const getExamList = () => {
  return instance.get(`v2/dict/get-exam-list?XDEBUG_SESSION_START=8084`)
}

// 考试中心-导出错题
export const exportProblem = (knowledge_point, answer, analysis, expand, selfProposition, se_id, school_id, student_ids, class_id) => {
  return instance.get(`v2/exam/product-mistakes-collection?knowledge_point=${knowledge_point}&answer=${answer}&analysis=${analysis}&expand=${expand}&selfProposition=${selfProposition}&se_id=${se_id}&school_id=${school_id}&student_ids=${student_ids}&class_id=${class_id}`)
}

// 添加学校
export const addSchool = (area_id, name) => {
  return instance.post('/v2/base-data/add-school', {
    area_id,
    name
  })
}

// 数据采集获取学校列表
export const getSchoolList = (me_id) => {
  return instance.post('/v2/student/upload-statistics', {
    me_id
  })
}

// 考生信息录入-点击学校获取该学校下的所有学生信息
export const getStudentsList = ( me_id, school_id, limit = 10, student_id, page = 1) => {
  const offset = limit * (page - 1)
  return instance.post('/v2/student/upload-detail', {
    me_id,
    school_id,
    offset,
    student_id
  })
}

// 学生信息导出-学校/学生列表
export const exportSchoolList = (me_id) => {
  return instance.get(`/v2/down/student-excel?me_id=${me_id}`,{timeout: 60000})
}

// 下载学生列表模板
export const downSchoolList = () => {
  return instance.get('/v2/down/template?type=student')
}

// 学生信息导入--检查校验
export const checkStudents = (me_id) => {
  return instance.post('/v2/student/examming-students', {
    me_id
  })
}

// 导入学生信息-检查文件列表
export const checkFileList = (me_id) => {
  return instance.post('/v2/student/upload-data-state', {
    me_id
  })
}

// 创建考试-获取考试详情
export const creatDetail = (me_id) => {
  return instance.get(`/v2/exam/detail?me_id=${me_id}&XDEBUG_SESSION_START=8084`)
}

// 导入学生信息-检查文件列表详情-删除已上传
export const deleteFileList = (id) => {
  return instance.post('/v2/student/delete-data-state', {
    id
  })
}

// 学生信息导入--检查完成的数据导入数据库
export const importStudent = (me_id, file_id) => {
  return instance.post('/v2/student/import-db', {
    me_id, file_id
  })
}

// 删除上传试卷
export const deleteTestPaper = (se_id) => {
  return instance.post('/v2/exam-paper/delete', {
    se_id
  })
}

// 查看试卷
export const viewTestPaper = (se_id, limit = 1000, page =1) => {
  const offset = limit * (page -1)
  return instance.get(`/v2/exam-paper/question-list?offset=${offset}&se_id=${se_id}`)
}

// 删除指定试题
export const DeleteTestQuestions = (id) => {
  return instance.post('/v2/exam-paper/delete-question', {
    id
  })
}

// 添加试题
export const addTextQuestion = ( se_id, type_id, knowledge, question_number, question_content, difficulty, question_parsing, answer, score, volume_type ) => {
  return instance.post('/v2/exam-paper/add-question', {
    se_id,
    type_id,
    knowledge,
    question_number, 
    question_content,
    difficulty,
    question_parsing,
    answer,
    score,
    volume_type
  })
}

// 试卷录入-上传试卷(已存在的情况)
export const textUpload1 =  baseURL + '/v2/exam-paper/upload-doc'

// 试卷录入-上传试卷(不存在的情况)
export const textUpload2 =  baseURL + '/v2/exam-paper/upload-doc'

// 试卷录入-上传学生列表
export const studentList = baseURL + 'v2/upload/put-student-by-excel'

// 试卷录入-确认试卷上传内容
export const confirmatioContent = (se_id, is_more = 0, content) => {
  return instance.post('/v2/exam-paper/resave-html', {
    se_id,
    content
  })
}

// 试卷录入-获取单科试卷题型
export const questionType = (course_id) => {
  return instance.get(`/v2/dict/question-type?course_id=${course_id}`)
}

// 试卷录入-获取单科考试的知识点
export const getCourseKnowledge = (se_id) => {
  return instance.get(`/v2/dict/se-knowlege?se_id=${se_id}`)
}

// 试卷录入-查看解析、编辑
export const analysisQuestions = (id) => {
  return instance.post('/v2/exam-paper/question-detail', {
    id
  })
}

// 试卷录入-划题标注
export const problemLable = (se_id) => {
  return instance.get(`/v2/exam-paper/division-detail?se_id=${se_id}`)
}

// 试卷录入-保存编辑后的试题拆分试题
export const saveContent= (se_id, is_more, content) => {
  return instance.post('v2/exam-paper/save-content', {
    se_id, is_more, content
  })
}

// 试卷录入-给已经划题成功的题目标注
export const problemLableCompleted= (question_id, trunk, volume_type, source, question_num, answer, knowledge, parsing, difficulty, score, question_type) => {
  return instance.post('/v2/exam-paper/question-label', {
    question_id, trunk, volume_type, source, question_num, answer, knowledge, parsing, difficulty, score, question_type
  })
}

//修改个人信息
export const updateSelfRequest = (nick, phone) => {
  return instance.post('/v2/user/update-self', {
    nick,
    phone
  })
}

//修改密码
export const modifyPswRequest = (new_pass, old_pass) => {
  return instance.post('/v2/user/modify-passwd', {
    new_pass,
    old_pass
  })
}

//角色列表
export const roleListRequest = () => {
  return instance.get('/v2/admin/role-list')
}

//操作日志
export const operationLogRequest = (page, limit) => {
  let offset = (page - 1) * limit
  return instance.get(`/v2/admin/operation-log?limit=${limit}&offset=${offset}`)
}

//登录日志
export const LoginLogRequest = (page, limit) => {
  let offset = (page - 1) * limit
  return instance.get(`/v2/admin/login-log?limit=${limit}&offset=${offset}`)
}

//用户列表
export const userListRequest = (page, limit) => {
  let offset = (page - 1) * limit
  return instance.get(`/v2/admin/user-list?limit=${limit}&offset=${offset}`)
}

//获取城市-地区字典
export const cityAreasRequest = (province_id) => {
  return instance.get(`/v2/dict/city-areas?province_id=${province_id}`)
}

//获取地区下的学校列表
export const schoolsRequest = area_id => {
  return instance.get(`/v2/dict/schools?area_id=${area_id}`)
}

//获取学校下指定年级的班级列表
export const schoolClassesRequest = (school_id, grade_id) => {
  return instance.get(`/v2/dict/school-classes?school_id=${school_id}&grade_id=${grade_id}`)
}

//用户添加
export const userCreateRequest = (login_name, name, password, mobile, type, city_id, area_id, school_id, grade_id, arr_class_id, arr_course_id) =>{
  return instance.post('/v2/admin/user-create', {
    login_name, name, password, mobile, type, city_id, area_id, school_id, grade_id, arr_class_id, arr_course_id
  })
}
//用户编辑
export const userUpdateRequest = (user_id = '', name = '', password = '', mobile = '', type ='', city_id ='', area_id ='', school_id = '' , grade_id = '', arr_class_id ='', arr_course_id ='') =>{
  return instance.post('/v2/admin/user-update', {
    user_id, name, password, mobile, type, city_id, area_id, school_id, grade_id, arr_class_id, arr_course_id
})
}

//用户删除
export const userDeleteRequest = user_id => {
  return instance.post('/v2/admin/user-delete', {
    user_id
  })
}

//获取考试列表
export const examListRequest = (limit, page, me_name='') => {
  const offset = (page-1)*limit
  return instance.get(`/v2/exam/exam-list?limit=${limit}&offset=${offset}&me_name=${me_name}`)
}

//创建考试
export const examCreateRequest = (school_id, grade_id, time, name, enter_year, term_code, course_arr, course_type, area_id, city_id, name_suffix, exam_type, exam_number_length, collection_time_start, collection_time_end) => {
  console.log(school_id, grade_id, time, name, enter_year, term_code, course_arr, course_type, area_id, city_id, name_suffix, exam_type, exam_number_length, collection_time_start, collection_time_end)
  return instance.post('v2/exam/create', {
    school_id, grade_id, time, name, enter_year, term_code, course_arr, course_type, area_id, city_id, name_suffix, exam_type, exam_number_length, collection_time_start, collection_time_end
  })
}

//修改考试
export const examUpdateRequest = (school_id, grade_id, time, name, enter_year, term_code, course_arr, course_type, area_id, city_id, name_suffix, exam_type, exam_number_length, collection_time_start, collection_time_end, me_id) => {
  // console.log('this is edit',school_id, grade_id, time, name, enter_year, term_code, course_arr, course_type, area_id, city_id, name_suffix, exam_type, exam_number_length, collection_time_start, collection_time_end, me_id)
  return instance.post('v2/exam/update', {
    school_id, grade_id, time, name, enter_year, term_code, course_arr, course_type, area_id, city_id, name_suffix, exam_type, exam_number_length, collection_time_start, collection_time_end, me_id
  })
}

//删除考试
export const examDeleteRequest = me_id =>{
  return instance.post('/v2/exam/delete', {me_id})
}

//考试成绩导入-录入学生excle成绩
export const putScoreByExcel = (se_id, file) =>{
  return instance.post('/v2/upload/put-score-by-excel', {se_id, file})
}

// 考试答案导入-录入学生excle答案
export const answerExport = baseURL + '/v2/upload/student-answer-excel?XDEBUG_SESSION_START=8084'

// 考试答案导入-录入家长excle信息
export const parentExport = baseURL + '/v2/upload/parent-info-excel'

//获取指定学生成绩
export const searchStudent = (student_id, se_id) => {
  student_id = parseInt(student_id)
  return instance.get(`/v2/score/search-student?student_id=${student_id}&se_id=${se_id}&XDEBUG_SESSION_START=8084`)
}

//考试成绩导入-修改指定学生成绩
export const updateStudentScoreRequest = (ess_id, q_list) => {
  return instance.post('/v2/score/update-student-score', {ess_id, q_list})
}

//模板下载
export const templateDownloadRequest = type => {
  return instance.get(`/v2/down/template?type=${type}`, {responseType: 'blob'})
}
//发布报告
export const releaseRequest = (me_id, release_at) => {
  return instance.post('/v2/report/release', {me_id, release_at})
}
//根据me_id,school获取所有考试的班级
export const examClassesRequest = (me_id, school_id) => {
  return instance.post('/v2/report/exam-classes', {me_id, school_id})
}
//根据me_id获取所有考试的学校
export const examSchoolsRequest = me_id => {
  return instance.post('/v2/report/exam-schools', {me_id})
}
//获取报告信息
export const reportDetailRequest = (me_id, student_id) => {
  return instance.post('/v2/report/report-detail', {me_id, student_id})
}
//整体数据
export const overallDataRequest = (me_id, class_id, course_id) => {
  return instance.post('/v2/report/overall-data', {me_id, class_id, course_id})
}
//报告下载
export const exportPdfRequest = (report, me_id) => {
  console.log(report, me_id)
   instance.post('/v2/report/export-pdf', {report, me_id})
   .then(res =>{
    instance.get(res.body, {responseType: 'blob', charset:'UTF-8'})
    .then(data =>{
        console.log(data)
        if (!data) {
            return
        }
        let url = window.URL.createObjectURL(new Blob([data]))
        let link = document.createElement('a')
        link.style.display = 'none'
        link.href = url
        link.setAttribute('download', '班级报告.pdf')
        document.body.appendChild(link)
        link.click()
    })
   })
}
//分数段人数
export const teacherGetInfoRequest = (me_id, class_id, course_id, school_id) =>{
  return instance.post('/v2/report/teacher-get-info', {me_id, class_id, course_id, school_id})
}

//知识点分析
export const compareKnowledgeRequest = (me_id, class_id, course_id) =>{
  return instance.post('/v2/report/compare-knowledge', {me_id, class_id, course_id})
}

//各班知识点统计
export const classKnowledgeRequest = (me_id, knowledge, class_id, course_id) => {
  return instance.post('/v2/report/class-knowledge', {me_id, knowledge, class_id, course_id})
}
//各班知识点分析
export const classKnowledgeAnalysisRequest = (me_id, class_id, course_id) => {
  return instance.post('/v2/report/class-knowledge-analysis', {me_id, class_id, course_id})
}
//总分分数段人数分布
export const reportSchaScoreSectionRequest = (me_id, school_id) => {
  return instance.post('/v2/school/report-scha-score-setion', {me_id, school_id})
}
//各班平均分统计
export const reportSchaClassAvgRequest = (me_id, school_id) => {
  return instance.post('/v2/school/report-scha-class-avg', {me_id, school_id})
}
//各科四率
export const reportSchaSubTotalRequest = (me_id, school_id) => {
  return instance.post('/v2/school/report-scha-sub-total',{me_id, school_id})
}
//总分及各科得分概述
export const reportSchaTotalScorRequest = (me_id, school_id) => {
  return instance.post('/v2/school/report-scha-total-score',{me_id, school_id})
}
//总分前后5%、25%人数各校分布比例情况
export const reportSchaRangeRankRequest = (me_id, school_id) => {
  return instance.post('/v2/school/report-scha-range-rank',{me_id, school_id})
}
//各班各科平均分
export const reportSchaClsSubAvgRequest = (me_id, subject, school_id) => {
  return instance.post('/v2/school/report-scha-cls-sub-avg', {me_id, subject, school_id})
}
//各班各科成绩
export const reportSchaClsSubTotalRequest = (me_id, subject, school_id) => {
  return instance.post('/v2/school/report-scha-cls-sub-total', {me_id, subject, school_id})
}

// 总体报告
export const overallReport = (me_id) => {
  return instance.get(`/v2/report/overall?me_id=${me_id}`)
}
//获取班级学生列表
export const getStudentListRequest = (class_id, school_id, me_id, student_id) => {
  return instance.post('/v2/report/get-student-list', {class_id, school_id, me_id, student_id})
}
//个人总体成绩
export const personalAllRequest = (me_id, student_id) => {
  return instance.post('/v2/report/personal-all', {me_id, student_id})
}
//小结
export const summaryRequest = (me_id, student_id) =>{
  return instance.post('/v2/report/summary', {me_id,student_id})
}
//个人单科成绩报告
export const individualsOnlyBranchRequest = (me_id, subject, student_id)  => {
  return instance.post('/v2/report/individuals-only-branch', {me_id, subject, student_id})
}


//我的卷库列表
export const selfList = (page ,limit = 10, filter="") => {
  const offset = limit*(page-1)
  return instance.get(`v2/group-roll/self-list?offset=${offset}&limit=${limit}&filter=${filter}`)
}
//我的卷库-复制
export const selfCopy = (id) => {
  return instance.get(`v2/group-roll/self-copy?paper_id=${id}`)
}
//我的卷库-删除
export const selfDelete = (id) => {
  return instance.get(`v2/group-roll/self-delete?paper_id=${id}`)
}
//我的卷库-修改试卷前的-预览
export const selfPreview = (paper_id) => {
  return instance.get(`v2/group-roll/self-preview?paper_id=${paper_id}`)
}

// 校本组卷试卷列表_hl
export const getExamListRequest = (area_id, city_id, school_id, grade_id, limit = 10, page = 1, start_at, end_at) => {
  const offset = limit*(page-1)
  // console.log(area_id, city_id, school_id, grade_id, limit, offset, start_at? start_at: '', end_at)
  return instance.get(`/v2/dict/get-exam-list?area_id=${area_id}&city_id=${city_id}&school=${school_id}&grade_id=${grade_id}&limit=${limit}&offset=${offset}&start_at=${start_at}&end_at=${end_at}`)
}

//根据se_id获取所有考试的学校
export const exmExamSchoolsRequest = se_id => {
  return instance.get(`/v2/exam/exam-schools?se_id=${se_id}`)
}
//获取参加考试指定学校-班级列表
export const exmExamclassesRequest = (se_id, school_id) =>{
  return instance.get(`/v2/exam/exam-classes?se_id=${se_id}&school_id=${school_id}`)
}
//获取参加考试学校-班级-学生
export const exmExamStudentsRequest = (se_id, class_id, school_id) =>{
  return instance.get(`/v2/exam/exam-students?se_id=${se_id}&class_id=${class_id}&school_id=${school_id}`)
}
//导出错题
export const productMistakesCollection = (knowledge_point, answer, analysis, expand, selfProposition, se_id, school_id, student_ids, class_id) => {
  return instance.get(`/v2/exam/product-mistakes-collection?knowledge_point=${knowledge_point}&answer=${answer}&analysis=${analysis}&expand=${expand}&selfProposition=${selfProposition}&se_id=${se_id}&school_id=${school_id}&student_ids=${student_ids}&class_id=${class_id}`)
}

//试卷录入，标注主列表
export const allQuestionRequest = (se_id) => {
  return instance.post('/v2/exam-paper/all-question',{se_id})
}
//根据se_id获取知识点
export const seKnowledgeRequest = (se_id) => {
  return instance.get(`/v2/dict/se-knowlege?se_id=${se_id}`)
}
//试卷录入-获取单科试卷题型
export const questionTypeRequest = (se_id) => {
  return instance.get(`/v2/dict/question-type?se_id=${se_id}`)
}
//试卷录入-给已经划题成功的题目标注
export const questionLabel = (question_id, trunk, volume_type, sourse, question_num, answer, knowledge, parsing, difficulty, score, question_type) => {
  console.log({question_id, trunk, volume_type, sourse, question_num, answer, knowledge, parsing, difficulty, score, question_type})
  return instance.post('/v2/exam-paper/question-label', {
    question_id, trunk, volume_type, sourse, question_num, answer, knowledge, parsing, difficulty, score, question_type
  })
}

//编辑试卷-从新预览试卷获取
export const paperDetails = (paper_id) =>{
  return instance.get(`/v2/group-roll/paper-details?paper_id=${paper_id}`)
}

//获取角色权限列表
export const permissionListRequest = (role_id) => {
  return instance.get(`/v2/admin/permission-list?role_id=${role_id}`)
}
//更新角色的权限
export const updatePermissionRequest = (role_id, permissionIds) => {
  console.log(role_id, permissionIds)
  return instance.post(`/v2/admin/update-permission`, {role_id, permissionIds})
}