import React, { Component } from 'react'

export default class index extends Component {
    render() {
        return (
            <div>
                404!this html has not found!
            </div>
        )
    }
}
