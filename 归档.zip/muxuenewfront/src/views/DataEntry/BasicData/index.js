import React, { Component } from 'react'
import { Menu, Icon, Layout, Card, Input, Button, Switch, Select } from 'antd'
import { addSchoolDispatch } from '../../../actions/addSchool'

import './BasicData.less'
import { connect } from 'echarts';

const { SubMenu } = Menu
const { Content, Sider } = Layout
const { Search } = Input

const { Option } = Select;
const provinceData = ['Zhejiang', 'Jiangsu']
const cityData = {
  Zhejiang: ['Hangzhou', 'Ningbo', 'Wenzhou'],
  Jiangsu: ['Nanjing', 'Suzhou', 'Zhenjiang'],
}

// 将 state 中保存的通知状态数据映射为组件的属性
const mapStateToProps = (state) => {
    // 返回一个对象
    return {
      basicdata: state.basicdata
    }
}

// @connect(
//     mapStateToProps,
//     { addSchoolDispatch }
// )
export default class BasicData extends Component {
    // submenu keys of first level
    rootSubmenuKeys = ['sub1', 'sub2', 'sub4']

    constructor() {
        super()
        this.state = {
            openKeys: ['sub1'],
            cities: cityData[provinceData[0]],
            secondCity: cityData[provinceData[0]][0]
        }
    }

    onOpenChange = openKeys => {
        const latestOpenKey = openKeys.find(key => this.state.openKeys.indexOf(key) === -1)
        if (this.rootSubmenuKeys.indexOf(latestOpenKey) === -1) {
        this.setState({ openKeys });
        } else {
        this.setState({
            openKeys: latestOpenKey ? [latestOpenKey] : [],
        })
        }
    }

    handleProvinceChange = value => {
        this.setState({
          cities: cityData[value],
          secondCity: cityData[value][0],
        })
    }
    
      onSecondCityChange = value => {
        this.setState({
          secondCity: value,
        })
    }

    render() {
        const { cities } = this.state
        return (
            <Layout className="layout">
                <Sider width={'20%'} style={{ background: "#f3faff" }}>
                    <div style={{display: "flex", flexDirection: "column", justifyContent: "space-around", alignItems: "flex-end", height: 300, cursor: "pointer", paddingRight: "10%"}}>
                        <div style={{height: 50, width: 150, backgroundColor: "#0195ff", color: "#fefefe", textAlign: "center", lineHeight: "50px", fontSize: "16px", fontWeight: 500}}>区域管理</div>
                        <div style={{height: 50, width: 150, backgroundColor: "#0195ff", color: "#fefefe", textAlign: "center", lineHeight: "50px", fontSize: "16px", fontWeight: 500}}>学校管理</div>
                        <div style={{height: 50, width: 150, backgroundColor: "#0195ff", color: "#fefefe", textAlign: "center", lineHeight: "50px", fontSize: "16px", fontWeight: 500}}>知识点管理</div>
                    </div>
                </Sider>
                <Content style={{ paddingRight: '10%', backgroundColor: "#f3faff" }}>
                    <div style={{ background: '#fff', margin: 24, minHeight: 280}}>
                        <div style={{ textAlign: "center", paddingTop: 30 }}>
                            <Select
                                defaultValue={provinceData[0]}
                                style={{ width: 120 }}
                                onChange={this.handleProvinceChange}
                                >
                                {provinceData.map(province => (
                                    <Option key={province}>{province}</Option>
                                ))}
                            </Select>
                            <Select
                                style={{ width: 120 }}
                                value={this.state.secondCity}
                                onChange={this.onSecondCityChange}
                                >
                                {cities.map(city => (
                                    <Option key={city}>{city}</Option>
                                ))}
                            </Select>
                            <Select
                                style={{ width: 120 }}
                                value={this.state.secondCity}
                                onChange={this.onSecondCityChange}
                                >
                                {cities.map(city => (
                                    <Option key={city}>{city}</Option>
                                ))}
                            </Select>
                            <Select
                                style={{ width: 220 }}
                                value={this.state.secondCity}
                                onChange={this.onSecondCityChange}
                                >
                                {cities.map(city => (
                                    <Option key={city}>{city}</Option>
                                ))}
                            </Select>
                            <Button type="primary">添加学校</Button>
                        </div>
                        <Card title="班级详情" style={{ textAlign:"center", margin: "5% 8%" }}>
                            <Button type="primary">选择班级</Button>
                        </Card>
                    </div>
                </Content>
            </Layout>
        )
    }
}
