import React, { Component } from 'react'
import { TestHeader } from '../../../../components'
import { problemLable, problemLableCompleted, saveContent, allQuestionRequest, questionLabel, seKnowledgeRequest, questionTypeRequest } from 'requests'
import RcUeditor from 'react-ueditor-wrap';
import {
    Table,
    Tabs,
    Layout,
    Button,
    Modal,
    message,
    Card,
    Drawer,
    Input,
    Popover,
    Select,
    Radio,
    TreeSelect,
    Form
} from 'antd'
const { Content } = Layout
const { TabPane } = Tabs
const { Option } = Select
const { SHOW_PARENT } = TreeSelect;


function callback(key) {
    console.log(key);
}

@Form.create()
class analysis extends Component {

    constructor() {
        super()
        const arr = window.location.href.split('/')
        const se_id = arr[arr.length - 1]
        this.state = {
            visible1: false,
            visible2: false, // 题型抽屉
            splitVisible: false,
            content: '',
            tag_data: [],
            subValue: '',
            testList: [],
            se_id,
            confirm:false,

            knowledgeList: [],
            questionList: [],
            display: 'none', // 标注 ‘试卷信息’ 显示与隐藏

            //题id
            question_id: '',
            //题干
            trunk: '',
            //区分ab卷
            volume_type: '',
            //试题来源
            sourse: '',
            //题序号
            question_num: '',
            //答案
            answer: '',
            //知识点Id列表
            knowledge: [],
            //解析
            parsing: '',
            //难度
            difficulty: '',
            //分值
            score: '',
            //题目类型Id
            question_type: '',

            //提交的题干
            subSelf: '',
            //提交的答案
            subAnswer: '',
            //提交的解析
            subParsing: '',
            quesTypeList: []
        }
    }

    // 列
    columns = [
        {
            title: '题型',
            dataIndex: 'name'
        },
        {
            title: '题量',
            dataIndex: 'sum'
        },
        {
            title: '题号',
            dataIndex: 'question_num'
        },
    ]

    // 题型抽屉
    showDrawer = () => {
        this.setState({
            visible2: true,
        });
    };

    // 拆分试题模态框
    showModal = () => {
        this.setState({
            splitVisible: true,
        });
    };

    handleOk = () => {
        this.setState({confirm:true})
        // 富文本编辑器 保存
        saveContent(this.state.se_id, 0, this.state.subValue)
            .then(resp => {
                message.info(resp.message)
                this.setState({confirm:false})
                if (resp.code === 200) {
                    this.setState({ visible: false, visible1: false })
                    //请求制卷数据
                    this.testListHandle()
                }
            })
        // this.props.history.push(`/admin/dataentry/examinationprocess/datacollection/problemLable/${this.props.match.params.se_id}`)

    };

    handleCancel = () => {
        this.setState({
            visible: false,
        });
    };
    //请求制卷列表
    testListHandle = () => {
        problemLable(this.props.match.params.se_id)
            .then(resp => {
                let count = 0
                const questionList = resp.body.question_type?resp.body.question_type.map((item, index) => {
                    count +=item.questions.length
                    item = {
                        name: item.name,
                        sum: item.questions.length,
                        question_num: item.questions.map(subj => subj.question_num + ' ')
                    }
                    return item
                }): []
                questionList.push({
                    name: '总计',
                    sum: count+'题'
                })
                this.setState({
                    testList: resp.body,
                    initData: resp.body.html_string,
                    questionList
                })
            })
    }
    //请求单科试卷题型
    questionTypeHandle = () => {
        questionTypeRequest(this.state.se_id)
        .then(res => {
            this.setState({quesTypeList: res.body})
        })
    }
    //请求标注列表
    tagListHandle = () => {
        allQuestionRequest(this.props.match.params.se_id)
            .then(res => {
                console.log(res.body)
                this.setState({
                    tag_data: res.body,
                })
            })
    }
    //请求知识点列表
    queryKnowledgeHandle = () => {
        seKnowledgeRequest(this.state.se_id)
            .then(res => {
                this.setState({ knowledgeList: this.renderTreeNodes(res.body.length?res.body:[]) })
            })
    }
    //递归改变数据
    renderTreeNodes = data => {

      return  data.map(item => {
          if (item.children) {
              item = {
                  title: item.name, 
                  key: item.id,
                  value: item.id,
                  children: this.renderTreeNodes(item.children)
              }
            return item
          }
            item = {
            title: item.name, 
            key: item.id,
            value: item.id,
        }
          return item;
        })
    }
    //返回dangerhtml
    dangerHtml = (html) => {
        return(
                    <div dangerouslySetInnerHTML={{ __html: html }}></div>
        )
    }
    // 显示试卷信息
    showPaperInformation = () => {
        if(this.state.display === 'block') {
            this.setState({
                display: 'none'
            })
        }
        if(this.state.display === 'none') {
            this.setState({
                display: 'block'
            })
        }
    }
    componentDidMount = () => {
        this.testListHandle()
        this.tagListHandle()
    }
    render() {
        const tProps = {
            treeData: this.state.knowledgeList,
            value:this.state.knowledge,
            onChange: value=>{
                this.setState({knowledge: value})
            },
            treeCheckable: true,
            showCheckedStrategy: SHOW_PARENT,
            searchPlaceholder: '请选择知识点',
            dropdownStyle:{ maxHeight: 400, overflow: 'auto' },
            style: {
              width: '100%',
            },
          };
        const { getFieldDecorator } = this.props.form;
        return (
            <Layout className="layout" style={{ backgroundColor: "#f3faff" }}>
                <TestHeader img='/images/two.png'>
                </TestHeader>
                <Content style={{ padding: '24px', width: '1450px', margin: 'auto' }}>
                    <div style={{ background: '#fff', margin: 24, minHeight: 280 }}>
                        <Tabs defaultActiveKey="1" onChange={this.tagListHandle}>
                            <TabPane tab="制卷" key="1" >
                                <Card bordered={false}>
                                    {
                                        this.dangerHtml(this.state.testList.html_string )
                                    }
                                </Card>
                                {/* <div style={{  }}> */}
                                    <Button type="primary" style={{position: "fixed",display: this.state.visible1?'none': 'block',transition:'all 2s',  top: 200, right: 20, zIndex:'888888'}} onClick={() => { 
                                        this.setState({ visible1: true }) }}>
                                        拆分试题
                                </Button>
                                {/* </div> */}
                            </TabPane>
                            <TabPane tab="标注" key="2">
                                <Button type="primary" style={{position: "fixed",transition:'all 2s',  top: 200, right: 20, zIndex:'888888'}} onClick={
                                    this.showPaperInformation
                                }>
                                        试卷信息
                                </Button>
                                <div style={{borderRadius: 10, display: this.state.display, position: 'fixed', top: 200, right: 20, zIndex:'888', width: 300, height: 200,  background: 'rgba(255,255,255)', boxShadow:'2px 2px 3px 2px #ccc'}}>
                                    <div  style={{marginTop: 50, marginLeft: 10}}>
                                        {
                                            <div><span style={{fontWeight: 600}}>考试名称：</span>{ this.state.tag_data.name}</div>
                                        }
                                    </div>
                                    <div  style={{marginTop: 20, marginLeft: 10}}>
                                        {
                                            <div><span style={{fontWeight: 600}}>试题数量：</span>{ this.state.tag_data.count}</div>
                                        }
                                    </div>
                                    <div style={{marginTop: 20, marginLeft: 10}}>
                                        {
                                            <div><span style={{fontWeight: 600}}>试题总分：</span>{ this.state.tag_data.all_score}</div>
                                        }
                                    </div>
                                </div>
                                <div>
                                </div>
                                {
                                    this.state.tag_data.list ? this.state.tag_data.list.map(item => {
                                        return (
                                            <div style={{ position: 'relative', marginBottom: '10px',paddingBottom: '20px', borderBottom: '1px solid #ccc' }} key={item.question_id} >
                                                <div >
                                                <div style={{ height: '40px' , marginTop: '-10px', width: '40px', backgroundColor: item.sign === true ? '#0195ff' : '#f5222d', color: '#fff', textAlign:'center', fontSize: '16px', lineHeight: '35px'}}>{item.question_num}</div>
                                                <div style={{marginLeft: '20px',marginTop: '10px', width: '85%', marginLeft: 50}}>
                                                    {
                                                        this.dangerHtml(item.content_and_note.trunk )
                                                    }
                                                </div>
                                                <Button style={{zIndex:'99', position: 'absolute', right: 20, bottom: 5}} type='primary' onClick={async () => {
                                                this.setState({
                                                    splitVisible: true,
                                                    question_id: item.question_id,
                                                    question_num: item.question_num,
                                                    trunk: item.content_and_note.trunk,
                                                    volume_type: item.content_and_note.volume_type ? item.content_and_note.volume_type : 1,
                                                    sourse: item.content_and_note.sourse ? item.content_and_note.sourse : '',
                                                    answer: item.content_and_note.answer ? item.content_and_note.answer : '',
                                                    knowledge: item.content_and_note.knowledge?item.content_and_note.knowledge.map(item=>item.id):[],
                                                    parsing: item.content_and_note.parsing ? item.content_and_note.parsing : '',
                                                    difficulty: item.content_and_note.difficulty ? item.content_and_note.difficulty : 1,
                                                    score: item.content_and_note.score,
                                                })
                                                this.queryKnowledgeHandle()
                                                await  questionTypeRequest(this.state.se_id)
                                                .then(res => {
                                                    this.setState({quesTypeList: res.body})
                                                })
                                                this.setState({
                                                   
                                                    question_type: item.content_and_note.question_type?item.content_and_note.question_type+'':this.state.quesTypeList[0].quest_type_id,
                                                })
                                                }}>标注</Button>
                                                </div>
                                                {<div style={{ marginLeft: 50, marginTop: 50, border: '1px dashed #ccc', marginRight: 150, borderRadius: 5}}>
                                                    <div style={{marginLeft: 10, marginTop:20,position: 'relative'}}>
                                                        <span style={{fontWeight: 600}}>题型：</span><div style={{position: 'absolute',top: 0,marginLeft: 50  }}>{this.dangerHtml(item.q_type_name)}</div>
                                                    </div>
                                                    <div style={{marginLeft: 10 , marginTop:20, position: 'relative'}}>
                                                        <span style={{fontWeight: 600}}>分数：</span><div style={{position: 'absolute',top: 0, marginLeft: 50  }}>{this.dangerHtml(item.content_and_note.score)}</div>
                                                    </div>
                                                    <div style={{marginLeft: 10, marginTop:20,position: 'relative'}}>
                                                        <span style={{fontWeight: 600}}>难度：</span><div style={{position: 'absolute',top: 0,marginLeft: 50  }}>
                                                        {(() => {
                                                            switch (item.content_and_note.difficulty) {
                                                            case 1:
                                                                return '容易'
                                                            case 2:
                                                                return '较易'
                                                            case 3:
                                                                return '一般'
                                                            case 4:
                                                                return '较难'
                                                            case 5:
                                                                return '困难'
                                                            default:
                                                                return null
                                                            }
                                                        }
                                                        )()}
                                                    </div>
                                                    </div>
                                                    <div style={{marginLeft: 10, marginTop:20, position: 'relative'}}>
                                                        <span style={{fontWeight: 600}}>知识点：</span><div style={{position: 'absolute',top: 0,marginLeft: 50  }}>{this.dangerHtml(item.content_and_note.knowledge.map(i => i.name))}</div>
                                                    </div>
                                                    <div style={{marginLeft: 10, marginTop:20, position: 'relative'}}>
                                                        <span style={{fontWeight: 600}}>答案：</span><div style={{position: 'absolute',top: 0, marginLeft: 50  }}>{this.dangerHtml(item.content_and_note.answer)}</div>
                                                    </div>
                                                    
                                                </div>
                                               }
                                            </div>
                                        )
                                    }):''
                                }
                            </TabPane>
                        </Tabs>

                    </div>
                </Content>
                <Drawer
                    title="拆分试题"
                    visible={this.state.visible1}
                    placement="right"
                    closable={true}
                    style={{width:'1000px'}}
                    onClose={() => {
                        this.setState({ visible1: false })
                    }}
                >
                    <div>
                        <div style={{ backgroundColor: "#fff" }}>
                            <Button onClick={() => {
                                this.setState({ visible: true })
                            }}>拆分试题</Button>
                        </div>
                        <div style={{ backgroundColor: "#fff" }}>
                            题目列表
                    </div>
                        <div>
                            <Table dataSource={this.state.questionList} columns={this.columns} rowKey="name" pagination={false}>
                            </Table>
                        </div>
                    </div>
                </Drawer>
                {/* 试卷题目 */}
                <Modal
                    title="划题"
                    visible={this.state.visible}
                    confirmLoading={this.state.confirm}
                    onOk={this.handleOk}
                    onCancel={() => {
                        this.setState({ visible: false, visible1: false })
                    }}
                    width={1000}
                >
                    <div>
                        <RcUeditor editorConfig={{ initialFrameWidth: 950 }} value={this.state.testList.html_string} style={{ width: '900px' }} onChange={(value) => { this.setState({ subValue: value }) }} />
                    </div>
                </Modal>
                {/* 拆分试题 */}
                <Modal
                    title="标注"
                    visible={this.state.splitVisible}
                    confirmLoading={this.state.confirm}
                    onOk={() => {
                        this.props.form.validateFields((error) => {
                            if(!error){
                                this.setState({confirm:true})
                                // 富文本编辑器 保存
                                let { question_id, subSelf, volume_type, sourse, question_num, subAnswer, knowledge, subParsing, difficulty, score, question_type } = this.state
                                questionLabel(question_id, subSelf, volume_type, sourse, question_num, subAnswer, knowledge, subParsing, difficulty, score, question_type)
                                    .then(resp => {
                                        message.info(resp.message)
                                        this.setState({confirm:false})
                                        if (resp.code === 200) {
                                            this.setState({ splitVisible: false }, ()=>{
                                                //请求制卷数据
                                                this.tagListHandle()
                                            })
                                        }
                                    })
                            }
                        })
                    }}
                    onCancel={() => { this.setState({ splitVisible: false }) }}
                    width={1000}
                >
                    <Form.Item>
                        {
                             getFieldDecorator('questionNum',{rules: [
                                 {
                                    // type: 'number',
                                    required: true,
                                    message: '请输入题号' 
                                 }, {
                                    message:'题号只能输入正整数',
                                    pattern: /^\d+$/
                                 }
                             ], initialValue: this.state.question_num
                            })(

                                <div style={{ margin: '20px' }}>
                                    <div style={{ margin: '10px 20px' }}>【题号】</div>
                                    <Input value={this.state.question_num} onChange={(e)=>{
                                        this.setState({question_num: e.target.value})}}/>
                                </div>
                             )
                        }
                    </Form.Item>
                    <div style={{ margin: '20px' }}>
                        <div style={{ margin: '10px 20px' }}>【题干】</div>
                        <RcUeditor editorConfig={{ initialFrameWidth: 900 }} value={this.state.trunk} onChange={(value) => { this.setState({ subSelf: value }) }} />
                    </div>
                    <div style={{ margin: '20px' }}>
                        <div style={{ margin: '10px 20px' }}>【答案】</div>
                        <RcUeditor editorConfig={{ initialFrameWidth: 900 }} value={this.state.answer} onChange={(value) => { 
                            this.setState({ subAnswer: value }) }} />
                    </div>
                    <Form.Item>
                        {
                             getFieldDecorator('score',{rules: [
                                 {
                                    required: true,
                                    message: '请输入分数' 
                                 }, {
                                    message:'分数必须为正整数或者小数，小数最多两位小数位。整数部分不能以0开头',
                                    pattern: /^\d+\.{0,1}(\d{1,2})?$/
                                 }
                             ],initialValue: this.state.score
                            })(
                            <div style={{ margin: '20px' }}>
                                    <div style={{ margin: '10px 20px' }}>【分数】</div>
                                <Input value={this.state.score} onChange={e => { this.setState({ score: e.target.value }) }} />
                            </div>
                             )
                        }
                    </Form.Item>
                    <div style={{ margin: '20px' }}>
                        <div style={{ margin: '10px 20px' }}>【知识点】</div>
                        <TreeSelect {...tProps} />
         
                    </div>
                    <div style={{ margin: '20px' }} >
                        <div style={{ margin: '10px 20px' }}>【题型】</div>
                        <Select style={{ width: '100%' }} value={this.state.question_type} onChange={value => {
                            this.setState({ question_type: value })
                        }}>
                            {this.state.quesTypeList.map(item => {
                                return(
                                    <Option key={item.quest_type_id} value={item.quest_type_id}>{item.quest_type_name}</Option>
                                )
                            })}
                        </Select>
                    </div>
                    <div style={{ margin: '20px' }}>
                        <div style={{ margin: '10px 20px' }}>【解析】</div>
                        <RcUeditor editorConfig={{ initialFrameWidth: 900 }} value={this.state.parsing} onChange={(value) => { this.setState({ subParsing: value }) }} />
                    </div>
                    <div style={{ margin: '20px' }}>
                        <div style={{ margin: '10px 20px' }}>【试卷类型】</div>
                        <Radio.Group value={this.state.volume_type} onChange={e => { this.setState({ volume_type: e.target.value }) }}>
                            <Radio value={1}>A卷</Radio>
                            <Radio value={2}>B卷</Radio>
                        </Radio.Group>
                    </div>
                    <div style={{ margin: '20px' }}>
                        <div style={{ margin: '10px 20px' }}>【难度】</div>
                        <Radio.Group value={this.state.difficulty} onChange={e => { this.setState({ difficulty: e.target.value }) }}>
                            <Radio value={1}>容易</Radio>
                            <Radio value={2}>较易</Radio>
                            <Radio value={3}>一般</Radio>
                            <Radio value={4}>较难</Radio>
                            <Radio value={5}>困难</Radio>
                        </Radio.Group>
                    </div>
                </Modal>
            </Layout>
        )
    }
}
export default analysis
