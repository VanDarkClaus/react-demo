import React, { Component } from 'react'
import { TestHeader, UEditor } from '../../../../components'
import {
    getSchoolList,
    getStudentsList,
    exportSchoolList,
    downSchoolList,
    checkStudents,
    checkFileList,
    deleteFileList,
    creatDetail,
    viewTestPaper,
    searchStudent,
    textUpload1,
    textUpload2,
    problemLable,
    confirmatioContent,
    updateStudentScoreRequest,
    templateDownloadRequest,
    studentList,
    importStudent,
    answerExport,
    parentExport
} from 'requests'
import { deleteTestPaperDispatch } from '../../../../actions/deleteTextPaper'
import { viewTestPaperDispatch } from '../../../../actions/viewTextPaper'
import { connect } from 'react-redux'
import { Layout, Tabs, Table, Button, Modal, Upload, message, Icon, Input, Card, Radio, Message, Row, Col, Form, notification, Spin, Alert, Switch } from 'antd'

const { Content } = Layout
const { TabPane } = Tabs
const { Search } = Input

function callback(key) {
    // console.log(key)
}

// 将 state 中保存的通知状态数据映射为组件的属性
const mapStateToProps = (state) => {
    // 返回一个对象
    return {
        datacollection: state.datacollection
    }
}
@connect(
    mapStateToProps,
    { deleteTestPaperDispatch, viewTestPaperDispatch }
)
@Form.create()
class DataCollection extends Component {

    constructor() {
        super()
        this.state = {
            h_se_id: '',
            //渲染学科的列表
            h_subjectList: [],
            //上传文件内容
            h_fileList: [
                {
                    uid: '-1',
                    name: 'xxx.png',
                    status: 'done',
                    url: 'http://www.baidu.com/xxx.png',
                },
            ],
            fileList: [
            ],
            uploading: false,

            hVisible: false,
            //编辑框
            h_edit_visible: false,
            h_student: {
                q_list: []
            },
            //切换显示
            h_toggle: '',

            c_toggle: '',
            visible: false,
            visible2: false,
            visible3: false,
            visible4: false,  //试题上传是否覆盖提示框
            visible5: false,  //试题上传完成展示框
            visible6: false,  //答案下载展示框
            visible7: false,  //导入家长模态框
            exportVisible: false,//导入试卷模态框
            body: [],
            student_list: [],
            list: [],
            exam_at: [],
            file_name: '',
            page: 1,
            c_subjectList: [], // 录入试卷显示学科
            se_id: '',
            html_string: '', // 上传试卷内容
            is_more: 0, // 是否拓展题
            loading: false, // 上传答案转圈圈
            loading1: false, // 上传家长转圈圈
        }
    }
    toggle = value => {
        this.setState({ loading: value });
    };
    //点击确定
    h_handleOk = () => {

    }
    //编辑确定
    h_edit_handleOk = () => {
        this.props.form.validateFields((err, values) => {
            for (let i in values) {
                values[i] = values[i] ? values[i] : this.state.h_student.q_list[i]
            }
            updateStudentScoreRequest(this.state.h_student.ess_id, values)
                .then(res => {
                    message.info(res.message)
                    if (res.code === 200) {
                        this.setState({ h_edit_visible: false }, () => {
                            searchStudent(this.state.h_search_value, this.state.h_se_id)
                                .then(res => {
                                    this.setState({ h_student: res.body })
                                })
                        })
                    }
                })
        })
    }

    // // 上传学生列表
    // uploadData = {
    //     name: 'file',
    //     // 上传地址
    //     action: studentList,
    //     // 请求头部
    //     headers: {
    //         Authorization: (JSON.parse(sessionStorage.getItem('token'))).access_token,
    //     },
    //     data: {
    //         me_id: window.location.search.slice(7)
    //     },
    //     onChange(info) {
    //         if (info.file.status !== 'uploading') {
    //             console.log(info.file, info.fileList);
    //         }
    //         if (info.file.status === 'done') {
    //             message.success(`${info.file.name} 上传成功，刷新页面`);
    //         } else if (info.file.status === 'error') {
    //             message.error(`${info.file.name} 上传失败`);
    //         }
    //     },
    // }



    // 学校列表
    columns1 = [
        {
            title: '学校',
            dataIndex: 'school_name',
        },
        {
            title: '导入数量',
            dataIndex: 'all_num',
        },
        {
            title: '检查通过数量',
            dataIndex: 'examming_num',
        },
    ]

    // 检查文件列表
    columns2 = [
        {
            title: '序号',
            render: (text, record, index) => {
                return this.dataIndex = index + 1
            }
        },
        {
            title: '检查时间',
            render: (text, record, index) => {
                return this.dataIndex = new Date(parseInt(record.exam_at) * 1000).toLocaleString().replace(/:\$/)
            }
        },
        {
            title: '源文件名',
            dataIndex: 'file_name',
        },
        {
            title: '状态',
            render: (text, record, index) => {
                return this.dataIndex = record.state
            }
        },
        {
            title: '操作',
            dataIndex: 'chaozuo',
            render: (text, record, index) => {
                return (
                    <Button.Group style={{ display: "flex" }}>
                        {
                            (() => {
                                if (record.state === '未录入') {
                                    return (
                                        <Button onClick={
                                            () => {
                                                importStudent(window.location.search.slice(7), record.id)
                                                    .then(resp => {
                                                        if (resp.code === 200) {
                                                            this.showModal2()
                                                        }
                                                    })
                                            }
                                        }>录入</Button>
                                    )
                                }
                            })()
                        }
                        <Button onClick={this.exportSchoolListHandler}>导出</Button>
                        <Button type="danger" onClick={
                            () => {
                                this.setState({
                                    list: this.state.list.filter(item => item.id !== record.id)
                                })
                                deleteFileList(record.id)
                                    .then(resp => {
                                        if (resp.code === 200) {
                                            alert('删除成功')
                                        }
                                    })
                            }
                        }>删除</Button>
                    </Button.Group>
                )
            }
        }
    ]
    // 学生列表
    columns3 = [
        {
            title: '学籍号',
            dataIndex: 'student_id',
        },
        {
            title: '考号',
            dataIndex: 'student_id',
        },
        {
            title: '姓名',
            dataIndex: 'student_name',
        },
        {
            title: '学校',
            dataIndex: 'school_name',
        },
        {
            title: '年级',
            dataIndex: 'grade_name',
        },
        {
            title: '班级',
            dataIndex: 'class_name',
        },
    ]

    // 显示学生信息模态框
    showModal = (school_id, me_id) => {
        this.setState({
            visible: true,
        })
        // 获取学生信息列表
        getStudentsList(school_id, me_id, this.page)
            .then(resp => {
                this.setState({
                    student_list: resp.body.content
                })
            })
    }

    handleOk = e => {
        this.setState({
            visible: false,
        })
    }

    handleCancel = e => {
        this.setState({
            visible: false,
        })
    }

    // 显示检查文件列表模态框
    showModal2 = () => {
        this.setState({
            visible2: true,
        })
        const me_id = window.location.search.slice(7)
        checkFileList(me_id)
            .then(resp => {
                this.setState({
                    list: resp.body.content
                })
                this.setState({
                    state: this.state.list.map(item => {
                        if (item.state == 0) {
                            return item.state = '未检测'
                        }
                        if (item.state == 1) {
                            return item.state = '未录入'
                        }
                        if (item.state == 2) {
                            return item.state = '录入完毕'
                        }
                        if (item.state == 3) {
                            return item.state = '出错'
                        }
                    })
                })

            })
    }

    handleOk2 = e => {
        this.setState({
            visible2: false,
        })
    }

    handleCancel2 = e => {
        this.setState({
            visible2: false,
        })
    }


    // 试题上传覆盖提示模态框
    showModal4 = () => {
        this.setState({
            visible4: true,
        });
    };

    handleOk4 = e => {
        this.setState({
            visible4: false,
        });
    };

    handleCancel4 = e => {
        this.setState({
            visible4: false,
        });
    };

    // 试题上传覆盖提示模态框
    showModal5 = () => {
        this.setState({
            visible5: true,
        });
    };

    handleOk5 = e => {
        confirmatioContent(this.state.c_toggle, this.state.is_more, this.state.html_string)
            .then(resp => {
                console.log(this.refs.ueditor.getUEContent())
            })
        this.setState({
            visible5: false,
        });
    };

    handleCancel5 = e => {
        this.setState({
            visible5: false,
        });
    };

    // 上传答案
    beforeUpload = () => {
        this.setState({
            loading: true
        })
    }


    uploadAnswer = {
        name: 'file',
        action: answerExport,
        headers: {
            Authorization: (JSON.parse(sessionStorage.getItem('token'))).access_token,
        },
        data: () => {
            return {
                se_id: this.state.h_se_id,
            }
        },
        onChange: (info) => {
            if (info.file.status === 'uploading') {
            }
            if (info.file.status === 'done') {
                if (info.file.response.code === 200) {
                    const args = {
                        message: `${info.file.response.message}`,
                        // description:
                        //   'I will never close automatically. I will be close automatically. I will never close automatically.',
                        duration: 0,
                    };
                    notification.open(args);
                    this.setState({
                        loading: false
                    })
                }
                else {
                    const args = {
                        message: `${info.file.response.message}`,
                        // description:
                        //   'I will never close automatically. I will be close automatically. I will never close automatically.',
                        duration: 0,
                    };
                    notification.open(args);

                }
            } else if (info.file.status === 'error') {
                // message.error(`${info.file.name} file upload failed.`);
            }
        },
        showUploadList: false,
    }

    // 答案下载模态框
    showModal6 = () => {
        this.setState({
            visible6: true,
        });
    };

    handleOk6 = e => {
        templateDownloadRequest('answer')
            .then(data => {
                if (!data) {
                    return
                }
                let url = window.URL.createObjectURL(new Blob([data]))
                let link = document.createElement('a')
                link.style.display = 'none'
                link.href = url
                link.setAttribute('download', '答案.doc')
                document.body.appendChild(link)
                link.click()
            })
        this.setState({
            visible6: false,
        });

    };

    handleCancel6 = e => {
        this.setState({
            visible6: false,
        });
    };


    // 上传家长
    beforeUpload1 = () => {
        this.setState({
            loading1: true
        })
    }

    // 上传家长
    uploadParent = {
        name: 'file',
        action: parentExport,
        headers: {
            Authorization: (JSON.parse(sessionStorage.getItem('token'))).access_token,
        },
        data: () => {
            return {
                me_id: window.location.search.slice(7)
            }
        },
        onChange: (info) => {
            if (info.file.status === 'uploading') {
                console.log(info.file);
            }
            if (info.file.status === 'done') {
                // console.log(info.file.response.code);
                if (info.file.response.code === 200) {
                    const args = {
                        message: `${info.file.response.message}`,
                        // description:
                        //   'I will never close automatically. I will be close automatically. I will never close automatically.',
                        duration: 0,
                    };
                    notification.open(args);
                    this.setState({
                        loading1: false
                    })
                }
                else {
                    const args = {
                        message: `${info.file.response.message}`,
                        // description:
                        //   'I will never close automatically. I will be close automatically. I will never close automatically.',
                        duration: 0,
                    };
                    notification.open(args);

                }
            } else if (info.file.status === 'error') {
                // message.error(`${info.file.name} file upload failed.`);
            }
        },
        showUploadList: false,
    }

    // 导入家长
    showModal7 = () => {
        this.setState({
            visible7: true,
        });
    };

    handleOk7 = e => {
        this.setState({
            visible7: false,
        });
        templateDownloadRequest('parent')
            .then(data => {
                if (!data) {
                    return
                }
                let url = window.URL.createObjectURL(new Blob([data]))
                let link = document.createElement('a')
                link.style.display = 'none'
                link.href = url
                link.setAttribute('download', '模板.xlsx')
                document.body.appendChild(link)
                link.click()
            })
    };

    handleCancel7 = e => {
        this.setState({
            visible7: false,
        });
    };

    // 获取数据
    componentDidMount() {
        this.getSchoolId()

        creatDetail(window.location.search.slice(7))
            .then(resp => {
                resp.body.map(item => {
                    switch (item.course_name) {
                        case '地理': item.img = '/images/subjectIcon/地理.png'; break;
                        case '化学': item.img = '/images/subjectIcon/化学.png'; break;
                        case '理综': item.img = '/images/subjectIcon/理综.png'; break;
                        case '历史': item.img = '/images/subjectIcon/历史.png'; break;
                        case '生物': item.img = '/images/subjectIcon/生物.png'; break;
                        case '数学': item.img = '/images/subjectIcon/数学.png'; break;
                        case "文综": item.img = '/images/subjectIcon/文综.png'; break;
                        case '物理': item.img = '/images/subjectIcon/物理.png'; break;
                        case '英语': item.img = '/images/subjectIcon/英语.png'; break;
                        case '语文': item.img = '/images/subjectIcon/语文.png'; break;
                        default: item.img = '/images/subjectIcon/政治.png'
                    }
                    return item
                })
                this.setState({
                    c_subjectList: resp.body,
                })
            })
    }
    //点击上传
    handleUpload = () => {
        const { fileList } = this.state;
        const formData = new FormData();
        // fileList.forEach(file => {
        formData.append('file', fileList[0]);
        formData.append('se_id', this.state.h_se_id);
        // });

        this.setState({
            uploading: true,
        });


        // You can use any AJAX library you like
        fetch(textUpload1, {
            headers: {
                Authorization: (JSON.parse(sessionStorage.getItem('token'))).access_token,
                //   'content-type': 'application/json'
            },
            method: 'POST',
            //   processData: false,
            body: formData,
        })
            .then((response) => {
                return response.json();
            })
            .then((myJson) => {
                message.info(myJson.message)
                this.setState({ uploading: false })
                if (myJson.code === 200) {
                    this.setState({ exportVisible: false })
                }
            })
    }
    // 根据考号搜索学生
    searchStudent(value) {
        const newList = []
        this.state.student_list.forEach(item => {
            if (item.student_id.indexOf(value) !== -1) {
                newList.push(item)
                this.setState({
                    student_list: newList
                })
            }
        })
    }

    // 获取学校列表id信息
    getSchoolId() {
        // 传入me_id
        getSchoolList(this.props.location.search.slice(7))
            .then(resp => {
                // const { school_name, school_id, all_num, examming_num } = resp.body
                this.setState({
                    body: resp.body
                })
            })
    }

    // 导出学校列表
    exportSchoolListHandler() {
        const me_id = window.location.search.slice(7)
        exportSchoolList(me_id)
            .then(resp => {
                if (resp.code === 200) {
                    message.success('导出完成')
                }
            })
    }

    // 学生列表模板下载
    downSchoolListHandler() {
        downSchoolList()
            .then(resp => {
                if (!resp) {
                    return
                }
                let url = window.URL.createObjectURL(new Blob([resp]))
                let link = document.createElement('a')
                link.style.display = 'none'
                link.href = url
                link.setAttribute('download', '模板.xlsx')
                document.body.appendChild(link)
                link.click()
            })
    }

    // 学生信息导入--检查校验
    checkStudentsHandler() {
        const me_id = window.location.search.slice(7)
        checkStudents(me_id)
            .then(resp => {
                if (resp.code === 200) {
                    message.success('校验完成')
                }
            })
    }


    // 试卷录入-删除已上传试卷
    deleteTestPaperHandler = (se_id) => {
        this.props.deleteTestPaperDispatch(se_id)
    }

    // 试卷录入-查看试卷
    viewTestPaperHandler = (se_id) => {
        this.props.viewTestPaperDispatch(se_id, this.state.page)

    }

    render() {
        const { uploading, fileList } = this.state
        // 上传试卷
        const uploadText = {
            onRemove: file => {
                this.setState(state => {
                    const index = state.fileList.indexOf(file);
                    const newFileList = state.fileList.slice();
                    newFileList.splice(index, 1);
                    return {
                        fileList: newFileList,
                    };
                });
            },
            beforeUpload: file => {
                this.setState(state => ({
                    fileList: [file],
                }));
                return false;
            },
            fileList,
        }
        //成绩录入上传文件配置
        const h_upload = {
            name: 'file',
            action: 'http://server.mymuxue.com/v2/upload/put-score-by-excel',
            // 请求头部
            headers: {
                Authorization: (JSON.parse(sessionStorage.getItem('token'))).access_token,
            },
            data: {
                se_id: this.state.h_se_id
            },
            onChange: (info) => {
                if (info.file.status !== 'uploading') {
                    // console.log(info.file, info.fileList);
                }
                if (info.file.status === 'done') {
                    message.success(`${info.file.name} 导入成功`);
                    this.setState({ visible6: false })
                } else if (info.file.status === 'error') {
                    message.error(`${info.file.name} 导入失败`);
                }
            }
        }
        const { getFieldDecorator } = this.props.form;
        return (
            <Layout className="layout" style={{ backgroundColor: "#f3faff" }}>
                <TestHeader img='/images/two.png'>
                </TestHeader>
                <Content style={{ padding: '24px 0', width: '1450px', margin: 'auto' }}>
                    <div style={{ background: '#fff', margin: 24, minHeight: 280 }}>
                        <div >
                            <Tabs onChange={callback} type="card" >
                                <TabPane tab="考生信息录入" key="1" >
                                    <Table
                                        rowKey="school_id"
                                        columns={this.columns1}
                                        dataSource={this.state.body}
                                        bordered
                                        pagination={false}
                                        footer={
                                            () => {
                                                return (
                                                    <div style={{ display: "flex", justifyContent: "space-around" }}>
                                                        <Button type="primary" style={{ width: 100 }} onClick={this.showModal2}>导入</Button>
                                                        <Button type="primary" style={{ width: 100 }} onClick={this.exportSchoolListHandler}>导出</Button>
                                                        <Button type="primary" style={{ width: 100 }} onClick={this.downSchoolListHandler}>模板下载</Button>
                                                        <Button type="primary" style={{ width: 100 }} onClick={this.checkStudentsHandler}>检查效验</Button>
                                                        <Button type="primary" style={{ width: 100 }} onClick={this.showModal7}>导入家长</Button>
                                                    </div>
                                                )
                                            }
                                        }
                                        style={{ width: 600, margin: '0 auto' }}
                                        onRow={(record) => {
                                            return {
                                                // 点击行跳出模态框
                                                onClick: (event) => {
                                                    event.preventDefault()
                                                    const me_id = this.props.location.search.slice(7)
                                                    if (record.school_id !== 0) {
                                                        this.showModal(record.school_id, me_id)
                                                    }
                                                }
                                            }
                                        }}

                                    />
                                    {/* 导入学生列表模态框 */}
                                    <div>
                                        <Modal
                                            title="导入学生基础信息"
                                            visible={this.state.visible2}
                                            onOk={this.handleOk2}
                                            onCancel={this.handleCancel2}
                                            width={1000}
                                        >
                                            <Upload {...this.uploadData} >
                                                <Button type="primary">浏览</Button>
                                            </Upload>
                                            <Table
                                                rowKey="school_id"
                                                columns={this.columns2}
                                                dataSource={this.state.list}
                                                bordered
                                                pagination={false}
                                                style={{ width: 900, margin: '0 auto', marginTop: 20 }}
                                            />
                                        </Modal>
                                    </div>
                                    {/* 点击学生列表模态框 */}
                                    <div>
                                        <Modal
                                            title="学生信息录入"
                                            visible={this.state.visible}
                                            onOk={this.handleOk}
                                            onCancel={this.handleCancel}
                                            width={1000}
                                        >
                                            <div>
                                                <Search
                                                    placeholder="输入考号"
                                                    onSearch={this.searchStudent}
                                                    enterButton
                                                    style={{ width: 300 }}
                                                />
                                            </div>
                                            <Table
                                                rowKey="school_id"
                                                columns={this.columns3}
                                                dataSource={this.state.student_list}
                                                bordered
                                                pagination={true}
                                                footer={
                                                    () => {
                                                        return (
                                                            <>
                                                                <Button type="primary" style={{ marginRight: "2%", width: 100 }} onClick={this.showModal2}>导入</Button>
                                                                <Button type="primary" style={{ marginRight: "2%", width: 100 }} onClick={this.exportSchoolListHandler}>导出</Button>
                                                                <Button type="primary" style={{ marginRight: "2%", width: 100 }} onClick={this.downSchoolListHandler}>模板下载</Button>
                                                                <Button type="primary" style={{ marginRight: "2%", width: 100 }} onClick={this.checkStudentsHandler}>检查效验</Button>
                                                            </>
                                                        )
                                                    }
                                                }
                                                style={{ width: 800, margin: '0 auto', marginTop: 20 }}
                                            />
                                        </Modal>
                                    </div>
                                </TabPane>
                                <TabPane tab="试卷录入" key="2">
                                    <div className="gutter-example">
                                        <Row gutter={16}>
                                            <div style={{ padding: '30px 17.5%', width: '100%', display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', position: 'relative' }}>
                                                {
                                                    this.state.c_subjectList.map(item => {
                                                        return (
                                                            <div key={item.se_id} style={{ height: '280px', width: '24%', display: 'flex', alignItems: 'center', flexDirection: 'column' }}>
                                                                <div onClick={() => { this.setState({ c_toggle: item.se_id }) }} style={{ position: 'relative', width: '170px', height: '170px', border: '2px solid rgb(204, 204, 204)', borderRadius: '5px' }}>
                                                                    <div style={{ marginLeft: '50%', transform: 'translate(-50%)', display: 'flex', justifyContent: 'center', width: '110px', height: '110px', borderRadius: '50%', background: '#f1f5f8', alignItems: 'center', marginTop: '20px' }}>
                                                                        <img src={item.img} style={{ width: '40px', height: '40px' }} alt={item.course_name} />
                                                                    </div>
                                                                    <img src='/images/圆角选中.png' alt='圆角选中' style={{ position: 'absolute', left: '0', top: '0', display: item.imported === 1 ? 'block' : 'none' }} />
                                                                    <div style={{ marginLeft: '50%', transform: 'translate(-50%)', textAlign: 'center', width: '110px', marginTop: '5px', borderTop: '1px solid #e9eef2' }}>{item.course_name}</div>
                                                                </div>
                                                                <div style={{ display: this.state.c_toggle === item.se_id ? 'block' : 'none' }}>
                                                                    <div style={{ display: "flex", width: 200, height: 80, justifyContent: 'space-between', flexWrap: 'wrap', marginTop: 10, }}>
                                                                        <div>
                                                                            <Button onClick={() => { this.setState({ h_se_id: item.se_id, exportVisible: true }) }} type="primary" >
                                                                                导入试卷
                                                                            </Button>
                                                                            {/* //导入试卷模态框 */}
                                                                            <Modal
                                                                                visible={this.state.exportVisible}
                                                                                footer={[]}
                                                                                title='本次上传会覆盖之前的文件'
                                                                                onCancel={() => { this.setState({ exportVisible: false }) }}

                                                                            >
                                                                                <Upload {...uploadText}>
                                                                                    <Button>
                                                                                        <Icon type="upload" /> 上传文件
                                                                                    </Button>
                                                                                </Upload>
                                                                                <Button
                                                                                    type="primary"
                                                                                    onClick={this.handleUpload}
                                                                                    disabled={fileList.length === 0}
                                                                                    loading={uploading}
                                                                                    style={{ marginTop: 16 }}
                                                                                >
                                                                                    {uploading ? '上传' : '开始上传'}
                                                                                </Button>
                                                                            </Modal>
                                                                        </div>
                                                                        <div>
                                                                            <Button type="primary" onClick={
                                                                                () => {
                                                                                    return (
                                                                                        this.props.history.push(`/admin/dataentry/examinationprocess/datacollection/problemLable/${item.se_id}`)
                                                                                    )
                                                                                }
                                                                            }>划题标注</Button>
                                                                        </div>
                                                                        <div>
                                                                            <Button type="primary" onClick={
                                                                                () => {
                                                                                    this.viewTestPaperHandler(item.se_id)
                                                                                    return (
                                                                                        this.props.history.push(`/admin/dataentry/examinationprocess/datacollection/viewtext/${item.se_id}`)
                                                                                    )
                                                                                }
                                                                            }>查看试卷</Button>
                                                                            <div>
                                                                                <Modal
                                                                                    title="Basic Modal"
                                                                                    visible={this.state.visible3}
                                                                                    onOk={this.handleOk3}
                                                                                    onCancel={this.handleCancel3}
                                                                                >
                                                                                    <p>Some contents...</p>
                                                                                    <p>Some contents...</p>
                                                                                    <p>Some contents...</p>
                                                                                </Modal>
                                                                            </div>
                                                                        </div>
                                                                        <div>
                                                                            <Button type="primary" onClick={
                                                                                () => {
                                                                                    this.deleteTestPaperHandler(item.se_id)
                                                                                    this.setState({
                                                                                        c_subjectList: this.state.c_subjectList.filter(name => name.se_id !== item.se_id)
                                                                                    })
                                                                                }
                                                                            }>删除试卷</Button>
                                                                        </div>
                                                                    </div>
                                                                </div>


                                                            </div>
                                                        )
                                                    })
                                                }
                                            </div>
                                        </Row>
                                    </div>
                                </TabPane>
                                <TabPane tab="成绩录入" key="3">
                                    <div style={{ padding: '30px 17.5%', width: '100%', display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', position: 'relative' }}>
                                        {
                                            this.state.c_subjectList.map(item => {
                                                return (
                                                    <div key={item.se_id} style={{ height: '280px', width: '24%', display: 'flex', alignItems: 'center', flexDirection: 'column' }}>
                                                        <div onClick={() => { this.setState({ h_toggle: item.se_id }) }} style={{ position: 'relative', width: '170px', height: '170px', border: '2px solid rgb(204, 204, 204)', borderRadius: '5px' }}>
                                                            <div style={{ marginLeft: '50%', transform: 'translate(-50%)', display: 'flex', justifyContent: 'center', width: '110px', height: '110px', borderRadius: '50%', background: '#f1f5f8', alignItems: 'center', marginTop: '20px' }}>
                                                                <img src={item.img} style={{ width: '40px', height: '40px' }} alt={item.course_name} />
                                                            </div>
                                                            <img src='/images/圆角选中.png' alt='圆角选中' style={{ position: 'absolute', left: '0', top: '0', display: item.imported === 1 ? 'block' : 'none' }} />
                                                            <div style={{ marginLeft: '50%', transform: 'translate(-50%)', textAlign: 'center', width: '110px', marginTop: '5px', borderTop: '1px solid #e9eef2' }}>{item.course_name}</div>
                                                        </div>
                                                        <div style={{ margin: '10px 0', marginBottom: '20px', marginLeft: '15px', display: this.state.h_toggle === item.se_id ? 'block' : 'none' }}>
                                                            <Button onClick={() => { this.setState({ hVisible: true, h_se_id: item.se_id }) }} type='primary' style={{ marginRight: '10px', marginBottom: '10px' }}>导入成绩</Button>
                                                            <Button onClick={() => { this.setState({ h_edit_visible: true, h_se_id: item.se_id }) }} type='primary'>编辑成绩</Button>
                                                            <Button onClick={() => { this.setState({ visible6: true, h_se_id: item.se_id }) }} type='primary'>导入答案</Button>

                                                        </div>

                                                    </div>

                                                )
                                            })
                                        }
                                        <Button onClick={() => {
                                            const arr = window.location.href.split('/')
                                            const data = arr[arr.length - 1].slice(15)
                                            this.props.history.push(`/admin/dataentry/examinationprocess/publishreports?${data}`)
                                        }}
                                            style={{ width: '105px', height: '40px', position: 'absolute', right: '6%', bottom: '20px', }}
                                            disabled={!this.state.c_subjectList.every(item => item.imported === 1)}
                                            type='primary'>下一步</Button>
                                    </div>
                                    {/* 导入成绩弹出模态框 */}
                                    {
                                        <Modal
                                            destroyOnClose={true}
                                            closable={false}
                                            title="请选择文件"
                                            okText='关闭'
                                            cancelText='下载模板'
                                            visible={this.state.hVisible}
                                            onOk={() => {
                                                this.setState({ hVisible: false })
                                                //关闭之后从新请求
                                                creatDetail(window.location.search.slice(7))
                                                    .then(resp => {
                                                        resp.body.map(item => {
                                                            switch (item.course_name) {
                                                                case '地理': item.img = '/images/subjectIcon/地理.png'; break;
                                                                case '化学': item.img = '/images/subjectIcon/化学.png'; break;
                                                                case '理综': item.img = '/images/subjectIcon/理综.png'; break;
                                                                case '历史': item.img = '/images/subjectIcon/历史.png'; break;
                                                                case '生物': item.img = '/images/subjectIcon/生物.png'; break;
                                                                case '数学': item.img = '/images/subjectIcon/数学.png'; break;
                                                                case "文综": item.img = '/images/subjectIcon/文综.png'; break;
                                                                case '物理': item.img = '/images/subjectIcon/物理.png'; break;
                                                                case '英语': item.img = '/images/subjectIcon/英语.png'; break;
                                                                case '语文': item.img = '/images/subjectIcon/语文.png'; break;
                                                                default: item.img = '/images/subjectIcon/政治.png'
                                                            }
                                                            return item
                                                        })
                                                        this.setState({
                                                            c_subjectList: resp.body
                                                        })
                                                    })
                                            }}
                                            onCancel={() => {
                                                templateDownloadRequest('grade')
                                                    .then(data => {
                                                        if (!data) {
                                                            return
                                                        }
                                                        let url = window.URL.createObjectURL(new Blob([data]))
                                                        let link = document.createElement('a')
                                                        link.style.display = 'none'
                                                        link.href = url
                                                        link.setAttribute('download', '模板.xlsx')
                                                        document.body.appendChild(link)
                                                        link.click()
                                                    })
                                            }}
                                        >
                                            <Upload {...h_upload} >
                                                {/* fileList={this.state.fileList} */}
                                                <Button>
                                                    <Icon type="upload" /> 点击上传
                                            </Button>
                                            </Upload>
                                        </Modal>
                                    }
                                    {/* 编辑成绩弹出模态框 */}
                                    {
                                      this.state.h_edit_visible? <Modal
                                            title="编辑成绩"
                                            visible={this.state.h_edit_visible}
                                            onOk={this.h_edit_handleOk}
                                            destroyOnClose={true}
                                            width={820}
                                            destroyOnClose
                                            onCancel={() => { this.setState({ h_edit_visible: false }) }}
                                        >
                                            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', width: '100%', flexDirection: 'column' }}>
                                                <Search
                                                    placeholder="请输入学号"
                                                    onSearch={value =>
                                                        searchStudent(value, this.state.h_se_id)
                                                            .then(res => {
                                                                this.setState({ h_student: res.body, h_search_value: value })
                                                            })
                                                    }
                                                    style={{ width: 300 }}
                                                />
                                            </div>
                                            <Card title='基础信息'>
                                                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                                    <div>姓名: {this.state.h_student.student_name}</div>
                                                    <div>学校: {this.state.h_student.school_name}</div>
                                                    <div>班级: {this.state.h_student.class_name}</div>
                                                </div>
                                            </Card>
                                            <Card title='成绩信息'>
                                                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                                    <div>科目: {this.state.h_student.course_name}</div>
                                                    <div>得分:{this.state.h_student.ess_score}</div>
                                                </div>
                                                <Form style={{ maxHeight: '300px', overflow: 'auto', display: 'flex', flexWrap: 'wrap' }}>
                                                    {this.state.h_student?this.state.h_student.q_list.map((item, index) => {
                                                        return (
                                                            <Form.Item key={index} style={{ width: '50%' }}>
                                                                {getFieldDecorator(`${index}`)(
                                                                    <div style={{ display: 'flex' }}>
                                                                        <div>题目{index}：{item}分 改为</div>
                                                                        <Input width={80} style={{ width: '50px' }} />
                                                                        <div>分</div>
                                                                    </div>
                                                                )}
                                                            </Form.Item>
                                                        )
                                                    }):''}
                                                </Form>
                                            </Card>
                                        </Modal>:''
                                    }
                                </TabPane>
                            </Tabs>
                        </div>
                    </div>
                    <div>
                    </div>
                    <div>
                        <Modal
                            visible={this.state.visible5}
                            onCancel={this.handleCancel5}
                            onOk={this.handleOk5}
                            width={1000}
                        >
                            <Card bordered={false}>
                                <div>
                                    {/* 使用UEditor 组件 */}
                                    <UEditor ref="ueditor" dangerouslySetInnerHTML={{ __html: this.state.html_string }} />
                                </div>
                            </Card>
                        </Modal>
                    </div>
                    {/* 导入答案模态框 */}
                    <Modal
                        title="导入答案"
                        visible={this.state.visible6}
                        onOk={this.handleOk6}
                        onCancel={this.handleCancel6}
                        okText='下载模板'
                    >
                        <Upload beforeUpload={this.beforeUpload} {...this.uploadAnswer} >
                            <Button>
                                {this.state.loading ? <Icon type="loading" /> : <Icon type="upload" />}上传答案
                            </Button>
                        </Upload>
                    </Modal>
                    <Modal
                        title="导入家长"
                        visible={this.state.visible7}
                        onOk={this.handleOk7}
                        onCancel={this.handleCancel7}
                        okText='下载模板'
                    >
                        <Upload beforeUpload={this.beforeUpload1} {...this.uploadParent} >
                            <Button>
                                {this.state.loading1 ? <Icon type="loading" /> : <Icon type="upload" />}上传
                            </Button>
                        </Upload>
                    </Modal>
                </Content>
            </Layout>
        )
    }
}

export default DataCollection
