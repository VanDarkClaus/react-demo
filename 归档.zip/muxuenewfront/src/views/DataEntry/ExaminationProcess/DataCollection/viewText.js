import React, { Component } from 'react'
import {TestHeader, UEditor} from '../../../../components'
import { viewTestPaperDispatch } from '../../../../actions/viewTextPaper'
import { connect } from 'react-redux'
import { DeleteTestQuestions, viewTestPaper, addTextQuestion, questionType, getCourseKnowledge, analysisQuestions } from 'requests'
import { 
  Layout,
  Button,
  Modal,
  Upload,
  message,
  Icon,
  Input,
  Card,
  Row,
  Col,
  List,
  Form,
  Tooltip,
  Cascader,
  Select,
  Checkbox,
  AutoComplete,
  Radio,
  Tree,
  TreeSelect 
  } from 'antd'
import RcUeditor from 'react-ueditor-wrap';

import './viewText.less'

const { SHOW_PARENT } = TreeSelect;
const { TreeNode } = Tree
const { Content } = Layout
const listData = [];
for (let i = 0; i < 23; i++) {
  listData.push({
    href: 'http://ant.design',
    title: `题目 ${i+1}`,
    description:
      'Ant Design, a design language for background applications, is refined by Ant UED Team.',
    content:
      'We supply a series of design principles, practical patterns and high quality design resources (Sketch and Axure), to help people create their product prototypes beautifully and efficiently.',
  });
}


function onBlur() {
  console.log('blur');
}

function onFocus() {
  console.log('focus');
}

function onSearch(val) {
  console.log('search:', val);
}

const IconText = ({ type, text }) => (
  <span>
    <Icon type={type} style={{ marginRight: 8 }} />
    {text}
  </span>
);

const { Option } = Select;
const AutoCompleteOption = AutoComplete.Option;
// 将 state 中保存的通知状态数据映射为组件的属性
const mapStateToProps = (state) => {
  // 返回一个对象
  return {
    viewtext: state.viewtext
  }
}

@connect(
  mapStateToProps,
  { viewTestPaperDispatch }
)
@Form.create()  
class viewText extends Component {

  constructor(props) {
    super(props)
    this.state = {
      visible: false,
      visible2: false,
      list: [],
      confirmDirty: false,
      autoCompleteResult: [],
      course_id: '',
      typeList: [],
      value: 1,
      treeData: [],
      // initData: '', //添加试题编辑器题干内容
      // initData1: '', //添加试题编辑器答案内容
      // initData2: '', //添加试题编辑器解析内容
      type_id: '',
      knowledge:'',
      question_number: '',
      question_content: '',
      question_parsing: '',
      difficulty: '',
      answer: '',
      volume_type: '',
      // treeData: [
      //   { title: 'Expand to load', key: '0' },
      //   { title: 'Expand to load', key: '1' },
      //   { title: 'Tree Node', key: '2', isLeaf: true },
      // ],
      testType: '', // 试卷类型 A B
      questionId: '', // 题型ID
      knowledge: [],  //知识点Id列表
      inputQuestionId: '', // 题序号
      defaultData1: '', //添加试题编辑器题干初始内容
      initData1: '', //添加试题编辑器题干内容
      defaultData2: '', //添加试题编辑器答案初始内容
      initData2: '', //添加试题编辑器答案内容
      defaultData3: '', //添加试题编辑器解析初始内容
      initData3: '', //添加试题编辑器解析内容
      score: '', // 分数
    }
  }

  // 难度选择
  onChangeSelect = e => {
    console.log('radio checked', e.target.value);
    this.setState({
      value: e.target.value,
    });
  };

  // onChange = (value)  => {
  //   console.log(`selected ${value}`);
  // }

  // 选择题型ID
  onChangeQuestionId = (value)  => {
    this.setState({
      questionId: value
    }, () => {
      console.log(this.state.questionId)
    })
  }
  
  // 选择A、B卷
  onChangePaper = (value) => {
    this.setState({
      testType: value
    }, () => {
      // console.log(this.state.testType)
    })
  }

  // 添加题干
  hanldeChage1 = (value) => {
    this.setState({
      initData1: value
    }, () => {
      console.log(this.state.initData1)
    })
  }

  // 添加答案
  hanldeChage2 = (value) => {
    this.setState({
      initData2: value
    }, () => {
      console.log(this.state.initData2)
    })
  }

  // 添加解析
  hanldeChage3 = (value) => {
    this.setState({
      initData3: value
    }, () => {
      console.log(this.state.initData3)
    })
  }

  // 添加试题提交表单
  handleSubmit = (e) => {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values, score) => {
      console.log(values, score)
      addTextQuestion( this.props.match.params.se_id, this.state.questionId, this.state.knowledge, this.state.inputQuestionId, this.state.initData1, this.state.value, this.state.initData2, this.state.initData3, this.state.score,this.state.testType  )
        .then(resp => {
          if(resp.code !== 200) {
            this.setState({
              visible: true
            })
            message.warning(resp.message)
          }
          if(resp.code === 200) {
            this.setState({
              visible: false
            })
            viewTestPaper(this.props.match.params.se_id)
              .then(resp => {
                console.log(resp)
                this.setState({
                  list: resp.body.list,
                  course_id: resp.body.sinlge_exam.course_id
                })
                console.log(this.state.list)
                this.setState({
                  list: this.state.list.map((item, index) => {
                    return {
                      title: item.question_number,
                      description: <div dangerouslySetInnerHTML = {{ __html:item.question_content }}></div>,
                      id: item.id
                    }
                  })
                })
              })
          }
          console.log(resp)
        })
    });
  }

  // 编辑试题提交表单
  handleSubmit2 = (e) => {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err, values) => {
      if (!err) {
          console.log('Received values of form: ', values);
        }
      console.log(values)
      addTextQuestion()
        .then(resp => {
          console.log(resp)
        })
    });
    // 富文本编辑器 保存
    console.log(this.refs.ueditor.getUEContent())
    this.refs.ueditor.getUEContent()
  };
 
  handleConfirmBlur = e => {
    const { value } = e.target;
    this.setState({ confirmDirty: this.state.confirmDirty || !!value });
  };

  compareToFirstPassword = (rule, value, callback) => {
    const { form } = this.props;
    if (value && value !== form.getFieldValue('password')) {
      callback('Two passwords that you enter is inconsistent!');
    } else {
      callback();
    }
  };

  validateToNextPassword = (rule, value, callback) => {
    const { form } = this.props;
    if (value && this.state.confirmDirty) {
      form.validateFields(['confirm'], { force: true });
    }
    callback();
  };

  handleWebsiteChange = value => {
    let autoCompleteResult;
    if (!value) {
      autoCompleteResult = [];
    } else {
      autoCompleteResult = ['.com', '.org', '.net'].map(domain => `${value}${domain}`);
    }
    this.setState({ autoCompleteResult });
  };

  // 添加试题模态框
  showModal = () => {
    this.setState({
      visible: true,
    })
    questionType(this.state.course_id)
      .then(resp => {
        console.log(resp)
        this.setState({
          typeList: resp.body
        })
        console.log(this.state.typeList)
      })
    getCourseKnowledge(this.props.match.params.se_id)
      .then(resp => {
        console.log(resp)
        this.setState({ treeData: this.renderTreeNodes(resp.body.length?resp.body:[]) })
        console.log(this.state.treeData)
      })
  }

  //递归改变数据
  renderTreeNodes = data => {

    return  data.map(item => {
        if (item.children) {
            item = {
                title: item.name, 
                key: item.id,
                value: item.id,
                children: this.renderTreeNodes(item.children)
            }
          return item
        }
          item = {
          title: item.name, 
          key: item.id,
          value: item.id,
      }
        return item;
      })
  }

  // 编辑试题
  showModal2 = (id) => {
    this.setState({
      visible2: true,
    });
    analysisQuestions(id)
      .then(resp => {
        console.log(resp)
        const { questionName, questionType, difficulty, question_content, answer, question_number, question_parsing, type_id, volume_type, score, knowledges } = resp.body
        // 动态改变表单值
        this.props.form.setFieldsValue({
          questionName, questionType, difficulty, question_content, answer, question_number, question_parsing, type_id, volume_type, score, knowledges
        })
      })
  };

  handleOk2 = e => {
    console.log(e);
    this.setState({
      visible2: false,
    });
  };

  handleCancel2 = e => {
    console.log(e);
    this.setState({
      visible2: false,
    });
  };

  handleOk = e => {
    console.log(e);
    // this.setState({
    //   visible: false,
    // });
  };

  handleCancel = e => {
    console.log(e);
    this.setState({
      visible: false,
    });
  };

  // 删除试题
  deleteTestHandler(id) {
    DeleteTestQuestions(id)
      .then(resp => {
        console.log(resp)
        if(resp.code === 200 ) {
          alert('删除成功')
        }
        this.setState({
          list: this.state.list.filter(item => item.id !== id)
        })
      })
  }

  // 查看解析、编辑试题
  analysisQuestionsHandler = (id) => {
    analysisQuestions(id)
      .then(resp => {
        console.log(resp)
        if(resp.code === 200) {
          return(
            this.props.history.push(`/admin/dataentry/examinationprocess/datacollection/analysisquestions/${id}`)
          )
        }
      })
  }

  inputValue = (value) => {
    console.log(value)
  }

  // 获取数据
  componentDidMount() {
    viewTestPaper(this.props.match.params.se_id)
      .then(resp => {
        console.log(resp)
        this.setState({
          list: resp.body.list,
          course_id: resp.body.sinlge_exam.course_id
        })
        console.log(this.state.list)
        this.setState({
          list: this.state.list.map((item, index) => {
            return {
              title: item.question_number,
              description: <div dangerouslySetInnerHTML = {{ __html:item.question_content }}></div>,
              id: item.id
            }
          })
        })
      })
  }
  render() {
    const tProps = {
      treeData: this.state.treeData,
      value: this.state.knowledge,
      onChange: value=>{
        this.setState({knowledge: value}, () => {
          console.log(this.state.knowledge)
        })
      },
      treeCheckable: true,
      showCheckedStrategy: SHOW_PARENT,
      searchPlaceholder: '请选择知识点',
      dropdownStyle:{ maxHeight: 400, overflow: 'auto' },
      style: {
        width: '100%',
      },
    };
    const { getFieldDecorator } = this.props.form;
    const { autoCompleteResult } = this.state;

    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 8 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 16 },
      },
    };
    const tailFormItemLayout = {
      wrapperCol: {
        xs: {
          span: 24,
          offset: 0,
        },
        sm: {
          span: 16,
          offset: 8,
        },
      },
    };
    const prefixSelector = getFieldDecorator('prefix', {
      initialValue: '86',
    })(
      <Select style={{ width: 70 }}>
        <Option value="86">+86</Option>
        <Option value="87">+87</Option>
      </Select>,
    );

    const websiteOptions = autoCompleteResult.map(website => (
      <AutoCompleteOption key={website}>{website}</AutoCompleteOption>
    ));
    return (
      <Layout className="layout" style={{ backgroundColor: "#f3faff" }}>
                <TestHeader img='/images/two.png'>
                </TestHeader>
                <Content style={{ padding: '24px 10%' }}>
                    <div style={{ background: '#fff', margin: 24, minHeight: 280 }}>
                    <Card  bordered={false} extra={
                      <a type="primary" onClick={
                        () => {
                            return(
                              this.props.history.goBack()
                            ) 
                          }
                        }>
                        返回
                      </a>
                    }>
                      <Button type="primary" onClick={this.showModal}>
                        添加试题
                        </Button>
                      <div>
                        <Modal
                          title="添加试题"
                          visible={this.state.visible}
                          onOk={this.handleOk}
                          onCancel={this.handleCancel}
                          width={1300}
                          footer={null}
                        >
                          <Form {...formItemLayout} onSubmit={this.handleSubmit}>
                            <Form.Item label="题号">
                              {getFieldDecorator('question_number', {
                                rules: [
                                  {
                                    required: true,
                                    message: '请输入题号' 
                                  },
                                  {
                                    message:'题号只能输入正整数',
                                    pattern: /^\d+$/
                                  }
                                ],
                              })(<Input onChange={(e) => {
                                this.setState({
                                  inputQuestionId: e.target.value
                                }, () => {
                                  console.log(this.state.inputQuestionId)
                                })
                              }} />)}
                            </Form.Item>
                            <Form.Item label="题型">
                              {getFieldDecorator('type_id', {
                                rules: [
                                  {
                                    required: true,
                                  },
                                ],
                              })(<Select
                                showSearch
                                style={{ width: 200 }}
                                placeholder="选择题型"
                                optionFilterProp="children"
                                onChange={this.onChangeQuestionId}
                                onFocus={onFocus}
                                onBlur={onBlur}
                                onSearch={onSearch}
                                filterOption={(input, option) =>
                                option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                }
                              >
                                {
                                    this.state.typeList.map((item) => {
                                      return (
                                        <Select.Option key={item.quest_type_id} value={item.quest_type_id}>{item.quest_type_name}</Select.Option>
                                      )
                                    })
                                }
                              </Select>)}
                            </Form.Item>
                            <Form.Item label="分值">
                              {getFieldDecorator('score', {
                                rules: [
                                  {
                                    required: true,
                                    message: '请输入分数' 
                                  },
                                  {
                                    message:'分数必须为正整数或者小数，小数最多两位小数位。整数部分不能以0开头',
                                    pattern: /^\d+\.{0,1}(\d{1,2})?$/
                                  }
                                ],
                              })(<Input onChange={(e) => {
                                this.setState({
                                  score: e.target.value
                                }, () => {
                                  console.log(this.state.score)
                                })
                              }}/>)}
                            </Form.Item>
                            <Form.Item label="所属卷面">
                              {getFieldDecorator('volume_type', {
                                rules: [
                                  {
                                    required: true,
                                  },
                                ],
                              })(<Select
                                showSearch
                                style={{ width: 200 }}
                                optionFilterProp="children"
                                onChange={this.onChangePaper}
                                onFocus={onFocus}
                                onBlur={onBlur}
                                onSearch={onSearch}
                                filterOption={(input, option) =>
                                option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                }
                              >
                                <Option value="1">A卷</Option>
                                <Option value="2">B卷</Option>
                              </Select>)}
                            </Form.Item>
                            <div style={{ marginLeft: '250px', marginBottom: 50 }}>
                                  <span style={{position: 'absolute', top: '339px', left: '213px'}}><span style={{color: 'red'}}>*</span>知识点：</span><div style={{ margin: '10px 20px' }}></div>
                                  <TreeSelect {...tProps} />
                            </div>
                            <Form.Item label="题干">
                              {getFieldDecorator('question_content', {
                                  rules: [
                                  {
                                      required: true,
                                      message: '请输入内容!',
                                  }
                                  ]
                              })(<div>
                                {/* 使用UEditor 组件 */}
                                <RcUeditor editorConfig={{ initialFrameWidth: 900 }} value={this.state.defaultData1} onChange={this.hanldeChage1} />
                              </div>)}
                              </Form.Item>
                              <Form.Item label="答案">
                              {getFieldDecorator('answer', {
                                  rules: [
                                  {
                                      required: true,
                                      message: '请输入内容!',
                                  }
                                  ]
                              })(<div>
                                {/* 使用UEditor 组件 */}
                                <RcUeditor editorConfig={{ initialFrameWidth: 900 }}  value={this.state.defaultData3} onChange={this.hanldeChage3} />
                              </div>)}
                              </Form.Item>
                              <Form.Item label="解析">
                              {getFieldDecorator('question_parsing', {
                                  rules: [
                                  {
                                      required: true,
                                      message: '请输入内容!',
                                  }
                                  ]
                              })(<div>
                                {/* 使用UEditor 组件 */}
                                <RcUeditor editorConfig={{ initialFrameWidth: 900 }}  value={this.state.defaultData2} onChange={this.hanldeChage2} />
                              </div>)}
                              </Form.Item>
                              {/* <Form.Item label="知识点">
                              {getFieldDecorator('knowledge', {
                                  rules: [
                                  {
                                      required: true,
                                      message: '请输入内容!',
                                  }
                                  ]
                              })(
                                <TreeSelect {...tProps} />
                              )}
                              </Form.Item> */}
                              <Form.Item label="难度">
                              {getFieldDecorator('difficulty', {
                                  rules: [
                                  {
                                      required: true,
                                      message: '请输入内容!',
                                  }
                                  ]
                              })(<div>
                                 <Radio.Group onChange={this.onChangeSelect} value={this.state.value}>
                                  <Radio value={5}>困难</Radio>
                                  <Radio value={4}>较难</Radio>
                                  <Radio value={3}>一般</Radio>
                                  <Radio value={2}>较易</Radio>
                                  <Radio value={1}>容易</Radio>
                                </Radio.Group>
                              </div>)}
                              </Form.Item>
                              
                              <Button.Group style={{marginLeft: '80%'}}>
                                <Button type="danger"  onClick={this.handleCancel}>
                                  取消
                                </Button>
                                <Button type="primary" htmlType="submit" onClick={this.handleOk}>
                                  确定
                                </Button>
                              </Button.Group>
                            
                          </Form>
                       
                        </Modal>
                      </div>
                    </Card>
                    <List
                        style={{paddingLeft: 50}}
                        itemLayout="vertical"
                        size="large"
                        pagination={{
                          onChange: page => {
                            console.log(page);
                          },
                          pageSize: 5,
                        }}
                        dataSource={this.state.list}
                        renderItem={item => (
                          <List.Item
                            actions={[
                              <Button onClick={
                                () => {
                                  this.showModal2(item.id)
                                }
                              }>编辑</Button>,
                              <Button onClick={
                                () => {
                                  this.analysisQuestionsHandler(item.id)
                                }
                              }>查看解析</Button>,
                              <Button onClick={
                                () => {
                                  this.deleteTestHandler(item.id)
                                }
                              }>删除</Button>
                            ]}
                          >
                             <div>
                              <Modal
                                title="编辑试题"
                                visible={this.state.visible2}
                                onOk={this.handleOk2}
                                onCancel={this.handleCancel2}
                                width={1000}
                              >
                              {/* <Form {...formItemLayout} onSubmit={this.handleSubmit2}>
                                <Form.Item label="题号">
                                  {getFieldDecorator('question_number', {
                                    rules: [
                                      {
                                        required: true,
                                      },
                                    ],
                                  })(<Input />)}
                                </Form.Item>
                                <Form.Item label="题型">
                                  {getFieldDecorator('type_id', {
                                    rules: [
                                      {
                                        required: true,
                                      },
                                    ],
                                  })(<Select
                                    showSearch
                                    style={{ width: 200 }}
                                    placeholder="选择题型"
                                    optionFilterProp="children"
                                    onChange={this.onChange}
                                    onFocus={onFocus}
                                    onBlur={onBlur}
                                    onSearch={onSearch}
                                    filterOption={(input, option) =>
                                      option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                    }
                                  >
                                    {
                                        this.state.typeList.map((item) => {
                                          return (
                                            <Select.Option key={item.quest_type_id} value={item.quest_type_id}>{item.quest_type_name}</Select.Option>
                                          )
                                        })
                                    }
                                  </Select>)}
                                </Form.Item>
                                <Form.Item label="分值">
                                  {getFieldDecorator('score', {
                                    rules: [
                                      {
                                        required: true,
                                      },
                                    ],
                                  })(<Input />)}
                                </Form.Item>
                                <Form.Item label="所属卷面">
                                  {getFieldDecorator('volume_type', {
                                    rules: [
                                      {
                                        required: true,
                                      },
                                    ],
                                  })(<Select
                                    showSearch
                                    style={{ width: 200 }}
                                    optionFilterProp="children"
                                    onChange={this.onChange}
                                    onFocus={onFocus}
                                    onBlur={onBlur}
                                    onSearch={onSearch}
                                    filterOption={(input, option) =>
                                      option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                    }
                                  >
                                    <Option value="1">A卷</Option>
                                    <Option value="2">B卷</Option>
                                  </Select>)}
                                </Form.Item>
                                <Form.Item label="题干">
                                  {getFieldDecorator('question_content', {
                                      rules: [
                                      {
                                          required: true,
                                          message: '请输入内容!',
                                      }
                                      ]
                                  })(<div ref={this.editorRef}></div>)}
                                  </Form.Item>
                                  <Form.Item label="答案">
                                  {getFieldDecorator('answer', {
                                      rules: [
                                      {
                                          required: true,
                                          message: '请输入内容!',
                                      }
                                      ]
                                  })(<div ref={this.editorRef}></div>)}
                                  </Form.Item>
                                  <Form.Item label="解析">
                                  {getFieldDecorator('question_parsing', {
                                      rules: [
                                      {
                                          required: true,
                                          message: '请输入内容!',
                                      }
                                      ]
                                  })(<div ref={this.editorRef}></div>)}
                                  </Form.Item>
                                  <Form.Item label="知识点">
                                  {getFieldDecorator('knowledge', {
                                      rules: [
                                      {
                                          required: true,
                                          message: '请输入内容!',
                                      }
                                      ]
                                  })(
                                    <Tree loadData={this.onLoadData}>{this.renderTreeNodes(this.state.treeData)}</Tree>
                                  )}
                                  </Form.Item>
                                  <Form.Item label="难度">
                                  {getFieldDecorator('difficulty', {
                                      rules: [
                                      {
                                          required: true,
                                          message: '请输入内容!',
                                      }
                                      ]
                                  })(<div>
                                    <Radio.Group onChange={this.onChangeSelect} value={this.state.value}>
                                      <Radio value={5}>困难</Radio>
                                      <Radio value={4}>较难</Radio>
                                      <Radio value={3}>一般</Radio>
                                      <Radio value={2}>较易</Radio>
                                      <Radio value={1}>容易</Radio>
                                    </Radio.Group>
                                  </div>)}
                                  </Form.Item>
                                  <Button.Group style={{marginLeft: '80%'}}>
                                    <Button type="danger"  onClick={this.handleCancel2}>
                                      取消
                                    </Button>
                                    <Button type="primary" htmlType="submit" onClick={this.handleOk2}>
                                      确定
                                    </Button>
                                  </Button.Group>
                                
                              </Form> */}
                              </Modal>
                            </div>
                            <List.Item.Meta
                              title={<a href={item.href}>{item.title}</a>}
                              description={item.description}
                            />
                            {item.content}
                          </List.Item>
                        )}
                      />
                    </div>
                </Content>
            </Layout>
    )
  }
}
export default viewText
