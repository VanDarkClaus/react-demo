import React, { Component } from 'react'
import {TestHeader} from '../../../../components'
import { analysisQuestions } from 'requests'
import { 
    Layout,
    Button,
    Modal,
    Upload,
    message,
    Icon,
    Input,
    Card,
    Row,
    Col,
    List,
    Form,
    Tooltip,
    Cascader,
    Select,
    Checkbox,
    AutoComplete,
    Radio,
    Tree
    } from 'antd'
const { Content } = Layout

export default class analysis extends Component {

    constructor() {
        super()
        this.state ={
            answer:'',  // 答案
            difficulty: '',  // 难度
            knowledges: [],  // 知识点
            questionName: '',   // 题名称
            questionType: '',  // 题类型
            question_content: '',  // 题内容
            question_number: '',  // 试题序号
            question_parsing: '',  // 解析
            score: '',  // 满分分数
            type_id: '',  // 题型ID
            volume_type: ''  // 试卷类型：1-A卷；2-B卷
        }
    }

    componentDidMount(){
        analysisQuestions(this.props.match.params.id)
            .then(resp => {
                console.log(resp)
                const { answer, difficulty, knowledges, questionName, questionType, question_content, question_number, question_parsing, score, type_id, volume_type } = resp.body
                this.setState({
                    answer,
                    difficulty,
                    knowledges,
                    questionName,
                    questionType,
                    question_content,
                    question_number,
                    question_parsing,
                    score,
                    type_id,
                    volume_type
                })
                console.log(this.state.answer)
            })
    }
    render() {
        return (
            <Layout className="layout" style={{ backgroundColor: "#f3faff" }}>
                <TestHeader img='/images/two.png'>
                </TestHeader>
                <Content style={{ padding: '24px 10%' }}>
                    <div style={{ background: '#fff', margin: 24, minHeight: 280 }}>
                        <Card bordered={false}>
                        <h3>
                            {
                                "题型：" + this.state.questionType
                            }
                        </h3>
                        <h3>
                        {
                                "难度：" + this.state.difficulty
                            }
                        </h3>
                        </Card>
                        
                        <Card title={<div dangerouslySetInnerHTML = {{ __html:this.state.question_content }}></div> }>
                        <p>{"[知识点] " + this.state.knowledges.map((item => {
                            return item.name
                        }))}</p>
                        <div dangerouslySetInnerHTML = {{ __html:this.state.answer }}></div>
                        <p>{"[解析] " + this.state.question_parsing}</p>
                        </Card>
                        <Card title='拓展题型'>

                        </Card>
                    </div>
                </Content>
            </Layout>
        )
    }
}
