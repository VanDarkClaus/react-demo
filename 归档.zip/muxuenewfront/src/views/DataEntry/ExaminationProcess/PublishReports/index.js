import React, { Component } from 'react'
import {TestHeader} from 'components'
import {Radio, DatePicker, Button, message, Spin} from 'antd'
// import moment from 'moment'
import {releaseRequest} from 'requests'

class index extends Component {
    state = { mode: 'time', dateString:'',date:'', value:'1',confirm: false };

    handleOpenChange = (open) => {
      if (open) {
        this.setState({ mode: 'time' });
      }
    };
  
    handlePanelChange = (value, mode) => {
      this.setState({ mode});
    };
    render() {
        return (
            <>
                <TestHeader img='/images/three.png'/>
                <div style = {{ margin: 'auto', width: '75.5%', background: '#fff', height: '660px'}}>
                    <img src='/images/publishreportsThree.png' alt='发布报告' style={{display: 'block', margin: 'auto', paddingTop: '44px',marginBottom: '44px'}}/>
                    <div style={{width: '84%', margin: 'auto', borderTop:'1px dashed #dedede'}}>
                        <div style={{width:'100%', display:'flex',justifyContent:'flex-end',margin: '20px', }}>
                            <Radio.Group name="radiogroup" defaultValue={1}>
                                <Radio style={{fontSize: '20px'}} value={1} onChange={value=>{this.setState({value: value.target.value})}}>立即发布</Radio>
                                <Radio style={{fontSize: '20px'}} value={2} onChange={value=>{this.setState({value: value.target.value})}}>定时发布</Radio>
                            </Radio.Group>
                            <span style={{width: '300px', fontSize: '20px'}}>{this.state.dateString}</span>
                        </div>
                        <div style={{width:'100%', display:'flex',justifyContent:'flex-end'}}>
                
                                        <DatePicker
                                            style={{marginRight:'200px'}}
                                            mode={this.state.mode}
                                            showTime
                                            onOpenChange={this.handleOpenChange}
                                            onPanelChange={this.handlePanelChange}
                                            onChange={(date, dateString)=>{
                                                this.setState({date: date.format('X'), dateString: '('+ dateString + ')'})
                                            }}
                                        />
                        </div>
                        <div style={{width: '100%',display:'flex',justifyContent:'center', marginTop:'120px'}}>
                            <Button style={{width: '140px',height:'60px', display:this.state.confirm?'none':'block'}} type='primary' size='large' onClick={async()=>{
                                await this.setState({confirm:true})
                                let arr = window.location.href.split('/')
                                let me_id =arr[arr.length - 1].slice(21)
                                releaseRequest(me_id, this.state.value===1?'': this.state.date)
                                .then(res => {
                                    this.setState({confirm:false})
                                    console.log(res)
                                    message.info(res.message)
                                })
                            }}>发布报告</Button>
                                <Spin  style={{width: '140px',height:'60px', lineHeight:'60px', display:this.state.confirm?'block':'none'}} size="large" />
                        </div>
                    </div>
                </div>
            </>
        )
    }
}

export default index
