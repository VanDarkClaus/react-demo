import React, { Component } from 'react'

export default class index extends Component {
    render() {
        return (
            <div>
                第三方数据
            </div>
        )
    }
}
