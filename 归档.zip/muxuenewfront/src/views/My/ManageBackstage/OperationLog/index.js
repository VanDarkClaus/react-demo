import React, { Component } from 'react'
import {Card, Form, Table  } from 'antd'
import {operationLogRequest} from '../../../../requests'
import moment from 'moment'

@Form.create()
class index extends Component {
  constructor() {
    super()
    this.state = {
        body: {
            count: 1,
            contents: [
            {
              area_id: null,
              class_id: null,
              content: "",
              created_at: "",
              id: "",
              ip: "",
              name: "",
              type: "",
              updated_at: "",
              user_id: "",
            },
          ]
        }
    }
  }
 
  loginLogData(page = 1, limit = 15) {
    operationLogRequest(page, limit)
    .then(res => {
      this.setState({
        body: res.body
      })
    })
  }

  componentDidMount(){
    this.loginLogData()
  }
    render() {
      
      const columns = [
            {
              title: '姓名',
              dataIndex: 'name',
            }, {
                title: '操作类型',
                dataIndex: 'type'
            }, {
              title: '操作详情',
              dataIndex: 'content'
            },{
              title: 'IP地址',
              dataIndex: 'ip'
            },{
                title: '时间',
                dataIndex: 'updated_at',
                render(text) {
                    return moment(Number(text)).format('YYYY年MM月DD日 HH:mm:ss')
                }
            }
      ]
      var { contents, count } = this.state.body
      var total = Number(count)
        return (
            <Card title="登录日志"
                // headStyle={{  padding: '0 10%' }}
                style={{ width: '90%', margin: 'auto', marginTop: '30px' }}
                hoverable={true}
                bordered={false}
            >
            <Table
              dataSource={contents}
              columns={columns}
              rowKey='id'
              bordered
              size="middle"
              pagination = {{
                  pageSize: 20,
                  showQuickJumper: true,
                  total,
                  onChange: (page) => {
                      this.loginLogData(page)
                  }
              }}
            />
            </Card>
        )
    }
}

export default index