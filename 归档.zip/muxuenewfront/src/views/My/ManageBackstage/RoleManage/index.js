import React, { Component } from 'react'
import {Card, Form, Table, Button, Modal, Tree, message } from 'antd'
import {roleListRequest, permissionListRequest, updatePermissionRequest} from '../../../../requests'

const { TreeNode } = Tree
console.log(Tree)

@Form.create()
class index extends Component {
  constructor() {
    super()
    this.state = {
      visible: false,
      confirmLoading: false,
      dataSource: [
      ],
      autoExpandParent: true,
      checkedList: [],
      selectedKeys: [],

      role_id:'',
      roleList: []
    }
  }

  showModal = id => {
    this.setState({
      visible: true,
      selectId: id
    });
  };

  handleOk = () => {
    this.setState({
      confirmLoading: true,
    });
    updatePermissionRequest(this.state.role_id, this.state.checkedList.checked)
    .then(res=>{
      console.log(res)
      message.info(res.message)
      this.setState({
        visible: false,
        confirmLoading: false
      })
    })

  };

  handleCancel = () => {
    this.setState({
      visible: false,
    });
  };
  //树结构的方法

  onCheck = (checkedKeys, info) => {
    // let arr = [...info.halfCheckedKeys,...checkedKeys]
    // console.log(checkedKeys)
    this.setState({ checkedList: checkedKeys }, ()=>{
      // console.log(this.state.checkedList)
    });
  };

  // onSelect = (selectedKeys, info) => {
  //   console.log('onSelect', info.halfCheckedKeys);
  //   this.setState({ selectedKeys  });
  // };

  renderTreeNodes = data =>
    data.map(item => {
      if (item.children) {
        return (
          <TreeNode title={item.title} key={item.key} dataRef={item}>
            {this.renderTreeNodes(item.children)}
          </TreeNode>
        );
      }
      return <TreeNode key={item.key} {...item} />;
    });

 //获取角色权限列表
 permissionListHandle =() => {
  permissionListRequest(this.state.role_id)
  .then(res=>{
    this.setState({roleList:res.body.tree, checkedList:{checked:res.body.default_id_list}})
  })
 }
  componentDidMount(){
    
    roleListRequest()
    .then(res => {
      this.setState({
        dataSource: res.body
      })
    })
  }
    render() {
      
      const columns = [
            {
              title: '角色名称',
              dataIndex: 'role_name',
              key:'name'
            }, {
              title: '描述',
              dataIndex: 'remark',
              key: 'description'
            }, {
              title: '操作',
              dataIndex: 'operation',
              key: 'operation',
              render: (text, record) => {
                return(
                    <Button disabled={record.status === '0'} onClick={() =>{
                    this.setState({role_id: record.id},()=>{
                      this.permissionListHandle()
                    })
                    this.showModal(record.id)
                    }}  type='primary'>
                      设置权限
                    </Button>
                )
              }
            }
      ]
      const { visible, confirmLoading } = this.state;
        return (
            <Card title="角色管理"
                // headStyle={{  padding: '0 10%' }}
                style={{ width: '90%', margin: 'auto', marginTop: '30px' }}
                hoverable={true}
                bordered={false}
            >
            <Table
              dataSource={this.state.dataSource}
              columns={columns}
              rowKey='id'
              bordered
              size="middle"
              pagination = {false}
            />
              <Modal
                checkable
                title="设置权限"
                visible={visible}
                onOk={this.handleOk}
                confirmLoading={confirmLoading}
                onCancel={this.handleCancel}
              >
                <Tree
                  checkable
                  checkStrictly={true}
                  autoExpandParent={false}
                  onCheck={this.onCheck}
                  // showCheckedStrategy='SHOW_ALL'
                  // multiple
                  checkedKeys={this.state.checkedList}
                  // onSelect={this.onSelect}
                >
                 {this.renderTreeNodes(this.state.roleList)}
                 </Tree>
              </Modal>
            </Card>
        )
    }
}

export default index