import React, { Component } from 'react'
import { manageBackstageRoutes } from '../../../routes'
import {Switch, Redirect, Route} from 'react-router-dom'
import SonFrame from '../../../components/SonFrame'

export default class index extends Component {
    render() {
        return (
            <SonFrame>
                <Switch>
                    {
                        manageBackstageRoutes.map(item =>{
                            return <Route
                                    path = {item.path}
                                    key = {item.path}
                                    component = {item.component}
                                    exact = {item.exact}
                                    />
                        })
                    }
                    <Redirect from = '/admin/managebackstage' to = '/admin/managebackstage/rolemanage' exact/>
                    <Redirect to = '/404'/>
                </Switch>
            </SonFrame>
        )
    }
}
