import React, { Component } from 'react'
import { Card, Form, Table, Button, Modal, Checkbox, Input, Select, Row, Col, message } from 'antd'
import { userListRequest, cityAreasRequest, schoolsRequest, schoolClassesRequest, userCreateRequest, userUpdateRequest, userDeleteRequest } from '../../../../requests'
import dictionary from '../../../../utils/dictionary'
import { addNewRoleShow } from '../../../../utils/isShowByRoot'

@Form.create()
class index extends Component {
  constructor() {
    super()
    this.state = {
      //当前页数
      page: 1,
      //通过省请求到的详细数据
      cityAreas: '',
      
      //已选中的学校的id
      schoolId: '',
      //省id
      province_id: '',
      //选中年级id
      grade: '',
      //选中班级id
      classesId:'',
      //省的id
      area_id: '',
      //身份
      status: '',
      // rolename:'', describe:'', psd:'', phone:'', status:'', city:'', area:'', school:'', grade:'', classes:'', course:''

      //城市
      cityData: [],
      //县区的数据
      areaData: [],
      areaDataChildren: [],
      //请求学校列表
      schoolList: [],
      //请求到班级列表
      classesList: [],
      getFieldDecorator: '',
      ModalText: {
        content: '',
        title: '',
        method: '',
        type: ''
      },
      visible: false,
      confirmLoading: false,
      body: {
        count: 1,
        content: [
          {
            area: "宝安区",
            area_id: "440306",
            can_operation: true,
            city: "深圳市",
            city_id: "440300",
            class_id: "227573032",
            class_item: {
              class_id: "227573032",
              class_name: "2班",
              grade_id: "303"
            },
            email: "",
            grade_id: "303",
            login_name: "1777705",
            mobile: "18012345678",
            name: "姓名5",
            school_id: "22757",
            school_name: "深圳市宝安区学校test1",
            status: "学生",
            type: 2,
            user_id: "1777705",
            province:'',
            province_id:''
          },
        ]
      }
    }
  }
  compareToFirstPassword = (rule, value, callback) => {
    const { form } = this.props;
    if (value && value !== form.getFieldValue('psd')) {
      callback('两次密码不一致');
    } else {
      callback();
    }
  };
  componentDidMount() {
    this.loginLogData()
  }

  showModal = e => {
    this.setState({
      visible: true,
    })
    switch (e.target.getAttribute('dataname')) {
      case 'addrole': this.props.form.setFieldsValue({
        //新建模态框赋予初始值
        rolename:'', describe:'', psd:'', phone:'', status:'', city:'', area:'', school:'', grade:'', classes:'', course:''
      })
      this.setState({
        ModalText: {
          title: '新增用户',
          content: this.content,
          method: userCreateRequest,
          type: 'addrole'
        },
      }); break;
      case 'edit': 
      const {user_id, name, mobile, type, city_id, area_id, school_id = '', class_item = '',grade_id='', province_id } = JSON.parse(e.target.getAttribute('datainfo'))
      const {class_name} = class_item
      //请求省数据
      cityAreasRequest(province_id)
      .then(res => {
        const cityData = res.body.map(item => {
          item = {
            city_id: item.area_id,
            name: item.name
          }
          return item
        }) 
        const areaData = {}
        res.body.map(item => {
            areaData[item.area_id]= item.nodes
          return item
        })
   
        this.setState({ province_id, cityData, areaData, areaDataChildren: areaData[city_id], status: type },()=>{
                //通过区请求得到学校数据
          const requestId = this.state.areaDataChildren.length>0? area_id: city_id
          schoolsRequest(requestId)
          .then(res => {
            this.setState({
              schoolList: res.body
            },()=>{
                this.props.form.setFieldsValue({
                //编辑模态框赋予初始值
                rolename: user_id,province:province_id, describe:name, phone:mobile, status:type, area:area_id,city: city_id, school:school_id, grade:grade_id, classes:class_name, course:''
              })
            })
          })

        })
      })
      this.setState({ ModalText: {title: '编辑', content: this.content, method: userUpdateRequest, type: 'edit' } })
      ; break;
      default: this.setState({ ModalText: 'add' });
    }
  };

  handleOk = () => {
    this.setState({
      confirmLoading: true
    });
    this.props.form.validateFieldsAndScroll((err, values) => {
      console.log(err,values);
      if (!err) {
        const {rolename, describe, psd, phone, status, city, area, school, grade, classes, course} =values
        //编辑时这里判断传入的值是否存在如果不存在使用默认值
        this.state.ModalText.method(rolename, describe, psd, phone, status, city, area, school, grade, classes, course)
        .then(res => {
          if(res.code === 200){
            this.setState({
              visible: false,
              confirmLoading: false,
            })
            message.info(res.message)
          } else{
            this.setState({
              confirmLoading: false,
            })
            message.error(res.message)
          }
        })
      }
    });
  };

  handleCancel = () => {
    this.setState({
      visible: false,
      confirmLoading: false,
      ModalText: {
        content: '',
        title: ''
      },
    })
  };

  loginLogData(page = 1, limit = 15) {
    userListRequest(page, limit)
      .then(res => {
        this.setState({
          body: res.body
        })
      })
  }

  render() {
    const { Option } = Select
    const columns = [
      {
        title: '选中',
        dataIndex: 'dsff',
        render: () => {
          return (
            <Checkbox />
          )
        }
      }, {
        title: '姓名',
        dataIndex: 'name'
      }, {
        title: '市',
        dataIndex: 'city'
      }, {
        title: '学校',
        dataIndex: 'school_name'
      }, {
        title: '身份',
        dataIndex: 'status'
      }, {
        title: '手机',
        dataIndex: 'mobile'
      }, {
        width: 150,
        title: '操作',
        dataIndex: 'dsf',
        render: (text,record) => {
          return (
            <>
              <Button onClick={this.showModal} datainfo={JSON.stringify(record)} dataname='edit'>编辑</Button>
              <Button onClick={() =>{
                console.log(text, record)
                userDeleteRequest(record.user_id)
                .then(res=>{
                  message.info(res.message)
                  this.loginLogData(this.state.page)
                })
              }}>删除</Button>
            </>
          )
        }
      }
    ]
    var { content, count } = this.state.body
    var total = Number(count)
    const { visible, confirmLoading, ModalText,areaDataChildren=[] } = this.state;
    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 4 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 16 },
      },
    };
    const { getFieldDecorator } = this.props.form
    return (
      <Card title="用户管理"
        style={{ width: '90%', margin: 'auto', marginTop: '30px' }}
        hoverable={true}
        bordered={false}
        extra={
          <Button dataname='addrole' onClick={this.showModal}>
            新增用户
                  </Button>
        }
      >
        <Table
          dataSource={content}
          columns={columns}
          rowKey='user_id'
          bordered
          size="middle"
          pagination={{
            pageSize: 20,
            showQuickJumper: true,
            total,
            onChange: (page) => {
              this.loginLogData(page)
              this.setState(
                {page}
              )
            }
          }}
        />
        <Modal
          width={700}
          title={ModalText.title}
          visible={visible}
          onOk={this.handleOk}
          confirmLoading={confirmLoading}
          onCancel={this.handleCancel}
        >
          <Form {...formItemLayout}>
            <Form.Item label='登录名称' style={{display:this.state.ModalText.type === 'block'? '': 'none' }} >
              {getFieldDecorator('rolename', {
                rules: [
                  // {
                  //   required: true,
                  //   message: '不能为空',
                  // }, {
                  //   message: '请输入4-16位字符',
                  //   pattern: /^[-@_a-zA-Z0-9]{4,16}$/
                  // }
                ],
              })(<Input style={{ outline: 'none', border: '1px solid #d9d9d9', borderRadius: '4px', width: '100%'}} />)}
            </Form.Item>
            <Form.Item label="姓名" >
              {getFieldDecorator('describe', {
                rules: [
                  {
                    required: true,
                    message: '请输入姓名',
                  }
                ],
              })(<Input style={{ outline: 'none', border: '1px solid #d9d9d9', borderRadius: '4px', width: '100%' }} />)}
            </Form.Item>
            <Form.Item label="手机号码" >
              {getFieldDecorator('phone', {
                rules: [
                  {
                    required: true,
                    message: '请输入手机号码',
                  }, {
                    message: '请输入正确电话号码',
                    pattern: /^1[3456789]\d{9}$/
                  }
                ],
              })(<Input style={{ outline: 'none', border: '1px solid #d9d9d9', borderRadius: '4px', width: '100%' }} />)}
            </Form.Item>
            <Row>
              <Col span={12}>
                <Form.Item label="身份" >
                  {getFieldDecorator('status', {
                    rules: [
                      {
                        required: true,
                        message: '请输入身份',
                      }
                    ],
                  })(<Select
                    showSearch
                    style={{ width: 150 }}
                    // placeholder="请选择身份"
                    disabled={this.state.ModalText.type === 'addrole'?false: true} 
                    optionFilterProp="children"
                    onChange={value => {
                      this.setState({ status: value })
                      //改变现实内容
                    }}
                  >
                    {dictionary.role.map(item => {
                      return <Option key={item.id} value={item.id}>{item.rolename}</Option>
                    })}
                  </Select>)}
                </Form.Item>
              </Col>
              <Col span={12}>
                <Form.Item label="省" >
                  {getFieldDecorator('province', {
                    rules: [
                      {
                        required: true,
                        message: '请选择省份',
                      }
                    ],
                  })(<Select
                    showSearch
                    style={{ width: 150 }}
                    // placeholder="请选择省份"
                    optionFilterProp="children"
                    onChange={province_id => {
                      cityAreasRequest(province_id)
                      .then(res => {
                       const cityData = res.body.map(item => {
                          item = {
                            city_id: item.area_id,
                            name: item.name
                          }
                          return item
                        }) 
                        const areaData = {}
                        res.body.map(item => {
                            areaData[item.area_id]= item.nodes
                          return item
                        })
                        this.setState({ province_id, cityData, areaData })
                        //清空市和区
                        this.props.form.setFieldsValue({
                          'city': '',
                          'area': '',
                          "school": ''
                        })
                      })
                    }}
                  >
                    {dictionary.provinceDict.map(item => {
                      return <Option key={item.area_id} value={item.area_id}>{item.name}</Option>
                    })}
                  </Select>)}
                </Form.Item>
              </Col>
            </Row>

            <Row>
              <Col span={12}>
                <Form.Item label="市" >
                  {getFieldDecorator('city', {
                    rules: [
                      {
                        required: true,
                        message: '请选择市',
                      }
                    ],
                  })(<Select
                    showSearch
                    allowClear={true}
                    style={{ width: 150 }}
                    // placeholder="请选择市"
                    optionFilterProp="children"
                    onChange={city_id => {
                      this.setState({
                        areaDataChildren: this.state.areaData[city_id]
                      })
                       //通过市id获取到学校
                       schoolsRequest(city_id)
                       .then(res => {
                         this.setState({
                           schoolList: res.body
                         })
                       })
                      //清空区
                      this.props.form.setFieldsValue({
                        'area': '',
                        "school": ''
                      })
                    }}
                  >
                    {this.state.cityData.map(item => {
                      return <Option key={item.city_id} value={item.city_id}>{item.name}</Option>
                    })}
                  </Select>)}
                </Form.Item>
              </Col>
              <Col span={12}>
                <Form.Item label="区/县" >
                  {getFieldDecorator('area', {
                    rules: [
                    ],
                  })(<Select
                    showSearch
                    style={{ width: 150 }}
                    // placeholder="请选择区/县"
                    optionFilterProp="children"
                    onChange={area_id => {
                      this.setState({ area_id })
                      //通过区县id获取到学校
                      schoolsRequest(area_id)
                      .then(res => {
                        this.setState({
                          schoolList: res.body
                        })
                      })
                    }}
                  >
                    {
                      areaDataChildren.map(item => {
                      return <Option key={item.area_id} value={item.area_id}>{item.name}</Option>
                    })
                    }
                  </Select>)}
                </Form.Item>
              </Col>
            </Row>

            <Row>
              <Col span={12}>
                <Form.Item label="学校" >
                {getFieldDecorator('school', {
                    rules: [
                    ],
                  })(<Select
                    showSearch
                    style={{ width: 150 }}
                    optionFilterProp="children"
                    onChange={schoolId => {
                      this.setState({
                        schoolId
                      })
                    }}
                  >
                    {this.state.schoolList.map(item => {
                      return <Option key={item.school_id} value={item.school_id}>{item.name}</Option>
                    })}
                  </Select>)}
                </Form.Item>
              </Col>
              <Col span={12} style={addNewRoleShow(this.state.status)}>
                <Form.Item label="年级" >
                  {getFieldDecorator('grade', {
                      rules: [
                      ],
                    })(<Select
                      showSearch
                      style={{ width: 150 }}
                      optionFilterProp="children"
                      onChange={grade => {
                        this.setState({ grade })
                        schoolClassesRequest(this.state.schoolId, grade)
                        .then(res => {
                          this.setState({
                            classesList: res.body
                          })
                        })
                      }}
                    >
                      {dictionary.grade.map(item => {
                        return <Option key={item.id} value={item.id}>{item.name}</Option>
                      })}
                    </Select>)}
                </Form.Item>
              </Col>
            </Row>

            <Row style={addNewRoleShow(this.state.status)}>
              <Col span={12}>
                <Form.Item label="班级"  >
                {getFieldDecorator('classes', {
                      rules: [
                      ],
                    })(<Select
                      showSearch
                      style={{ width: 150 }}
                      optionFilterProp="children"
                      onChange={classesId => {
                        this.setState({ classesId })
                      }}
                    >
                      {this.state.classesList.map(item => {
                        return <Option key={item.class_id} value={item.class_id}>{item.name}</Option>
                      })}
                    </Select>)}
                </Form.Item>
              </Col>
              <Col span={12}>
                <Form.Item label="科目"  >
                  {getFieldDecorator('course', {
                        // rules: [
                        //   {
                        //     required: true,
                        //     message: '请选择科目',
                        //   }
                        // ],
                      })(<Select
                        showSearch
                        style={{ width: 150 }}
                        // placeholder="请选择科目"
                        optionFilterProp="children"
                        // onChange={course => {
                        //   this.setState({ course })
                        // }}
                      >
                        {dictionary.course.map(item => {
                          return <Option key={item.id} value={item.id}>{item.name}</Option>
                        })}
                      </Select>)}
                </Form.Item>
              </Col>
            </Row>

            <Form.Item label="密码" >
              {getFieldDecorator('psd', {
                rules: [
               {
                    message: '请输入4-16位字符',
                    pattern: /^[-@_a-zA-Z0-9]{4,16}$/
                  }
                ],
              })(<Input type='password' style={{ outline: 'none', border: '1px solid #d9d9d9', borderRadius: '4px', width: '100%' }} />)}
            </Form.Item>
            <Form.Item label="确认密码"  >
              {getFieldDecorator('comfimpsd', {
                rules: [
                  {
                    validator: this.compareToFirstPassword,
                  }, {
                    message: '请输入4-16位字符',
                    pattern: /^[-@_a-zA-Z0-9]{4,16}$/
                  }
                ],
              })(<Input type='password' style={{ outline: 'none', border: '1px solid #d9d9d9', borderRadius: '4px', width: '100%' }} />)}
            </Form.Item>
          </Form>
        </Modal>
      </Card>
    )
  }
}

export default index