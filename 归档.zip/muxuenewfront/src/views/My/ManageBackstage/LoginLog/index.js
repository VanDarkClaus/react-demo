import React, { Component } from 'react'
import {Card, Form, Table  } from 'antd'
import {LoginLogRequest} from '../../../../requests'
import moment from 'moment'

@Form.create()
class index extends Component {
  constructor() {
    super()
    this.state = {
        body: {
            count: 1,
            contents: [
            {
                created_at: "",
                id: "",
                ip: "",
                is_admin: "",
                name: "",
                updated_at: "",
                user_id: ""
            },
          ]
        }
    }
  }
 
  loginLogData(page = 1, limit = 15) {
    LoginLogRequest(page, limit)
    .then(res => {
      this.setState({
        body: res.body
      })
    })
  }

  componentDidMount(){
    this.loginLogData()
  }
    render() {
      
      const columns = [
            {
              title: '姓名',
              dataIndex: 'name',
            }, {
                title: 'IP地址',
                dataIndex: 'ip'
            }, {
                title: '时间',
                dataIndex: 'updated_at',
                render(text) {
                    return moment(Number(text)).format('YYYY年MM月DD日 HH:mm:ss')
                }
            }
      ]
      const { contents, count } = this.state.body
      const total = Number(count)
        return (
            <Card title="登录日志"
                style={{ width: '90%', margin: 'auto', marginTop: '30px' }}
                hoverable={true}
                bordered={false}
            >
            <Table
              dataSource={contents}
              columns={columns}
              rowKey='id'
              bordered
              size="middle"
              pagination = {{
                  pageSize: 20,
                  showQuickJumper: true,
                  total,
                  onChange: (page) => {
                      this.loginLogData(page)
                  }
              }}
            />
            </Card>
        )
    }
}

export default index