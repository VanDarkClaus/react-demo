import React, { Component } from 'react'
import { Card, Button, Form, Input, Modal, message } from 'antd'
import { connect } from 'react-redux'
import { updateSelfRequest, modifyPswRequest } from '../../../requests'
import {loginoutDispatch} from '../../../actions/loginActions'

const mapStateToProps = state => {
    return {
        state
    }
}

@Form.create({ name: 'normal_login' })
@connect(mapStateToProps, {loginoutDispatch})
class index extends Component {
    state = {
        visible: false,
        confirmLoading: false,
      };
    showModal = () => {
        this.setState({
          visible: true,
        })
      }
      handleOk = () => {
        this.setState({
          confirmLoading: true,
        })
        this.props.form.validateFields(['name', 'phone'], (errors, {name, phone}) => {
            //修改用户
            if(!errors){
                updateSelfRequest(name, phone)
                .then(res => {
                    res.code === 200?message.success(res.message) : message.error(res.message)
                })
            }
        })
        setTimeout(() => {
          this.setState({
            visible: false,
            confirmLoading: false,
          });
        }, 2000);
      };
    
      handleCancel = () => {
        this.setState({
          visible: false,
        });
      };
      

    compareToFirstPassword = (rule, value, callback) => {
        const { form } = this.props;
        if (value && value !== form.getFieldValue('newPassword')) {
          callback('两次输入密码不一样');
        } else {
          callback();
        }
      }
      //修改密码
    submit = () => {
        this.props.form.validateFieldsAndScroll(['oldPassword', 'newPassword', 'confirmPassword'], (errors, {oldPassword, newPassword}) => {
            if(!errors){
                modifyPswRequest(oldPassword, newPassword)
                .then(res => {
                    res.code === 200?message.success(res.message) : message.error(res.message)
                    //修改密码后退出登录
                    this.props.loginoutDispatch()
                })
            }
        })
    }
    render() {
        const { getFieldDecorator } = this.props.form;
        const { nick, phone, school_name } = this.props.state.loginReducer.loginValues.user_info
        const rules = [
            {
                required: true,
                message: '请输入密码',
            }, {
                type: 'string',
                message: '请输入字符'
            }, {
                min:6,
                message: '密码不能少于6个字符',
            }, {
                max:16,
                message: '密码不能大于16个字符',
            }, {
                message:'只能输入数字字母和一些符号',
                pattern: /^(?:\d+|[a-zA-Z]+|[!@#$%^&*]+)$/
            }
        ]
        const { visible, confirmLoading } = this.state;
        const ModalText = 
        <Card
            bordered={false}
        >
             <Form.Item label="姓名" hasFeedback>
                {getFieldDecorator('name', {
                    rules: [
                        {
                            required: true,
                            message: '请输入姓名',
                        }
                    ]
                })(<Input style={{border:'1px solid #d9d9d9',borderRadius:'4px' }}/>)}
            </Form.Item>
            <Form.Item label="电话" hasFeedback>
                {getFieldDecorator('phone', {
                    rules: [
                        {
                            required: true,
                            message: '请输入电话',
                        }, {
                            message:'请输入正确电话号码',
                            pattern: /^1[3456789]\d{9}$/
                        }
                    ]
                })(<Input style={{border:'1px solid #d9d9d9',borderRadius:'4px' }}/>)}
            </Form.Item>

        </Card>
        return (
            <>
                <Card title="个人信息"
                    headStyle={{ fontSize: '24px', fontWeight: 'normal', backgroundColor: '#F2F2F2' }}
                    style={{ width: '80%', margin: 'auto', marginTop: '50px' }}
                    extra={
                        <div>
                            <Button onClick={this.showModal} type='primary' style={{ fontSize: '24px', fontWeight: 'normal', lineHeight: '100%' }}>编辑</Button>
                            <Modal
                                title="编辑个人信息"
                                visible={visible}
                                onOk={this.handleOk}
                                confirmLoading={confirmLoading}
                                onCancel={this.handleCancel}
                            >
                                {ModalText}
                            </Modal>
                        </div>
                    }
                    hoverable={true}
                    bordered={false}
                >
                    <div style={{ fontSize: '20px', marginTop: '30px' }}>
                        <span style={{ margin: '10px', marginRight: '100px' }}>姓名：</span><span>{nick}</span>
                    </div>
                    <div style={{ fontSize: '20px', marginTop: '30px' }}>
                        <span style={{ margin: '10px', marginRight: '100px' }}>电话：</span><span>{phone? phone : '-'}</span>
                    </div>
                    <div style={{ fontSize: '20px', marginTop: '30px' }}>
                        <span style={{ margin: '10px', marginRight: '100px' }}>学校：</span><span>{school_name ? school_name : '-'}</span>
                    </div>
                </Card>
                <Form>
                    <Card title="修改密码"
                        headStyle={{ fontSize: '24px', fontWeight: 'normal', backgroundColor: '#F2F2F2' }}
                        style={{ width: '80%', margin: 'auto', marginTop: '50px' }}
                        extra={<Button onClick={this.submit} type='primary' style={{ fontSize: '24px', fontWeight: 'normal', lineHeight: '100%' }}>确定</Button>}
                        hoverable={true}
                        bordered={false}
                    >
                        <Form.Item label="原密码" hasFeedback>
                            {getFieldDecorator('oldPassword', {
                                rules
                            })(<Input.Password style={{border:'1px solid #d9d9d9',borderRadius:'4px' }}/>)}
                        </Form.Item>
                        <Form.Item label="新密码" hasFeedback>
                            {getFieldDecorator('newPassword', {
                                rules
                            })(<Input.Password style={{border:'1px solid #d9d9d9',borderRadius:'4px' }}/>)}
                        </Form.Item>
                        <Form.Item label="确认新密码" hasFeedback>
                            {getFieldDecorator('confirmPassword', {
                                rules: [
                                    ...rules,
                                    {
                                        validator: this.compareToFirstPassword
                                    }
                                ]
                            })(<Input.Password onBlur={this.handleConfirmBlur} style={{border:'1px solid #d9d9d9',borderRadius:'4px' }}/>)}
                        </Form.Item>

                    </Card>
                </Form>
            </>
        )
    }
}

export default index