import React, { Component } from 'react'
import { Form, Icon, Input, Button } from 'antd'
import {connect} from 'react-redux'
import { loginDispatch } from '../../actions/loginActions'
import { Redirect } from 'react-router-dom'
import './login.less'

const mapStateToProps = state =>   {
  return {
    state
  }
}

@connect(mapStateToProps, {loginDispatch})
@Form.create({ name: 'normal_login' })
class index extends Component {
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.props.loginDispatch(values)
        e.preventDefault();
      }
    });
  };

  render() {
    const { getFieldDecorator } = this.props.form;
    return (
      this.props.state.loginReducer.loginValues.access_token?
      <Redirect to = '/admin'/>
      :
      <div className='login-img'>
        <div className='mx-login'>
          <Form  className="login-form">
            <Form.Item>
              {getFieldDecorator('username', {
                rules: [{ required: true, message: '请输入账号' }],
              })(
                <Input
                  style={{ width: '330px', height: '50px', marginBottom:'5px'}}
                  prefix={<Icon type="user" style={{ color: 'rgba(0,0,0,.25)' }} />}
                  placeholder="请输入用户名"
                />,
              )}
            </Form.Item>
            <Form.Item>
              {getFieldDecorator('password', {
                rules: [{ required: true, message: '请输入密码' }],
              })(
                <Input.Password
                  style={{ width: '330px', height: '50px',background:'#dedede', marginBottom:'5px'}}
                  prefix={<Icon type="lock" style={{ color: 'rgba(0,0,0,.25)' }} />}
                  placeholder="请输入密码"
                />,
              )}
            </Form.Item>
            <Form.Item>
              <Button
                onClick={this.handleSubmit}
                type="primary"
                htmlType="submit"
                style={{fontSize:'16px',letterSpacing: '10px', width: '330px', height: '50px',borderRadius: '25px',border:'none', background: 'linear-gradient(to right, #5abfe8,#6381f3)', color:'#4058e0'}}
              >
                登录
            </Button>
            </Form.Item>
          </Form>
            <a href='http://mymuxue.com' >返回首页</a>
        </div>
      </div>
    )
  }
}

export default index