import React, { Component } from 'react'
import { resourceRoutes } from '../../routes'
import {Switch, Redirect, Route} from 'react-router-dom'
import SonFrame from '../../components/SonFrame'

export default class index extends Component {
    render() {
        return (
            <SonFrame>
                <Switch>
                    {
                        resourceRoutes.map(item =>{
                            return <Route
                                    path = {item.path}
                                    key = {item.path}
                                    component = {item.component}
                                    exact = {item.exact}
                                    />
                        })
                    }
                    <Redirect from = '/admin/resource' to = '/admin/resource/qualitygroup' exact/>
                    <Redirect to = '/404'/>
                </Switch>
            </SonFrame>
        )
    }
}
