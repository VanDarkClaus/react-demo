import React, { Component } from 'react'
import { selfList, selfCopy, selfDelete, downLoadPaper, downLoadAnswerSheet } from '../../../requests'
import {  Card, Input, Button, List, Pagination, Popconfirm, Popover } from 'antd'
import moment from 'moment'

const { Search } = Input

export default class MyGroup extends Component {

    constructor() {
        super()
        this.state = {
            textPaperList: [],
            visible: false,
            page: 1,
            searchValue: '',
            listCount: 10,
        }
    }

    // 获取试卷列表数据
    selfListhandle() {
        selfList(this.state.page, 10, this.state.searchValue)
            .then(resp => {
                this.setState({
                    textPaperList: resp.body.list,
                    listCount: Number(resp.body.count)
                })
            })
    }
    componentDidMount() {
        // 获取试卷列表数据
        selfList(this.state.page)
            .then(resp => {
                this.setState({
                    textPaperList: resp.body.list,
                    listCount: Number(resp.body.count),
                })
            })
    }

    // 下载试卷
    downLoadTextPaper = (id, name) => {
        downLoadPaper(id, 0)
            .then(resp => {
                if (!resp) {
                    return
                }
                let url = window.URL.createObjectURL(new Blob([resp]))
                let link = document.createElement('a')
                link.style.display = 'none'
                link.href = url
                link.setAttribute('download', `${name}-试卷.doc`)
                document.body.appendChild(link)
                link.click()
            })
    }

  
    render() {
        return (
            <div style={{ padding: '10px 0',  width: '1450px',margin: '0 auto', }}>
                <div style={{ background: '#fff', margin: 24, minHeight: 280 }}>
                    <Card style={{ marginLeft: "20px", marginRight: "20px" }} bordered={false}>
                        <Search onSearch={value => {
                            this.setState({ searchValue: value, page: 1 }, () => {
                                this.selfListhandle()
                            })
                        }} enterButton style={{ width: 300, float: "right" }} placeholder="支持题干搜索" />
                    </Card>
                    {
                        this.state.textPaperList.map((item, index) => {
                            return (
                                <List.Item key={index}>
                                    <Card style={{ margin: "0 20px" ,width:'1200px', margin:'auto'}} >
                                        <div style={{ fontSize: '18px', fontWeight: 900, marginBottom: 20 }}>{item.title}</div>
                                        <span>{item.course_name}</span>
                                        <span style={{ marginLeft: 50 }}>{moment(item.created_at * 1000).format('YYYY/MM/DD')}</span>
                                        <span style={{ marginLeft: 50 }}>预览0次</span>
                                        <Button.Group style={{ marginLeft: 500 }}>
                                            <Button type="primary" onClick={() => {
                                                selfCopy(item.id)
                                                    .then(res => {
                                                        if (res.code === 200) {
                                                            selfList(this.state.page)
                                                                .then(res => {
                                                                    this.setState({
                                                                        textPaperList: res.body.list,
                                                                    })
                                                                })
                                                        }
                                                    })
                                            }}>
                                                复制试卷
                                            </Button>
                                            <Button type="primary" onClick={()=>{
                                                this.props.history.push({pathname:`/admin/resource/qualitygroup/paperPreview/''`, state:{garde_id:item.id}})
                                            }}>
                                                修改试卷
                                            </Button>
                                            <Popconfirm title="确定删除吗？" okText="删除" cancelText="取消" onConfirm={() => {
                                                selfDelete(item.id)
                                                    .then(res => {
                                                        if (res.code === 200) {
                                                            selfList(this.state.page)
                                                                .then(res => {
                                                                    this.setState({
                                                                        textPaperList: res.body.list,
                                                                    })
                                                                })
                                                        }
                                                    })
                                            }}>
                                                <Button type="primary">
                                                    删除
                                                </Button>
                                            </Popconfirm>
                                            <Button type="primary" onClick={
                                                () => {
                                                    this.downLoadTextPaper(item.id, item.title)
                                                }
                                            }>
                                                下载试卷
                                            </Button>
                                            <Popover
                                                content={(
                                                    <div>
                                                        <Button onClick={()=>{downLoadAnswerSheet(item.id, '',item.title, 1)}} style={{marginRight:'20px'}}>下载pdf</Button>
                                                        <Button onClick={()=>{downLoadAnswerSheet(item.id, '',item.title, 0)}}>下载doc</Button>
                                                    </div>
                                                )}
                                            >
                                                <Button type="primary">下载答题卡</Button>
                                            </Popover>
                                        </Button.Group>
                                    </Card>
                                </List.Item>
                            )
                        })
                    }
                    <Pagination onChange={page => {
                        this.setState({ page }, () => {
                            this.selfListhandle()
                        })
                    }}
                        total={this.state.listCount}
                        style={{ display: 'flex', justifyContent: 'flex-end' }}
                    />
                </div>
            </div>
        )
    }
}
