import React, { Component } from 'react'
import { Tabs, Layout, Card, Descriptions, Radio, Input, Upload, message, Button, Icon, Modal, Checkbox, Row, Col } from 'antd'
import './StudyGroup.less'

const CheckboxGroup = Checkbox.Group
const { TabPane } = Tabs
const { Content, Footer } = Layout

const { Dragger } = Upload
const props = {
    name: 'file',
    multiple: true,
    action: 'https://www.mocky.io/v2/5cc8019d300000980a055e76',
    onChange(info) {
        const { status } = info.file;
        if (status !== 'uploading') {
            console.log(info.file, info.fileList);
        }
        if (status === 'done') {
            message.success(`${info.file.name} file uploaded successfully.`);
        } else if (status === 'error') {
            message.error(`${info.file.name} file upload failed.`);
        }
    },
}

// 多选框数据分类
const plainOptions = ['初二123班的数学月考', '初二123班的数学月考2']
// 改变选中标签页返回函数
function callback(key) {
    console.log(key)
}
// 保存为试卷模板
function saveTemplate(e) {
    console.log(`checked = ${e.target.checked}`);
}

export default class StudyGroup extends Component {

    state = {
        // 模态框显示状态，初始值为 false 不显示
        visible1: false,
        visible2: false,
        indeterminate: true,
        checkAll: false
    }

    // 显示专题训练模态框
    showModal1 = () => {
        this.setState({
            visible1: true,
        })
    }

    // 显示薄弱训练模态框
    showModal2 = () => {
        this.setState({
            visible2: true,
        })
    }
    
    // 点击模态框 “确定” 按钮隐藏模态框
    handleOk = e => {
        console.log(e)
        this.setState({
            visible1: false,
            visible2: false,
        })
    }
    
    // 点击模态框 “取消” 按钮隐藏模态框
    handleCancel = e => {
        console.log(e)
        this.setState({
            visible1: false,
            visible2: false,
        })
    }

    // 改变多选框选择状态
    changeSelect = checkedList => {
        this.setState({
            checkedList,
            indeterminate: !!checkedList.length && checkedList.length < plainOptions.length,
            checkAll: checkedList.length === plainOptions.length,
        })
    }
    
    // 全选
    onCheckAllChange = e => {
        this.setState({
            checkedList: e.target.checked ? plainOptions : [],
            indeterminate: false,
            checkAll: e.target.checked,
        })
    }
    render() {
        return (
            <Layout className="layout">
                <Content style={{ padding: '0 15%', backgroundColor: "#f3faff" }}>
                <div style={{ background: '#fff', margin: 24, minHeight: 280 }}>
                <Tabs defaultActiveKey="1" onChange={callback} style={{marginLeft: "40px", marginRight: "40px"}}>
                    <TabPane tab="专题训练" key="1">
                        <Card bordered={false} style={{borderBottom: "1px dashed #ccc"}}>
                            <Descriptions column={1}>
                                <Descriptions.Item><span style={{fontWeight: 700, color: "#5f6064"}}>年级或班级：</span>
                                    <Radio.Group defaultValue="a" buttonStyle="solid" style={{marginLeft: "20px"}}>
                                        <Radio.Button value="a" style={{marginRight: "50px"}}>全部</Radio.Button>
                                    </Radio.Group>
                                </Descriptions.Item>
                            </Descriptions>
                        </Card>
                        <Card bordered={false} style={{borderBottom: "1px dashed #ccc"}}>
                            <Descriptions column={1}>
                                <Descriptions.Item><span style={{fontWeight: 700, color: "#5f6064"}}>考试范围：</span>
                                        <Button style={{marginLeft: "33px"}} type="primary" onClick={this.showModal1}>点击选择考试范围</Button>
                                        <Modal
                                            title="考试范围"
                                            visible={this.state.visible1}
                                            onOk={this.handleOk}
                                            onCancel={this.handleCancel}
                                        >
                                            <Card bordered={false} style={{borderBottom: "1px dashed #ccc"}}>
                                                <Descriptions column={1}>
                                                    <Descriptions.Item><span style={{fontWeight: 700, color: "#5f6064"}}>统计时间段：</span>
                                                        <Radio.Group defaultValue="a" buttonStyle="solid" style={{marginLeft: "20px"}} >
                                                            <Radio.Button value="a">近一周</Radio.Button>
                                                            <Radio.Button value="b">近一个月</Radio.Button>
                                                            <Radio.Button value="c">自定义</Radio.Button>
                                                        </Radio.Group>
                                                    </Descriptions.Item>
                                                </Descriptions>
                                            </Card>
                                            <Card bordered={false} style={{borderBottom: "1px dashed #ccc"}}>
                                                <Descriptions column={1}>
                                                    <Descriptions.Item><span style={{fontWeight: 700, color: "#5f6064"}}>考试类型：</span>
                                                        <Radio.Group defaultValue="a" buttonStyle="solid" style={{marginLeft: "35px"}} >
                                                            <Radio.Button value="a">同步练习</Radio.Button>
                                                            <Radio.Button value="b">单元测试</Radio.Button>
                                                            <Radio.Button value="c">月考试卷</Radio.Button>
                                                            <Radio.Button value="d">期中考试</Radio.Button>
                                                            <Radio.Button value="e">期末考试</Radio.Button>
                                                            <Radio.Button value="f">入学测验</Radio.Button>
                                                            <Radio.Button value="g">模拟题</Radio.Button>
                                                            <Radio.Button value="h">其他题型</Radio.Button>
                                                        </Radio.Group>
                                                    </Descriptions.Item>
                                                </Descriptions>
                                            </Card>
                                            <Card bordered={false} >
                                                <span style={{fontWeight: 700, color: "#5f6064"}}>考试场次：</span>
                                                <Card>
                                                    <div style={{ borderBottom: '1px solid #E9E9E9' }}>
                                                    <Checkbox
                                                        indeterminate={this.state.indeterminate}
                                                        onChange={this.onCheckAllChange}
                                                        checked={this.state.checkAll}
                                                    >
                                                        全选
                                                    </Checkbox>
                                                    </div>
                                                    <CheckboxGroup
                                                        options={plainOptions}
                                                        value={this.state.checkedList}
                                                        onChange={this.changeSelect}
                                                    />
                                                </Card>
                                            </Card>
                                        </Modal>
                                </Descriptions.Item>
                            </Descriptions>
                        </Card>
                        <Card bordered={false} style={{borderBottom: "1px dashed #ccc"}}>
                            <Descriptions column={1}>
                                <Descriptions.Item><span style={{fontWeight: 700, color: "#5f6064"}}>得分率范围：</span>
                                    <Radio.Group defaultValue="a" buttonStyle="solid" style={{marginLeft: "20px"}} >
                                        <Radio.Button value="a">0%-20%</Radio.Button>
                                        <Radio.Button value="b">20%-40%</Radio.Button>
                                        <Radio.Button value="c">40%-60%</Radio.Button>
                                        <Radio.Button value="d">60%-80%</Radio.Button>
                                        <Radio.Button value="e">80%-100%</Radio.Button>
                                        <Radio.Button value="f">自定义</Radio.Button>
                                        <Input style={{width: "50px", marginLeft: "50px"}} />
                                        <span style={{marginLeft: "5px"}}>%</span> - <Input style={{width: "50px"}} /><span style={{marginLeft: "5px"}}>%</span>
                                    </Radio.Group>
                                </Descriptions.Item>
                            </Descriptions>
                        </Card>
                        <Card bordered={false} style={{borderBottom: "1px dashed #ccc"}}>
                            <Descriptions column={1}>
                                <Descriptions.Item><span style={{fontWeight: 700, color: "#5f6064"}}>试题数量：</span>
                                    <Radio.Group defaultValue="a" buttonStyle="solid" style={{marginLeft: "20px"}}>
                                        <Input  style={{width: "50px", marginLeft: "15px"}} /><span style={{marginLeft: "5px"}}>题</span>
                                    </Radio.Group>
                                </Descriptions.Item>
                            </Descriptions>
                        </Card>
                        <Card bordered={false} >
                            <Descriptions column={2}>
                                <Descriptions.Item><span style={{fontWeight: 700, color: "#5f6064"}}>得分率排序：</span>
                                    <Radio.Group defaultValue="a" buttonStyle="solid" style={{marginLeft: "20px"}}>
                                        <Radio.Button value="a">从低到高</Radio.Button>
                                        <Radio.Button value="b">从高到低</Radio.Button>
                                    </Radio.Group>
                                </Descriptions.Item>
                                <Descriptions.Item><span style={{fontWeight: 700, color: "#5f6064"}}>训练模式：</span>
                                    <Radio.Group defaultValue="a" buttonStyle="solid" style={{marginLeft: "20px"}}>
                                        <Radio.Button value="a">错题重做</Radio.Button>
                                        <Radio.Button value="b">错题扩展</Radio.Button>
                                    </Radio.Group>
                                </Descriptions.Item>
                            </Descriptions>
                        </Card>
                        <Button style={{height: "40px", width: "120px", float: "right",  marginRight: "50px", marginBottom: "20px",}} type="primary">生成试卷</Button>
                    </TabPane>
                    <TabPane tab="薄弱项训练" key="2">
                        <Card>
                            <Card bordered={false} style={{borderBottom: "1px dashed #ccc", height: "100px"}}>
                                <Descriptions column={1}>
                                    <Descriptions.Item><span style={{fontWeight: 700, color: "#5f6064"}}>年级或班级：</span>
                                        <Radio.Group defaultValue="a" buttonStyle="solid" style={{marginLeft: "20px"}}>
                                            <Radio.Button value="a" style={{marginRight: "50px"}}>全部</Radio.Button>
                                        </Radio.Group>
                                    </Descriptions.Item>
                                </Descriptions>
                            </Card>
                            <Card bordered={false} style={{borderBottom: "1px dashed #ccc"}}>
                                <Descriptions column={1}>
                                    <Descriptions.Item><span style={{fontWeight: 700, color: "#5f6064"}}>统计时间段：</span>
                                        <Radio.Group defaultValue="a" buttonStyle="solid" style={{marginLeft: "20px"}} >
                                            <Radio.Button value="a">近一周</Radio.Button>
                                            <Radio.Button value="b">近一个月</Radio.Button>
                                            <Radio.Button value="c">近两个月</Radio.Button>
                                            <Radio.Button value="d">近半年</Radio.Button>
                                        </Radio.Group>
                                    </Descriptions.Item>
                                </Descriptions>
                            </Card>
                            <Card bordered={false} style={{borderBottom: "1px dashed #ccc"}}>
                                <Descriptions column={1}>
                                    <Descriptions.Item><span style={{fontWeight: 700, color: "#5f6064"}}>得分率范围：</span>
                                        <Radio.Group defaultValue="a" buttonStyle="solid" style={{marginLeft: "20px"}} >
                                            <Radio.Button value="a">0%-20%</Radio.Button>
                                            <Radio.Button value="b">20%-40%</Radio.Button>
                                            <Radio.Button value="c">40%-60%</Radio.Button>
                                            <Radio.Button value="d">60%-80%</Radio.Button>
                                            <Radio.Button value="e">80%-100%</Radio.Button>
                                            <Radio.Button value="f">自定义</Radio.Button>
                                            <Input style={{width: "50px", marginLeft: "50px"}} />
                                            <span style={{marginLeft: "5px"}}>%</span> - <Input style={{width: "50px"}} /><span style={{marginLeft: "5px"}}>%</span>
                                        </Radio.Group>
                                    </Descriptions.Item>
                                </Descriptions>
                            </Card>
                            <Card bordered={false}>
                                <Descriptions column={1}>
                                    <Descriptions.Item><span style={{fontWeight: 700, color: "#5f6064"}}>得分率排序：</span>
                                        <Radio.Group defaultValue="a" buttonStyle="solid" style={{marginLeft: "20px"}}>
                                            <Radio.Button value="a">从低到高</Radio.Button>
                                            <Radio.Button value="b">从高到低</Radio.Button>
                                        </Radio.Group>
                                    </Descriptions.Item>
                                </Descriptions>
                            </Card>
                        </Card>
                            <Card  style={{marginTop: "20px"}}>
                                <Descriptions column={1}>
                                    <Descriptions.Item>
                                        <Radio.Group defaultValue="a" buttonStyle="solid" style={{marginLeft: "20px"}} >
                                            <Radio.Button value="a">三角形的中线、高线、角平分线</Radio.Button>
                                            <Radio.Button value="b">三角形内角和</Radio.Button>
                                            <Radio.Button value="c">三角形内角和</Radio.Button>
                                            <Radio.Button value="d">三角形内角和</Radio.Button>
                                            <Radio.Button value="f" onClick={this.showModal2}>自定义</Radio.Button>
                                            <div>
                                                <Modal
                                                title="自定义试卷题型题量"
                                                visible={this.state.visible2}
                                                onOk={this.handleOk}
                                                onCancel={this.handleCancel}
                                                >
                                                <Row style={{borderBottom: "1px dashed #ccc", textAlign: "center"}}>
                                                    <Col span={12}>
                                                        <Card bordered={false}>
                                                            <span style={{width: 100}}>书写</span>
                                                            <Button style={{marginLeft: 20}}>－</Button>
                                                            <Input style={{width: 100, marginLeft: "20px", marginRight: "20px"}} />
                                                            <Button>＋</Button>
                                                        </Card>
                                                    </Col>
                                                    <Col span={12}>
                                                        <Card bordered={false}>
                                                            <span>选择题</span>
                                                            <Button style={{marginLeft: 20}}>－</Button>
                                                            <Input style={{width: 100, marginLeft: "20px", marginRight: "20px"}} />
                                                            <Button>＋</Button>
                                                        </Card>
                                                    </Col>
                                                </Row>
                                                <Row style={{borderBottom: "1px dashed #ccc", textAlign: "center"}}>
                                                    <Col span={12}>
                                                        <Card bordered={false}>
                                                            <span>作文</span>
                                                            <Button style={{marginLeft: 20}}>－</Button>
                                                            <Input style={{width: 100, marginLeft: "20px", marginRight: "20px"}} />
                                                            <Button>＋</Button>
                                                        </Card>
                                                    </Col>
                                                    <Col span={12}>
                                                        <Card bordered={false}>
                                                            <span>名著导读</span>
                                                            <Button style={{marginLeft: 20}}>－</Button>
                                                            <Input style={{width: 100, marginLeft: "20px", marginRight: "20px"}} />
                                                            <Button>＋</Button>
                                                        </Card>
                                                    </Col>
                                                </Row>
                                                <Row style={{borderBottom: "1px dashed #ccc", textAlign: "center"}}>
                                                    <Col span={12}>
                                                        <Card bordered={false}>
                                                            <span>语言表达</span>
                                                            <Button style={{marginLeft: 20}}>－</Button>
                                                            <Input style={{width: 100, marginLeft: "20px", marginRight: "20px"}} />
                                                            <Button>＋</Button>
                                                        </Card>
                                                    </Col>
                                                    <Col span={12}>
                                                        <Card bordered={false}>
                                                            <span>诗歌鉴赏</span>
                                                            <Button style={{marginLeft: 20}}>－</Button>
                                                            <Input style={{width: 100, marginLeft: "20px", marginRight: "20px"}} />
                                                            <Button>＋</Button>
                                                        </Card>
                                                    </Col>
                                                </Row>
                                                <Row style={{borderBottom: "1px dashed #ccc", textAlign: "center"}}>
                                                    <Col span={12}>
                                                        <Card bordered={false}>
                                                            <span>文言文阅读</span>
                                                            <Button style={{marginLeft: 20}}>－</Button>
                                                            <Input style={{width: 100, marginLeft: "20px", marginRight: "20px"}} />
                                                            <Button>＋</Button>
                                                        </Card>
                                                    </Col>
                                                    <Col span={12}>
                                                        <Card bordered={false}>
                                                            <span>现代文阅读</span>
                                                            <Button style={{marginLeft: 20}}>－</Button>
                                                            <Input style={{width: 100, marginLeft: "20px", marginRight: "20px"}} />
                                                            <Button>＋</Button>
                                                        </Card>
                                                    </Col>
                                                </Row>
                                                <Checkbox onChange={saveTemplate}>保存为试卷模板</Checkbox>
                                                <span>如未勾选，以上题型题量设置，仅供本次使用</span>
                                                </Modal>
                                            </div>
                                        </Radio.Group>
                                    </Descriptions.Item>
                                </Descriptions>
                            </Card>
                        <Card style={{marginTop: "20px", width: 200, height: 200}}>
                            <Dragger {...props}>
                                <p className="ant-upload-drag-icon">
                                <Icon type="inbox" />
                                </p>
                                <p className="ant-upload-text">点击或者拖拽上传</p>
                                <p className="ant-upload-hint">
                                    支持单个或批量上传
                                </p>
                            </Dragger>
                               
                        </Card>
                        <Button style={{height: "40px", width: "120px", float: "right",  marginRight: "50px", marginBottom: "20px",}} type="primary">生成试卷</Button>
                    </TabPane>
                </Tabs>
                </div>
                </Content>
                <Footer style={{ textAlign: 'center', backgroundColor: "#f3faff" }}></Footer>
            </Layout>
        )
    }
}
