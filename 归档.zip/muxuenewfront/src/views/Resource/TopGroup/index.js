import React, { Component } from 'react'
import { Tabs, Layout, Card, Descriptions, Radio, Input, Pagination, Empty } from 'antd'

const { TabPane } = Tabs
const { Content, Footer } = Layout
const { Search } = Input

// 改变选中标签页返回函数
function callback(key) {
    console.log(key)
}

export default class TopGroup extends Component {

    render() {
        return (
            <Layout className="layout">
                <Content style={{ padding: '0 15%', backgroundColor: "#f3faff" }}>
                <div style={{ background: '#fff', margin: 24, minHeight: 280}}>
                <Card style={{ marginLeft: "20px", marginRight: "20px"}} bordered={false}>
                    <Search onSearch={value => console.log(value)} enterButton style={{ width: 300, float:"right"}} placeholder="支持题干搜索" />
                </Card>
                <Tabs defaultActiveKey="1" onChange={callback} style={{marginLeft: "40px", marginRight: "40px"}}>
                    <TabPane tab="全部" key="1">
                    <Card  bordered={false}>
                    <Descriptions column={1}>
                        <Descriptions.Item><span style={{fontWeight: 700, color: "#5f6064"}}>年级：</span>
                            <Radio.Group defaultValue="a" buttonStyle="solid" style={{marginLeft: "20px"}}>
                                <Radio.Button value="a" style={{marginRight: "20px"}}>全部</Radio.Button>
                                <Radio.Button value="b" style={{marginRight: "20px"}}>七年级</Radio.Button>
                                <Radio.Button value="c" style={{marginRight: "20px"}}>八年级</Radio.Button>
                                <Radio.Button value="d" style={{marginRight: "20px"}}>九年级</Radio.Button>
                            </Radio.Group>
                        </Descriptions.Item>
                        <Descriptions.Item><span style={{fontWeight: 700, color: "#5f6064"}}>年份：</span>
                            <Radio.Group defaultValue="a" buttonStyle="solid" style={{marginLeft: "20px"}}>
                                <Radio.Button value="a" style={{marginRight: "20px"}}>全部</Radio.Button>
                                <Radio.Button value="b" style={{marginRight: "20px"}}>2018</Radio.Button>
                                <Radio.Button value="c" style={{marginRight: "20px"}}>2017</Radio.Button>
                                <Radio.Button value="d" style={{marginRight: "20px"}}>2016</Radio.Button>
                                <Radio.Button value="e" style={{marginRight: "20px"}}>更早</Radio.Button>
                            </Radio.Group>
                        </Descriptions.Item>
                        <Descriptions.Item><span style={{fontWeight: 700, color: "#5f6064"}}>类型：</span>
                            <Radio.Group defaultValue="a" buttonStyle="solid" style={{marginLeft: "20px"}}>
                                <Radio.Button value="a" style={{marginRight: "20px"}}>全部</Radio.Button>
                                <Radio.Button value="b" style={{marginRight: "20px"}}>历年真题</Radio.Button>
                                <Radio.Button value="c" style={{marginRight: "20px"}}>模拟题</Radio.Button>
                                <Radio.Button value="d" style={{marginRight: "20px"}}>入学测试</Radio.Button>
                                <Radio.Button value="e" style={{marginRight: "20px"}}>期末测试</Radio.Button>
                                <Radio.Button value="f" style={{marginRight: "20px"}}>月考试卷</Radio.Button>
                                <Radio.Button value="g" style={{marginRight: "20px"}}>单元测试</Radio.Button>
                            </Radio.Group>
                        </Descriptions.Item>
                        <Descriptions.Item><span style={{fontWeight: 700, color: "#5f6064"}}>区域：</span>
                            <Radio.Group defaultValue="a" buttonStyle="solid" style={{marginLeft: "20px"}}>
                                <Radio.Button value="a" style={{marginRight: "20px"}}>全部</Radio.Button>
                                <Radio.Button value="b" style={{marginRight: "20px"}}>本省</Radio.Button>
                                <Radio.Button value="c" style={{marginRight: "20px"}}>全国</Radio.Button>
                            </Radio.Group>
                        </Descriptions.Item>
                    </Descriptions>
                    </Card>
                    <Card bordered={false}>
                        <Pagination simple defaultCurrent={1} total={50} style={{float: "right"}} />
                    </Card>
                    <Empty />
                    </TabPane>

                    <TabPane tab="全部题目" key="2">
                        待开发
                    </TabPane>
                </Tabs>
                </div>
                </Content>
                <Footer style={{ textAlign: 'center', backgroundColor: "#f3faff" }}></Footer>
            </Layout>
        )
    }
}
