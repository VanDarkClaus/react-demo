import React, { Component } from 'react'
import { paperPreview, savePaper, testPaperList, downLoadPaper, analysisPaperPreview, questionLists } from '../../../requests'
import { Layout, Card, Button, Select, DatePicker , Modal, List, Row, Col, Table, Icon, Tabs, Radio, Spin, Input, Tag, Avatar } from 'antd'
import 'echarts/lib/chart/pie'
import ReactEcharts from 'echarts-for-react'
import './paperPreview.less'

import {render} from 'react-dom';
import {sortableContainer, sortableElement} from 'react-sortable-hoc';
import arrayMove from 'array-move';
import Item from 'antd/lib/list/Item';

const IconText = ({ type, text }) => (
  <span>
    <Icon type={type} style={{ marginRight: 8 }} />
    {text}
  </span>
);

// 试题拖拽
const SortableItem = sortableElement(({value}) => <div>{value}</div>);

const SortableContainer = sortableContainer(({children}) => {
  return <div>{children}</div>;
});

const { Content, Footer, Sider } = Layout
const { TabPane } = Tabs

function callback(key) {
  console.log(key);
}

class PaperPreview extends Component {

    constructor() {
        super()
        this.state = {
            testList: [], // 添加试题
            titleValue: '2019年第一学期期末考试试卷', // 试卷题目
            textSubtitle: '模拟考试', 
            inputValue: 0, // 分数
            visible1: false, // 保存试卷模态框
            visible2: false, // 试卷分析模态框
            visible3: false, // 试题编辑模态框
            visible4: false, // 试题编辑-换题模态框
            paper_id: 0, // 下载试卷id
            isToggleOn: '',
            display: 'none',
            contentList: [], // 所有题的列表
            items: ['Item 1', 'Item 2', 'Item 3', 'Item 4', 'Item 5', 'Item 6'],
            questionList: [],
            arr: [],
            diff_list:[], // 试题分析困难度
            know_list:[], // 试题分析知识点
            type_list:[], // 试题分析类型
            grade_index: '', // 年级科目
            questionContent: [], // 更换试题列表
        }
    }

      // 模态框数据可视化展示
      getOption = () => {
        let option = {
        tooltip: {
            trigger: 'item',
            formatter: "{a} <br/>{b}: {c} ({d}%)"
        },
        legend: {
            orient: 'vertical',
            data:['容易', '较易', '一般', '较难', '困难'],
            right: 50
        },
        series: [
            {
                name:'难度',
                type:'pie',
                radius: ['50%', '70%'],
                avoidLabelOverlap: false,
                label: {
                    normal: {
                        show: false,
                        position: 'center'
                    },
                    emphasis: {
                        show: true,
                        textStyle: {
                            fontSize: '20',
                            fontWeight: 'bold'
                        }
                    }
                },
                labelLine: {
                    normal: {
                        show: false
                    }
                },
                data: this.state.diff_list
            }
        ]
    }
        return option
    }

    // 列
    columns = [
        {
            title: '题型',
            dataIndex: 'name'
        },
        {
            title: '题量',
            dataIndex: 'count'
            
        },
        {
            title: '分值',
            dataIndex: 'score'
        },
        {
            title: '分值占比%',
            dataIndex: 'rate'
        },
    ]
    
    // 拖拽试题
    onSortEnd = ({oldIndex, newIndex, collection}) => {
      this.setState(({questionList}) => {
        const newCollections = [...questionList];
        newCollections[collection] = arrayMove(
          questionList[collection],
          oldIndex,
          newIndex,
        );
        return {questionList: newCollections};
      });
    };

    componentDidMount(){
      paperPreview(this.props.location.state ? this.props.location.state.garde_id : '')
        .then(resp => {
          console.log(resp)
          this.setState({
            testList: resp.body.content_list,
            questionList: resp.body.content_list?resp.body.content_list.map(item => {
              return item.qt_list
            }) : [],
            titleValue: resp.body.title ? resp.body.title : '2019年第一学期期末考试试卷',
            textSubtitle: resp.body.subtitle ? resp.body.subtitle : '模拟考试',
            grade_index: this.state.grade_index
          })
          sessionStorage.setItem('testList', JSON.stringify(this.state.testList))
          sessionStorage.setItem('questionList', JSON.stringify(this.state.questionList))
        })
    }

    // 修改得分
    handleChangeScore = (e) => {
      this.setState({
        inputValue: e.target.value
      })
    }

    
    // 保存试卷模态框
    showModal1 = (content) => {
      console.log(content)
      if(this.state.testList){
        this.state.testList.map((item, index) =>{
        this.state.testList[index] = {
          ...this.state.testList[index],
          qt_list:this.state.questionList[index]
        }
      })}
        
      savePaper(this.state.titleValue, content,this.props.match.params.id, this.state.testList, this.state.textSubtitle)
        .then(resp => {
          if(resp.code === 200) {
            this.setState({
              visible1: true,
            });
            this.setState({
              paper_id: resp.body,
            })
          }
        })
    };
  
    handleOk1 = e => {
      console.log(e);
      this.setState({
        visible1: false,
      });
    };
  
    handleCancel1 = e => {
      console.log(e);
      this.setState({
        visible1: false,
      });
    };


    // 试卷分析模态框
    showModal2 = () => {
      this.setState({
        visible2: true,
      });
      analysisPaperPreview(this.props.location.state ? this.props.location.state.garde_id : '')
        .then(resp => {
          console.log(resp)
          this.setState({
            diff_list: resp.body.diff_list,
            know_list: resp.body.know_list,
            type_list: resp.body.type_list
          })
          this.setState({
            diff_list: this.state.diff_list.map((item => {
              return {
                value: item.rate,
                name: item.name
              }
            }))
          })
        })
    };
  
    handleOk2 = e => {
      console.log(e);
      this.setState({
        visible2: false,
      });
    };
  
    handleCancel2 = e => {
      console.log(e);
      this.setState({
        visible2: false,
      });
    };

    // 试题编辑模态框
    showModal3 = (index) => {
      this.setState({
        visible3: true,
        index: index
      }, () => {
        console.log(this.state.index)
      });
      
    };
    // 替换试题
    // changeQuestion = (item, id, index) => {
    //   console.log(this.state.questionList)
    //   console.log(item, id, index)
    //   // this.setState({
    //   //   questionList: this.state.questionList.push(item)
    //   // }, () => {
    //   //   console.log(this.state.questionList)
    //   // })
    //   this.setState({
    //     questionList: this.state.questionList.map(items => items.filter(i => i.id !== this.state.index)),
    //   }, () => {
    //     console.log(this.state.questionList)
    //   })
    // }

    // 删除试题
    deleteQuestion = (item, id, index) => {
      console.log(this.state.questionList)
      console.log(item, id, index)
      // this.setState({
      //   questionList: this.state.questionList.push(item)
      // }, () => {
      //   console.log(this.state.questionList)
      // })
      this.setState({
        questionList: this.state.questionList.map(items => items.filter(i => i.id !== this.state.index)),
        visible3: false
      }, () => {
        console.log(this.state.questionList)
      })
    }
  
    handleOk3 = e => {
      console.log(e);
      this.setState({
        visible3: false,
      });
    };
  
    handleCancel3 = e => {
      console.log(e);
      this.setState({
        visible3: false,
      });
    };

        

    // 更换试题 试题更换模态框
    showModal4 = () => {
      this.setState({
        visible3: false,
        visible4: true,
      });
      const str = this.props.location.pathname
      const q = str.lastIndexOf("\/");  
      const index  = str.substring(q + 1);
      questionLists(this.props.location.state ? this.props.location.state.garde_id : index)
        .then(resp => {
          console.log(resp)
          this.setState({
            questionContent: resp.body.content
          })
      })
    };
  
    handleOk4 = e => {
      console.log(e);
      this.setState({
        visible4: false,
      });
    };
  
    handleCancel4 = e => {
      console.log(e);
      this.setState({
        visible4: false,
      });
    };

  
 
    // 下载试卷
    downloadPaperHandler = () => {
      downLoadPaper(this.state.paper_id) 
        .then(resp => {
          console.log(resp)
          if (!resp) {
            return
          }
          let url = window.URL.createObjectURL(new Blob([resp]))
          let link = document.createElement('a')
          link.style.display = 'none'
          link.href = url
          link.setAttribute('download', '考试.doc')
          document.body.appendChild(link)
          link.click()
        })
    }

    // 试题下面操作是否显示
    textFooterHandler = (id) => {
      if(this.state.display === 'none') {
        if(id === this.state.isToggleOn) {
          this.setState({
            display: 'block'
          })
        }
      }
      if( this.state.display === 'block') {
        if(id === this.state.isToggleOn) {
          this.setState({
            display: 'none'
          })
        }
      }
    }
  

    // 重新匹配
    rematchHandler = () => {
      paperPreview(this.props.location.state?this.props.location.state.garde_id:'')
        .then(resp => {
          if(resp.code === 200) {
            this.setState({
              testList: JSON.parse(sessionStorage.getItem('testList')),
              questionList: JSON.parse(sessionStorage.getItem('questionList'))
            })
          }
        })
    }

    render() {
        return (
            <Layout className="layout">
                <Content style={{  backgroundColor: "#f3faff" }}>
                <div style={{ background: '#fff', margin: 24, minHeight: 280}}>
                   <Card title="试卷预览" bordered={false} extra={<Button.Group >
                    <Button type="primary" onClick={this.showModal2}>
                      试卷分析
                    </Button>

                    <Modal
                      title="试卷分析"
                      visible={this.state.visible2}
                      onOk={this.handleOk2}
                      onCancel={this.handleCancel2}
                      width={1000}
                      footer={false}
                      >
                        <Row gutter={16} style={{height: 400}}>
                        <Col span={12}>
                            <Card title="总体分布分析" bordered={false}>
                                <Table dataSource={this.state.type_list} columns={this.columns} rowKey="name"  pagination={{ pageSize: 3 }}>
                                </Table>
                            </Card>
                        </Col>
                        <Col span={12}>
                            <ReactEcharts option={this.getOption()}/>
                        </Col>
                        </Row>
                        <div>
                          <p>知识点分析</p>
                            <table style={{border: "1", cellpadding: "0", cellspacing: "0", width:"100%", textAlign: "center"}}>
                              <thead>
                                <tr style={{border:"1px solid #ccc"}}>
                                  <th style={{border:"1px solid #ccc"}}>序号</th>
                                  <th style={{border:"1px solid #ccc"}}>知识点</th>
                                  <th style={{border:"1px solid #ccc"}}>分值</th>
                                  <th style={{border:"1px solid #ccc"}}>分值占比</th>
                                  <th style={{border:"1px solid #ccc"}}>对应题号</th>
                                </tr>
                              </thead>
                            <tbody>
                                {
                                  this.state.know_list.map((prod, index) => {
                                    return (
                                      <tr style={{border:"1px solid #ccc"}} key={prod.name}>
                                          <td style={{border:"1px solid #ccc"}}>{index+1}</td>
                                          <td style={{border:"1px solid #ccc"}}>{prod.name}</td>
                                          <td style={{border:"1px solid #ccc"}}>{prod.score}</td>
                                          <td style={{border:"1px solid #ccc"}}>{prod.rate}</td>
                                          <td style={{border:"1px solid #ccc"}}>{prod.list.join()}</td>
                                      </tr>
                                    )
                                  })
                                }
                            </tbody>
                          </table>
                        </div>
                    </Modal>

                    <Button type="primary" onClick={this.rematchHandler}>
                      重新匹配
                    </Button>
                    <Button type="primary" onClick={()=>{
                    this.showModal1(document.querySelector(".content").outerHTML)
                  }}>
                      保存试卷
                    </Button>
                    <Modal
                      title="温馨提示"
                      visible={this.state.visible1}
                      onOk={this.handleOk1}
                      onCancel={this.handleCancel1}
                      footer={false}
                    >
                      <p>亲爱的老师，您的试卷已保存，您可以选择</p >
                      <div style={{width: "100%", display: "flex", justifyContent: "space-around"}} >
                      <Button onClick={this.downloadPaperHandler}>下载试卷</Button>
                      <Button onClick={
                        () => {
                            return(
                                this.props.history.push(`/admin/resource/qualitygroup/answersheet/${this.state.paper_id}`)
                            )
                        }
                    }>下载答题卡</Button>
                      
                      <Button>继续组卷</Button>
                      <Button>分享校库</Button>
                      </div>
                    </Modal>
                    <Button type="primary" onClick={
                        () => {
                            return(
                                this.props.history.push(`/admin/resource/qualitygroup`)
                            )
                        }
                    }>
                      关闭
                    </Button>
                  </Button.Group>}>
                  <Card  bordered={false} style={{marginLeft: "25px", marginRight: "25px", width: 800, margin: "0 auto"}}>
                    <div className="content">
                    <div >
                      <h2 className="textTitle" style={{border: 0, width: "100%", textAlign:"center", fontSize: 30}}>{this.state.titleValue}</h2>
                      <p style={{border: 0, width: "100%", textAlign:"center"}}>{this.state.textSubtitle}</p >
                      <div style={{ width: "100%", textAlign:"center", fontWeight: 900}}>
                        <span>学校：_____________</span>
                        <span>姓名：_____________</span>
                        <span>班级：_____________</span>
                        <span>考号：_____________</span>
                      </div>
                      <div>
                        <table style={{borderTop: "1px solid #000000", borderLeft:" 1px solid #000000", textAlign: "center", cellspacing: "0", width: "100%", fontSize: 15, marginTop:20 ,borderCollapse: "collapse"}}>
                          <thead>
                              <tr >
                                <th style={{borderBottom: "1px solid #000000", borderRight: "1px solid #000000"}}>题号</th>
                                {
                                  this.state.testList?this.state.testList.map((item,index) => {
                                    return (
                                      <th key={index} style={{borderBottom: "1px solid #000000", borderRight: "1px solid #000000"}}>{item.qt_index}</th>
                                    )
                                  }):''
                                }
                                <th style={{borderBottom: "1px solid #000000", borderRight: "1px solid #000000"}}>总分</th>
                              </tr>
                          </thead>
                          <tbody>
                              <tr >
                                <td style={{borderBottom: "1px solid #000000", borderRight: "1px solid #000000"}}>得分</td>
                                {
                                  this.state.testList?this.state.testList.map((item,index) => {
                                    return (
                                      <td key={index} style={{borderBottom: "1px solid #000000", borderRight: "1px solid #000000"}}></td>
                                    )
                                  }):''
                                }
                                <td style={{borderBottom: "1px solid #000000", borderRight: "1px solid #000000"}}></td>
                              </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                    <div className="questions" style={{marginTop: 30}}>
                      <SortableContainer onSortEnd={this.onSortEnd} >
                        {this.state.questionList.map((items, index) => (
                          <React.Fragment key={index}  >
                            <strong>{
                              this.state.questionList[index][0].qt_index + '、' +  this.state.questionList[index][0].qt_name+ '(本大题共' + items.length + '题，共' +  items.map(i => i.score).reduce(function(prev, curr, idx, arr){
                                return prev + curr;
                              }) + '分)'
                            }</strong>
                            <div style={{marginLeft: 15}}>
                              {
                                items.map((item, i) => (
                                  <div key={i}>
                                    <h4 style={{position:'absolute'}}>{(i + 1) + '.'} </h4>
                                    <div style={{marginLeft: 20}}>
                                    <SortableItem
                                      key={item.id}
                                      value={<div style={{marginLeft: 10,marginTop: 20, marginBottom:20}} dangerouslySetInnerHTML = {{__html: item.title }}></div>}
                                      index={i}
                                      collection={index}
                                    />
                                    </div>
                                  </div>
                              ))}
                            </div>
                          </React.Fragment>
                        ))}
                      </SortableContainer>
                      </div>
                    </div>
                    </Card>
                   </Card>
                </div>
         
                </Content>
                <div style={{ background: '#fff',  minHeight: 280}}>
                <Sider width={350} style={{ background: "#fff" }}>
                  <Tabs defaultActiveKey="2" onChange={callback}>
                    <TabPane tab="编辑" key="1" >
                    <div style={{border: '1px dashed #ccc', width: '80%', margin: '0 auto', borderRadius: '10px'}}>
                      <div style={{padding: 10}}>
                      <Tag color="#2db7f5" style={{marginBottom: 10}}>试卷标题</Tag>
                        <div style={{textAlign: "center"}}>
                          <Input style={{width: '90%', margin: '0 auto'}} placeholder={this.state.titleValue}  onChange={
                            (e) => {
                              this.setState({
                                titleValue: e.target.value
                              })
                            }
                          } />
                        </div>
                      </div>
                        <div style={{padding: 10}}>
                          <Tag color="#2db7f5" style={{marginBottom: 10, marginTop: 20}}>试卷副标题</Tag>
                          <div style={{textAlign: "center"}}>
                          <Input style={{width: '90%', margin: '0 auto'}} placeholder={this.state.textSubtitle}  onChange={
                            (e) => {
                              this.setState({
                                textSubtitle: e.target.value
                              })
                            }
                          } />
                          </div>
                        </div>
                      </div>
                    </TabPane>
                    <TabPane tab="题目顺序" key="2">
                      <div>
                        <p style={{textAlign: 'center',color: "#ccc"}}>通过拖动试题调整顺序</p >
                        <SortableContainer onSortEnd={this.onSortEnd} >
                        {this.state.questionList.map((items, index) => (
                          <div style={{border: '1px dashed #ccc', margin: 30, borderRadius: 10}} key={index}>
                            <React.Fragment key={index}  >
                            <Tag color="#2db7f5" style={{marginTop: 10, marginLeft: 10}}>{
                              this.state.questionList[index][0].qt_index + '、' +  this.state.questionList[index][0].qt_name 
                            }</Tag>
                            <div style={{marginLeft: 15}}>
                              {
                                items.map((item, i) => (
                                  <div key={i}>
                                    <div style={{marginLeft: 20}}>
                                    <SortableItem
                                      key={item.id}
                                      value={
                                        <div style={{display: 'flex', justifyContent: 'space-around', alignItems: 'center'}}>
                                          <div style={{border: '1px solid #ccc', width: 40, textAlign:'center', marginTop: 10, marginBottom: 10, height: 40,lineHeight:2,fontSize:18}}>
                                          {i + 1}
                                          </div>
                                          {/* <Button onClick={() => {
                                            this.showModal3(item.id)
                                          }}>编辑</Button> */}
                                          <Modal
                                            title="编辑"
                                            visible={this.state.visible3}
                                            onOk={this.handleOk3}
                                            onCancel={this.handleCancel3}
                                            footer={false}
                                          >
                                            {/* <Button onClick={
                                              this.showModal4
                                            }>换题</Button> */}
                                            <Button onClick={
                                              () => {
                                                this.deleteQuestion(item.id)
                                              }
                                            }>删除</Button>
                                          </Modal>
                                        </div>
                                      }
                                      index={i}
                                      collection={index}
                                    />
                                    </div>
                                  </div>
                              ))}
                            </div>
                          </React.Fragment>
                          </div>
                        ))}
                      </SortableContainer>
                      </div>
                    </TabPane>
                    {/* <TabPane tab="试卷样式" key="3">
                      试卷样式
                    </TabPane> */}
                  </Tabs>,
                </Sider>
                </div>
                <Footer style={{ textAlign: 'center', backgroundColor: "#f3faff" }}></Footer>
                {/* 换题模态框 */}
                {/* <Modal
                  title="换题"
                  visible={this.state.visible4}
                  onOk={this.handleOk4}
                  onCancel={this.handleCancel4}
                  footer={false}
                >
                  <div >
                  <List
                    itemLayout="vertical"
                    size="default"
                    pagination={{
                      onChange: page => {
                        console.log(page);
                      },
                      pageSize: 3,
                    }}
                    dataSource={this.state.questionContent}
                    renderItem={(item, index) => (
                      <List.Item
                        key={item.title}
                      >
                        <List.Item.Meta
                        />
                        {<div style={{marginLeft: 10,marginTop: 20, marginBottom:20}} dangerouslySetInnerHTML = {{__html: item.title }}></div>}
                        <Button onClick={
                          () => {
                            this.changeQuestion(item,item.id,index)
                          }
                        }>替换</Button>
                      </List.Item>
                    )}
                  />
                  </div>
                </Modal> */}
            </Layout>
            
        )
    }
}

export default PaperPreview