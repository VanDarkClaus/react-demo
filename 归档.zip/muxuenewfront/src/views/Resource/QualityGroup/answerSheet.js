import React, { Component } from 'react'
import { Button, message, Radio, Input } from 'antd'
import {saveAnswerSheet, downLoadAnswerSheet, paperDetails} from 'requests'

export default class answerSheet extends Component {
    constructor() {
        super()
        const a = window.location.href.split('/')
        const paper_id = a[a.length - 1]
        this.state = {
            paper_id,
            value3: 2,
            tableName: '准考证号',

            testList:[],
            title: '',
            subtitle: '',
            textPage: 'A3',
            mark:2,//1手阅，2网阅
            subjNum: 2,

            tableRows: [0,1,2,3,4,5,6,7,8,9],
            tableColumns:  [0,1,2,3,4,5,6,7,8,9],
        }
    }
    componentDidMount() {
        paperDetails(this.state.paper_id)
            .then(resp => {
                console.log(resp)
                this.setState({
                    testList: resp.body,
                    title: resp.body.title,
                    subtitle: resp.body.subtitle,
                })
            })
    }
    render() {
        return (
            <>
                <div style={{display:'flex',alignItems:'center', width:'90%', margin:'auto', paddingTop:'6px',}}>
                    <div style={{ height: 150, width:'200px', border:'1px solid #dedede', borderRadius:'4px',padding:'4px 5px',background:'#fff', marginRight:'5px'  }}>
                        <p style={{ fontSize: "16px", fontWeight: 800, height: 30, lineHeight: '30px' }}>选择考号版式</p>
                        <Radio.Group  onChange={e=>{this.setState({value3: e.target.value})}} value={this.state.value3}>
                            <Radio value={1} onChange={() => {
                                this.setState({ tableName: '' })
                            }}>条形码</Radio><br></br>
                            <Radio value={2} onChange={() => {
                                this.setState({ tableName: '准考证号' })
                            }}>准考证号</Radio><br></br>
                            <Radio value={3} onChange={() => {
                                this.setState({ tableName: '学籍号' })
                            }}>学籍号</Radio>
                        </Radio.Group>
                    </div>
                    <div style={{display:this.state.tableName === ''? 'none': 'block', height: 150, width:'200px', border:'1px solid #dedede', borderRadius:'4px',padding:'4px 5px',background:'#fff',marginRight:'5px'  }}>
                        <p style={{ fontSize: "16px", fontWeight: 800, height: 30, lineHeight: '30px'}}>选择考号位数</p>
                        <Input placeholder='请输入考号位数默认10位' onChange={e => {
                            console.log(Number(e.target.value))
                            let tableColumns = []
                            for(let i=0 ;i<e.target.value;i++){
                                tableColumns[i] = i
                            }
                            this.setState({tableColumns})
                            }}></Input>
                    </div>
                    <div style={{ height: 150, width:'200px', border:'1px solid #dedede', borderRadius:'4px',padding:'4px 5px',background:'#fff', marginRight:'5px'  }}>
                        <p style={{ fontSize: "16px", fontWeight: 800, height: 30, lineHeight: '30px' }}>选择答题卡页数</p>
                        <Radio.Group  onChange={e=>{this.setState({textPage: e.target.value})}} value={this.state.textPage}>
                            <Radio value={'A4'} >单页</Radio><br></br>
                            <Radio value={'A3'} >双页</Radio><br></br>
                            {/* <Radio value={3} onChange={() => {
                                this.setState({ textPage: 3 })
                            }}>三页</Radio> */}
                        </Radio.Group>
                    </div>
                    <div style={{display:this.state.textPage === 'A4'?'none':'block', height: 150, width:'200px', border:'1px solid #dedede', borderRadius:'4px',padding:'4px 5px',background:'#fff', marginRight:'5px'  }}>
                        <p style={{ fontSize: "16px", fontWeight: 800, height: 30, lineHeight: '30px' }}>请输入第一页大题数目</p>
                        <Input value={this.state.subjNum} onChange={e=>{this.setState({subjNum:e.target.value})}}/>
                    </div>
                    <div style={{ height: 150, width:'200px', border:'1px solid #dedede', borderRadius:'4px',padding:'4px 5px',background:'#fff', marginRight:'5px'  }}>
                        <p style={{ fontSize: "16px", fontWeight: 800, height: 30, lineHeight: '30px' }}>选择阅卷模式</p>
                        <Radio.Group  onChange={e=>{this.setState({mark: e.target.value})}} value={this.state.mark}>
                            <Radio value={1}>手阅</Radio><br></br>
                            <Radio value={2}>网阅</Radio><br></br>
                            {/* <Radio value={3} onChange={() => {
                                this.setState({ textPage: 3 })
                            }}>三页</Radio> */}
                        </Radio.Group>
                    </div>
                    <div style={{  display:'flex',flexDirection:'column',height: 150, width:'200px', border:'1px solid #dedede', borderRadius:'4px',padding:'4px 5px',background:'#fff',marginRight:'5px' }}>
                        <p style={{ fontSize: "16px", fontWeight: 800, height: 30, lineHeight: '30px'}}>答题卡</p>
                        <Button type="primary" style={{margin:'2px'}} onClick={() => {
                            saveAnswerSheet(this.state.paper_id, document.querySelector('#questionLeft_h').outerHTML, this.state.textPage)
                                .then(res => {
                                    message.info(res.message)
                                })

                        }}>保存答题卡</Button>
                        <Button type="primary" style={{margin:'2px'}} onClick={() => {
                            downLoadAnswerSheet(this.state.paper_id, document.querySelector('#questionLeft_h').outerHTML,this.state.title, 1, this.state.textPage)
                              
                        }}>下载答题卡(pdf)
                            </Button>
                            <Button type="primary" style={{margin:'2px'}} onClick={() => {
                            downLoadAnswerSheet(this.state.paper_id, document.querySelector('#questionLeft_h').outerHTML,this.state.title, 0, this.state.textPage)
                              
                        }}>下载答题卡(doc)
                            </Button>
                    </div>
                   
                </div>
               <div style={{margin:'3%'}}>

                    <div id='questionLeft_h' style={{ background: '#fff',   }}>
                        <div style={{ float:'left', width: this.state.textPage === 'A4'?'90%':'50%', paddingLeft:this.state.textPage === 'A4'?'10%':'2%', display:'inline-block',boxSizing:'border-box' }}>
                            <p style={{ lineHeight: '15pt', margin: '12pt 0pt', orphans: 0, textAlign: 'center', widows: 0 }}><span style={{ fontFamily: '黑体', fontSize: '15pt', fontWeight: 'bold' }}>{this.state.title}</span></p>
                            <p style={{ lineHeight: '15pt', margin: '12pt 0pt', orphans: 0, textAlign: 'center', widows: 0 }}><span style={{ fontFamily: '黑体', fontSize: '15pt', fontWeight: 'bold' }}>{this.state.subtitle}</span></p>
                            <table cellSpacing={0} cellPadding={0} style={{ borderCollapse: 'collapse', marginLeft: '0pt',  }}>
                                <tbody >
                                    <tr>
                                        <td colSpan={6} style={{ verticalAlign: 'top' }}><p style={{ margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '宋体', fontSize: '10pt' }}>学&nbsp; 校:</span><span style={{ fontFamily: '"Times New Roman"', fontSize: '10pt' }}>_________________&nbsp; </span><span style={{ fontFamily: '宋体', fontSize: '10pt' }}>班&nbsp; 级:</span><span style={{ fontFamily: '"Times New Roman"', fontSize: '10pt' }}>_________________&nbsp; </span></p></td>
                                        <td style={{ borderRightColor: '#000000', borderRightStyle: 'solid', borderRightWidth: '0.75pt', verticalAlign: 'top' }}><p style={{ margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '宋体', fontSize: '10pt' }}>&nbsp;</span></p></td>
                                    
                                        <td rowSpan={5} style={{ borderBottomColor: '#000000', borderBottomStyle: 'solid', borderBottomWidth: '0.75pt', borderLeftColor: '#000000', borderLeftStyle: 'solid', borderLeftWidth: '0.75pt', borderRightColor: '#000000', borderRightStyle: 'solid', borderRightWidth: '0.75pt', borderTopColor: '#000000', borderTopStyle: 'solid', borderTopWidth: '0.75pt', verticalAlign: 'top' }}><p style={{ margin: '0pt', orphans: 0, textAlign: 'center', widows: 0 }}><span style={{ fontFamily: '宋体', fontSize: '10pt', fontWeight: 'bold' }}>{this.state.tableName}</span></p>
                                            <div style={{ textAlign: 'center',height:'100%' }}>
                                                {
                                                    this.state.tableName === ''?
                                                    // <div style={{margin:'0 auto', marginLeft:'20px',marginRight:'20px', border:'0.75pt solid #000', marginTop:'60pt'}}>请在此处贴上条形码</div>
                                                    <table cellSpacing={0} cellPadding={0} style={{ borderCollapse: 'collapse', margin: '0 auto' }}>
                                                        <tbody>
                                                            <tr><td>&nbsp;</td></tr>
                                                            <tr><td>&nbsp;</td></tr>
                                                            <tr><td>&nbsp;</td></tr>
                                                            <tr><td>&nbsp;</td></tr>
                                                            <tr><td>&nbsp;</td></tr>
                                                            <tr>
                                                                <td>&nbsp;</td>
                                                                <td>&nbsp;</td>
                                                                    <td>请</td>
                                                                    <td>在</td>
                                                                    <td>此</td>
                                                                    <td>处</td>
                                                                    <td>贴</td>
                                                                    <td>上</td>
                                                                    <td>条</td>
                                                                    <td>形</td>
                                                                    <td>码</td>
                                                                <td>&nbsp;</td>
                                                                <td>&nbsp;</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    :
                                                    <table cellSpacing={0} cellPadding={0} style={{ borderCollapse: 'collapse', margin: '0 auto' }}>
                                                    <tbody>
                                                        <tr style={{ height: '20pt' }}>
                                                            {
                                                                this.state.tableColumns.map(num =>{
                                                                    return(
                                                                        <td key={num+'tableone'} style={{ borderBottomColor: '#000000', borderBottomStyle: 'solid', borderBottomWidth: '0.75pt', borderLeftColor: '#000000', borderLeftStyle: 'solid', borderLeftWidth: '0.75pt', borderRightColor: '#000000', borderRightStyle: 'solid', borderRightWidth: '0.75pt', borderTopColor: '#000000', borderTopStyle: 'solid', borderTopWidth: '0.75pt', verticalAlign: 'top' }}><p style={{ margin: '0pt', orphans: 0, textAlign: 'center', widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '8pt' }}>&nbsp;</span></p></td>
                                                                    )
                                                                })
                                                            }
                                                        </tr>
                                                        {
                                                            this.state.tableRows.map(item => {
                                                                    return (
                                                                        <tr key={item + 'dad'}>
                                                                            {
                                                                                this.state.tableColumns.map(num => {
                                                                                        if(item === 9){
                                                                                            return(
                                                                                                <td key={num+'tabletwo'} style={{borderBottomColor: '#000000', borderBottomStyle: 'solid', borderBottomWidth: '0.75pt', borderLeftColor: '#000000', borderLeftStyle: 'solid', borderLeftWidth: '0.75pt', borderRightColor: '#000000', borderRightStyle: 'solid', borderRightWidth: '0.75pt', verticalAlign: 'top' }}><p style={{ lineHeight: '12pt', margin: '0pt', orphans: 0, textAlign: 'center', widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '8pt' }}> [ </span><span style={{ fontFamily: '"Times New Roman"', fontSize: '6pt' }}>{item}</span><span style={{ fontFamily: '"Times New Roman"', fontSize: '8pt' }}> ] </span></p></td>
                                                                                            )
                                                                                        } else {
                                                                                            return(
                                                                                                <td key={num+'tabletwo'} style={{ borderLeftColor: '#000000', borderLeftStyle: 'solid', borderLeftWidth: '0.75pt', borderRightColor: '#000000', borderRightStyle: 'solid', borderRightWidth: '0.75pt', verticalAlign: 'top' }}><p style={{ lineHeight: '12pt', margin: '0pt', orphans: 0, textAlign: 'center', widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '8pt' }}> [ </span><span style={{ fontFamily: '"Times New Roman"', fontSize: '6pt' }}>{item}</span><span style={{ fontFamily: '"Times New Roman"', fontSize: '8pt' }}> ] </span></p></td>
                                                                                            )
                                                                                        }
                                                                                })
                                                                            }
                                                                        </tr>
                                                                    )
                                                            })
                                                        }
                                                        
                                                    </tbody>
                                                </table>
                                            
                                                }
                                            </div><p style={{ margin: '0pt', orphans: 0, textAlign: 'center', widows: 0 }} /></td>
                                    </tr>
                                    <tr>
                                        <td colSpan={6} style={{ verticalAlign: 'top' }}><p style={{ margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '宋体', fontSize: '10pt' }}>姓&nbsp; 名:</span><span style={{ fontFamily: '"Times New Roman"', fontSize: '10pt' }}>_________________&nbsp; </span><span style={{ fontFamily: '宋体', fontSize: '10pt' }}>考&nbsp; 号:</span><span style={{ fontFamily: '"Times New Roman"', fontSize: '10pt' }}>_________________&nbsp; </span></p></td>
                                        <td style={{ borderRightColor: '#000000', borderRightStyle: 'solid', borderRightWidth: '0.75pt', verticalAlign: 'top' }}><p style={{ margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '宋体', fontSize: '10pt' }}>&nbsp;</span></p></td>
                                    </tr>
                                    <tr style={{ height: '106pt' }}>
                                        <td style={{ borderBottomColor: '#000000', borderBottomStyle: 'solid', borderBottomWidth: '0.75pt', borderLeftColor: '#000000', borderLeftStyle: 'solid', borderLeftWidth: '0.75pt', borderRightColor: '#000000', borderRightStyle: 'solid', borderRightWidth: '0.75pt', borderTopColor: '#000000', borderTopStyle: 'solid', borderTopWidth: '0.75pt', height: '106pt', verticalAlign: 'middle', writingMode: 'tb-rl' }}><p style={{ margin: '0pt 5.65pt', orphans: 0, textAlign: 'center', widows: 0 }}><span style={{ fontFamily: '宋体', fontSize: '10pt' }}>注意事项</span></p></td>
                                        <td colSpan={5} style={{ borderBottomColor: '#000000', borderBottomStyle: 'solid', borderBottomWidth: '0.75pt', borderLeftColor: '#000000', borderLeftStyle: 'solid', borderLeftWidth: '0.75pt', borderRightColor: '#000000', borderRightStyle: 'solid', borderRightWidth: '0.75pt', borderTopColor: '#000000', borderTopStyle: 'solid', borderTopWidth: '0.75pt', padding: '1.88pt 5.03pt', verticalAlign: 'middle' }}><p style={{ margin: '0pt', orphans: 0, textAlign: 'justify', widows: 0 }}><span style={{ fontFamily: '宋体', fontSize: '9pt' }}>1.答题前，务必将姓名、准考证号等信息完整填写在相应位置上，必须使用2B铅笔填涂准考证号，修改时，要用橡皮擦干净。</span></p><p style={{ margin: '0pt', orphans: 0, textAlign: 'justify', widows: 0 }}><span style={{ fontFamily: '宋体', fontSize: '9pt' }}>2.答选择题时，必须使用2B铅笔填涂答题卡上相应题目的答案标号。修改时，要用橡皮擦干净。答其他题时，必须使用0.5毫米黑色签字笔填写在答题卡对应的区域内，写在试卷上无效。</span></p><p style={{ margin: '0pt', orphans: 0, textAlign: 'justify', widows: 0 }}><span style={{ fontFamily: '宋体', fontSize: '9pt' }}>3.保证答题卡清洁完整，考试结束后，请将本试卷和答题卡一并上交。</span></p></td>
                                        <td style={{ borderLeftColor: '#000000', borderLeftStyle: 'solid', borderLeftWidth: '0.75pt', borderRightColor: '#000000', borderRightStyle: 'solid', borderRightWidth: '0.75pt', verticalAlign: 'top' }}><p style={{ margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '宋体', fontSize: '10pt' }}>&nbsp;</span></p></td>
                                    </tr>
                                    <tr style={{ height: '5.65pt' }}>
                                        <td style={{ borderBottomColor: '#000000', borderBottomStyle: 'solid', borderBottomWidth: '0.75pt', borderTopColor: '#000000', borderTopStyle: 'solid', borderTopWidth: '0.75pt', verticalAlign: 'top' }}><p style={{ margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '宋体', fontSize: '10pt' }}>&nbsp;</span></p></td>
                                        <td style={{ borderBottomColor: '#000000', borderBottomStyle: 'solid', borderBottomWidth: '0.75pt', borderTopColor: '#000000', borderTopStyle: 'solid', borderTopWidth: '0.75pt', verticalAlign: 'top' }}><p style={{ margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '宋体', fontSize: '10pt' }}>&nbsp;</span></p></td>
                                        <td style={{ borderBottomColor: '#000000', borderBottomStyle: 'solid', borderBottomWidth: '0.75pt', borderTopColor: '#000000', borderTopStyle: 'solid', borderTopWidth: '0.75pt', verticalAlign: 'top' }}><p style={{ margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '宋体', fontSize: '10pt' }}>&nbsp;</span></p></td>
                                        <td style={{ borderBottomColor: '#000000', borderBottomStyle: 'solid', borderBottomWidth: '0.75pt', borderTopColor: '#000000', borderTopStyle: 'solid', borderTopWidth: '0.75pt', verticalAlign: 'top' }}><p style={{ margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '宋体', fontSize: '10pt' }}>&nbsp;</span></p></td>
                                        <td style={{ borderBottomColor: '#000000', borderBottomStyle: 'solid', borderBottomWidth: '0.75pt', borderTopColor: '#000000', borderTopStyle: 'solid', borderTopWidth: '0.75pt', verticalAlign: 'top' }}><p style={{ margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '宋体', fontSize: '10pt' }}>&nbsp;</span></p></td>
                                        <td style={{ borderBottomColor: '#000000', borderBottomStyle: 'solid', borderBottomWidth: '0.75pt', borderTopColor: '#000000', borderTopStyle: 'solid', borderTopWidth: '0.75pt', verticalAlign: 'top' }}><p style={{ margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '宋体', fontSize: '10pt' }}>&nbsp;</span></p></td>
                                        <td style={{ borderRightColor: '#000000', borderRightStyle: 'solid', borderRightWidth: '0.75pt', verticalAlign: 'top' }}><p style={{ margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '宋体', fontSize: '10pt' }}>&nbsp;</span></p></td>
                                    </tr>
                                    <tr>
                                        <td colSpan={2} style={{ borderBottomColor: '#000000', borderBottomStyle: 'solid', borderBottomWidth: '0.75pt', borderLeftColor: '#000000', borderLeftStyle: 'solid', borderLeftWidth: '0.75pt', borderTopColor: '#000000', borderTopStyle: 'solid', borderTopWidth: '0.75pt', verticalAlign: 'top' }}><p style={{ margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '宋体', fontSize: '10pt' }}> 本栏考生禁填</span></p></td>
                                        <td style={{ borderBottomColor: '#000000', borderBottomStyle: 'solid', borderBottomWidth: '0.75pt', borderTopColor: '#000000', borderTopStyle: 'solid', borderTopWidth: '0.75pt', verticalAlign: 'middle' }}><p style={{ margin: '0pt', orphans: 0, textAlign: 'justify', widows: 0 ,display:'flex', justifyContent:'space-between', alignItems:'center'}}>
                                        
                                        <span style={{ fontFamily: '宋体', fontSize: '6pt', display:'inline-block', width:'50pt' }}>缺考标识</span>
                                        <span style={{ fontFamily: '宋体', fontSize: '6pt' }}> </span></p></td>
                                        <td style={{borderBottomColor: '#000000', borderBottomStyle: 'solid', borderBottomWidth: '0.75pt',}}>
                                        &nbsp;<span style={{display:'inline-block', border:'1pt solid #000', width:'18pt', fontSize: '8pt',textAlign:'center',lineHeight:'10pt', height:'10pt'}}>&nbsp;&nbsp;</span>&nbsp;
                                        </td>
                                        {/* <td style={{ borderBottomColor: '#000000', borderBottomStyle: 'solid', borderBottomWidth: '0.75pt', borderTopColor: '#000000', borderTopStyle: 'solid', borderTopWidth: '0.75pt', verticalAlign: 'top' }}><p style={{ margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '宋体', fontSize: '10pt' }}>&nbsp;</span></p></td> */}
                                        <td colSpan={2} style={{ borderBottomColor: '#000000', borderBottomStyle: 'solid', borderBottomWidth: '0.75pt', borderRightColor: '#000000', borderRightStyle: 'solid', borderRightWidth: '0.75pt', borderTopColor: '#000000', borderTopStyle: 'solid', borderTopWidth: '0.75pt', verticalAlign: 'middle' }}><p style={{ margin: '0pt', orphans: 0, textAlign: 'justify', widows: 0 }}><span style={{ fontFamily: '宋体', fontSize: '6pt' }}>缺考标识由监考老师用2B铅笔填涂</span></p></td>
                                        <td style={{ borderLeftColor: '#000000', borderLeftStyle: 'solid', borderLeftWidth: '0.75pt', borderRightColor: '#000000', borderRightStyle: 'solid', borderRightWidth: '0.75pt', verticalAlign: 'top' }}><p style={{ margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '宋体', fontSize: '10pt' }}>&nbsp;</span></p></td>
                                    </tr>
                                    <tr style={{ height: '0pt' }}>
                                        <td style={{ width: '27.45pt', border: 'none' }} />
                                        <td style={{ width: '54.65pt', border: 'none' }} />
                                        <td style={{ width: '27.3pt', border: 'none' }} />
                                        <td style={{ width: '27.3pt', border: 'none' }} />
                                        <td style={{ width: '103.75pt', border: 'none' }} />
                                        <td style={{ width: '103.75pt', border: 'none' }} />
                                        <td style={{ width: '10.9pt', border: 'none' }} />
                                        <td style={{ width: '191.05pt', border: 'none' }} />
                                    </tr>
                                </tbody>
                            </table>
                            <p style={{ margin: '0pt', orphans: 0, widows: 0 }}><span style={{ AwBookmarkEnd: 'student_info_netexam' }} /><span style={{ fontFamily: '宋体', fontSize: '10pt' }}>&nbsp;</span></p>

                            {
                                this.state.testList.list?this.state.textPage=='A4'?this.state.testList.list.map((item, bigNum) => {
                                    return (
                                    <table key={item.qt_index} cellSpacing={0} cellPadding={0} style={{ borderCollapse: 'collapse', marginLeft: '0pt',width:'100%', margin:'0 auto' }}>
                                        <tbody>
                                                            <tr>
                                                                <td style={{borderLeftColor: '#000000', borderLeftStyle: 'solid', borderLeftWidth: '0.75pt', borderRightColor: '#000000', borderRightStyle: 'solid',borderRightWidth: '0.75pt', borderTopColor: '#000000', borderTopStyle: 'solid', borderTopWidth: '0.75pt', verticalAlign: 'top'}}>&nbsp;</td>
                                                            </tr>
                                                            <tr style={{}}>
                                                                
                                                                <td style={{ borderLeftColor: '#000000', borderLeftStyle: 'solid', borderLeftWidth: '0.75pt', borderRightColor: '#000000', borderRightStyle: 'solid', borderRightWidth: '0.75pt', verticalAlign: 'top',  }}>
                                                                    <p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0, display:'flex', justifyContent:'space-between' }}>
                                                                        <span>

                                                                            <span style={{ fontFamily: '宋体', fontSize: '12pt', width:'300pt', }}>&nbsp;{item.qt_index}</span>
                                                                            <span style={{ fontFamily: '宋体', fontSize: '12pt', width:'300pt' }}>、{item.qt_name}（总分{item.qt_list.reduce((sum, curr) =>{return sum += curr.score},0)}分)</span>
                                                                        </span>
                                                                            {
                                                                                item.qt_list.reduce((sum, curr) =>{return sum += curr.score},0) > 10?
                                                                                <span style={{display:this.state.mark === 1?'inline-block':'none',width:'250px'}}>

                                                                                    <span style={{ width: '10px', height:'10pt',fontFamily: '"Times New Roman"', fontSize: '15pt',}}>考生禁填</span>&nbsp;
                                                                                    <span style={{border:'1px solid #000', width: '10px', height:'10pt',fontFamily: '"Times New Roman"', fontSize: '20pt',}}>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;
                                                                                    <span style={{border:'1px solid #000', width: '10px', height:'10pt',fontFamily: '"Times New Roman"', fontSize: '20pt',}}>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;
                                                                                    <span style={{border:'1px solid #000', width: '10px', height:'10pt',fontFamily: '"Times New Roman"', fontSize: '20pt',}}>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;
            
                                                                                </span>
                                                                                    :
                                                                                    <span style={{display:this.state.mark === 1?'inline-block':'none', width:'250px'}}>
                                                                                            <span style={{ width: '10px', height:'10pt',fontFamily: '"Times New Roman"', fontSize: '15pt',}}>考生禁填</span>&nbsp;
                                                                                        <span style={{border:'1px solid #000', width: '10px', height:'10pt',fontFamily: '"Times New Roman"', fontSize: '20pt',}}>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;
                                                                                        <span style={{border:'1px solid #000', width: '10px', height:'10pt',fontFamily: '"Times New Roman"', fontSize: '20pt',}}>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;
                                                                            </span>

                                                                            }
                                                                        
                                                                </p>
                                                                    {
                                                                        item.qt_list.map((topic, smallNum) => {
                                                                            if(item.qt_name === '选择题' || item.qt_name === '单项选择'){
                                                                                return  (
                                                                                    <div key={smallNum +'ccs'}>
                                                                                        <span>&nbsp;&nbsp;</span>
                                                                                        <span style={{marginRight:'10px'}}>{smallNum+1}.</span>
                                                                                        <span style={{display:'inline-block', border:'1pt solid #000', width:'18pt', fontSize: '8pt',textAlign:'center',lineHeight:'10pt', height:'10pt'}}>&nbsp;A&nbsp;</span>&nbsp;
                                                                                        <span style={{display:'inline-block', border:'1pt solid #000', width:'18pt', fontSize: '8pt',textAlign:'center',lineHeight:'10pt', height:'10pt'}}>&nbsp;B&nbsp;</span>&nbsp;
                                                                                        <span style={{display:'inline-block', border:'1pt solid #000', width:'18pt', fontSize: '8pt',textAlign:'center',lineHeight:'10pt', height:'10pt'}}>&nbsp;C&nbsp;</span>&nbsp;
                                                                                        <span style={{display:'inline-block', border:'1pt solid #000', width:'18pt', fontSize: '8pt',textAlign:'center',lineHeight:'10pt', height:'10pt'}}>&nbsp;D&nbsp;</span> 
                                                                                    </div>
                                                                                )
                                                                                    
                                                                            }else  if(item.qt_name === '简答题' || item.qt_name === '问答题') {
                                                                                return (
                                                                                    <div key={smallNum +'ccs'}>
                                                                                        <div>&nbsp;</div>
                                                                                        <div>&nbsp;</div>
                                                                                        <div>&nbsp;</div>
                                                                                        <div>&nbsp;</div>
                                                                                        <div>&nbsp;</div>
                                                                                    </div>
                                                                                )
                                                                            }else {
                                                                                return(
                                                                                    <div key={smallNum +'ccs'}>
                                                                                        <span>&nbsp;&nbsp;</span>
                                                                                        <span>{smallNum+1}.</span>
                                                                                        <span style={{color:'#000',fontSize:'24pt',fontWeight:'100'}}>_______________________&nbsp;&nbsp;&nbsp;</span>
                                                                                    </div>
                                                                                )
                                                                            }
                                                                        })
                                                                    }
                                                                </td> 
                                                                    {/* <p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, textIndent: '10.5pt', widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>2</span><span style={{ fontFamily: '宋体', fontSize: '12pt' }}>、（</span><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>2</span><span style={{ fontFamily: '宋体', fontSize: '12pt' }}>分）</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, textIndent: '10.5pt', widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>3</span><span style={{ fontFamily: '宋体', fontSize: '12pt' }}>、（</span><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>2</span><span style={{ fontFamily: '宋体', fontSize: '12pt' }}>分）</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, textIndent: '10.5pt', widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>4</span><span style={{ fontFamily: '宋体', fontSize: '12pt' }}>、（</span><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>2</span><span style={{ fontFamily: '宋体', fontSize: '12pt' }}>分）</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, textIndent: '10.5pt', widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>5</span><span style={{ fontFamily: '宋体', fontSize: '12pt' }}>、（</span><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>2</span><span style={{ fontFamily: '宋体', fontSize: '12pt' }}>分）</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p></td> */}
                                                            </tr>
                                                            <tr style={{ height: '1pt' }}>
                                                                <td style={{ borderBottomColor: '#000000', borderBottomStyle: 'solid', borderBottomWidth: '0.75pt', borderLeftColor: '#000000', borderLeftStyle: 'solid', borderLeftWidth: '0.75pt', borderRightColor: '#000000', borderRightStyle: 'solid', borderRightWidth: '0.75pt', verticalAlign: 'top' }}><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '9pt' }}>&nbsp;</span></p></td>
                                                            </tr>
                                                            <tr>
                                                                <td>&nbsp;</td>
                                                            </tr>
                                        </tbody>
                                    </table>
                                        
                                    )
                                }
                                ):'':''
                            }
                            {
                                this.state.testList.list?this.state.textPage=='A3'?this.state.testList.list.filter((item,index) => index < this.state.subjNum).map((item, bigNum) => {
                                    return (
                                    <table key={item.qt_index} cellSpacing={0} cellPadding={0} style={{ borderCollapse: 'collapse', marginLeft: '0pt',width:'100%', margin:'0 auto' }}>
                                        <tbody>
                                                            <tr>
                                                                <td style={{borderLeftColor: '#000000', borderLeftStyle: 'solid', borderLeftWidth: '0.75pt', borderRightColor: '#000000', borderRightStyle: 'solid',borderRightWidth: '0.75pt', borderTopColor: '#000000', borderTopStyle: 'solid', borderTopWidth: '0.75pt', verticalAlign: 'top'}}>&nbsp;</td>
                                                            </tr>
                                                            <tr style={{}}>
                                                                
                                                                <td style={{ borderLeftColor: '#000000', borderLeftStyle: 'solid', borderLeftWidth: '0.75pt', borderRightColor: '#000000', borderRightStyle: 'solid', borderRightWidth: '0.75pt', verticalAlign: 'top',  }}>
                                                                    <p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0, display:'flex', justifyContent:'space-between' }}>
                                                                        <span>

                                                                            <span style={{ fontFamily: '宋体', fontSize: '12pt', width:'300pt' }}>&nbsp;{item.qt_index}</span>
                                                                            <span style={{ fontFamily: '宋体', fontSize: '12pt', width:'300pt' }}>、{item.qt_name}（总分{item.qt_list.reduce((sum, curr) =>{return sum += curr.score},0)}分)</span>
                                                                        </span>
                                                                            {
                                                                                item.qt_list.reduce((sum, curr) =>{return sum += curr.score},0) > 10?
                                                                                <span style={{display:this.state.mark === 1?'inline-block':'none',width:'250px'}}>

                                                                                    <span style={{ width: '10px', height:'10pt',fontFamily: '"Times New Roman"', fontSize: '15pt',}}>考生禁填</span>&nbsp;
                                                                                    <span style={{border:'1px solid #000', width: '10px', height:'10pt',fontFamily: '"Times New Roman"', fontSize: '20pt',}}>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;
                                                                                    <span style={{border:'1px solid #000', width: '10px', height:'10pt',fontFamily: '"Times New Roman"', fontSize: '20pt',}}>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;
                                                                                    <span style={{border:'1px solid #000', width: '10px', height:'10pt',fontFamily: '"Times New Roman"', fontSize: '20pt',}}>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;
            
                                                                                </span>
                                                                                    :
                                                                                    <span style={{display:this.state.mark === 1?'inline-block':'none', width:'250px'}}>
                                                                                            <span style={{ width: '10px', height:'10pt',fontFamily: '"Times New Roman"', fontSize: '15pt',}}>考生禁填</span>&nbsp;
                                                                                        <span style={{border:'1px solid #000', width: '10px', height:'10pt',fontFamily: '"Times New Roman"', fontSize: '20pt',}}>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;
                                                                                        <span style={{border:'1px solid #000', width: '10px', height:'10pt',fontFamily: '"Times New Roman"', fontSize: '20pt',}}>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;
                                                                            </span>

                                                                            }
                                                                        
                                                                </p>
                                                                    {
                                                                        item.qt_list.map((topic, smallNum) => {
                                                                            if(item.qt_name === '选择题' || item.qt_name === '单项选择'){
                                                                                return  (
                                                                                    <div key={smallNum +'ccs'}>
                                                                                        <span>&nbsp;&nbsp;</span>
                                                                                        <span>{smallNum+1}.</span>
                                                                                        <span style={{display:'inline-block', border:'1pt solid #000', width:'18pt', fontSize: '8pt',textAlign:'center',lineHeight:'10pt', height:'10pt'}}>&nbsp;A&nbsp;</span>&nbsp;
                                                                                        <span style={{display:'inline-block', border:'1pt solid #000', width:'18pt', fontSize: '8pt',textAlign:'center',lineHeight:'10pt', height:'10pt'}}>&nbsp;B&nbsp;</span>&nbsp;
                                                                                        <span style={{display:'inline-block', border:'1pt solid #000', width:'18pt', fontSize: '8pt',textAlign:'center',lineHeight:'10pt', height:'10pt'}}>&nbsp;C&nbsp;</span>&nbsp;
                                                                                        <span style={{display:'inline-block', border:'1pt solid #000', width:'18pt', fontSize: '8pt',textAlign:'center',lineHeight:'10pt', height:'10pt'}}>&nbsp;D&nbsp;</span> 
                                                                                    </div>
                                                                                )
                                                                                    
                                                                            }else  if(item.qt_name === '简答题' || item.qt_name === '问答题') {
                                                                                return (
                                                                                    <div key={smallNum +'ccs'}>
                                                                                        <div>&nbsp;</div>
                                                                                        <div>&nbsp;</div>
                                                                                        <div>&nbsp;</div>
                                                                                        <div>&nbsp;</div>
                                                                                        <div>&nbsp;</div>
                                                                                    </div>
                                                                                )
                                                                            }else {
                                                                                return(
                                                                                    <div key={smallNum +'ccs'}>
                                                                                        <span>&nbsp;&nbsp;</span>
                                                                                        <span>{smallNum+1}.</span>
                                                                                        <span style={{color:'#000',fontSize:'24pt',fontWeight:'100'}}>_______________________&nbsp;&nbsp;&nbsp;</span>
                                                                                    </div>
                                                                                )
                                                                            }
                                                                        })
                                                                    }
                                                                </td> 
                                                                    {/* <p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, textIndent: '10.5pt', widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>2</span><span style={{ fontFamily: '宋体', fontSize: '12pt' }}>、（</span><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>2</span><span style={{ fontFamily: '宋体', fontSize: '12pt' }}>分）</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, textIndent: '10.5pt', widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>3</span><span style={{ fontFamily: '宋体', fontSize: '12pt' }}>、（</span><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>2</span><span style={{ fontFamily: '宋体', fontSize: '12pt' }}>分）</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, textIndent: '10.5pt', widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>4</span><span style={{ fontFamily: '宋体', fontSize: '12pt' }}>、（</span><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>2</span><span style={{ fontFamily: '宋体', fontSize: '12pt' }}>分）</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, textIndent: '10.5pt', widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>5</span><span style={{ fontFamily: '宋体', fontSize: '12pt' }}>、（</span><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>2</span><span style={{ fontFamily: '宋体', fontSize: '12pt' }}>分）</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p></td> */}
                                                            </tr>
                                                            <tr style={{ height: '1pt' }}>
                                                                <td style={{ borderBottomColor: '#000000', borderBottomStyle: 'solid', borderBottomWidth: '0.75pt', borderLeftColor: '#000000', borderLeftStyle: 'solid', borderLeftWidth: '0.75pt', borderRightColor: '#000000', borderRightStyle: 'solid', borderRightWidth: '0.75pt', verticalAlign: 'top' }}><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '9pt' }}>&nbsp;</span></p></td>
                                                            </tr>
                                                            <tr>
                                                                <td>&nbsp;</td>
                                                            </tr>
                                        </tbody>
                                    </table>
                                        
                                    )
                                }
                                ):'':''
                            }
                            <p style={{ margin: '0pt', orphans: 0, textAlign: 'justify', widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '8pt' }}>&nbsp;</span></p>
                            <p style={{ margin: '0pt', orphans: 0, textAlign: 'justify', widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '8pt' }}>&nbsp;</span></p>
                            <p style={{ margin: '0pt', orphans: 0, textAlign: 'justify', widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '8pt' }}>&nbsp;</span></p>
                        </div>
            
                        <div  style={{ float:'left',  width: '50%', display:this.state.textPage==='A4'?'none':'block', padding:'20pt', boxSizing:'border-box' }}>
                        {
                                this.state.testList.list?this.state.textPage=='A3'?this.state.testList.list.filter((item,index) => index > this.state.subjNum-1).map((item, bigNum) => {
                                    return (
                                    <table key={item.qt_index} cellSpacing={0} cellPadding={0} style={{ borderCollapse: 'collapse', marginLeft: '0pt',width:'100%', margin:'0 auto' }}>
                                        <tbody>
                                                            <tr>
                                                                <td style={{borderLeftColor: '#000000', borderLeftStyle: 'solid', borderLeftWidth: '0.75pt', borderRightColor: '#000000', borderRightStyle: 'solid',borderRightWidth: '0.75pt', borderTopColor: '#000000', borderTopStyle: 'solid', borderTopWidth: '0.75pt', verticalAlign: 'top'}}>&nbsp;</td>
                                                            </tr>
                                                            <tr style={{}}>
                                                                
                                                                <td style={{ borderLeftColor: '#000000', borderLeftStyle: 'solid', borderLeftWidth: '0.75pt', borderRightColor: '#000000', borderRightStyle: 'solid', borderRightWidth: '0.75pt', verticalAlign: 'top',  }}>
                                                                    <p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0, display:'flex', justifyContent:'space-between' }}>
                                                                        <span>

                                                                            <span style={{ fontFamily: '宋体', fontSize: '12pt', width:'300pt' }}>&nbsp;{item.qt_index}</span>
                                                                            <span style={{ fontFamily: '宋体', fontSize: '12pt', width:'300pt' }}>、{item.qt_name}（总分{item.qt_list.reduce((sum, curr) =>{return sum += curr.score},0)}分)</span>
                                                                        </span>
                                                                            {
                                                                                item.qt_list.reduce((sum, curr) =>{return sum += curr.score},0) > 10?
                                                                                <span style={{display:this.state.mark === 1?'inline-block':'none',width:'250px'}}>

                                                                                    <span style={{ width: '10px', height:'10pt',fontFamily: '"Times New Roman"', fontSize: '15pt',}}>考生禁填</span>&nbsp;
                                                                                    <span style={{border:'1px solid #000', width: '10px', height:'10pt',fontFamily: '"Times New Roman"', fontSize: '20pt',}}>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;
                                                                                    <span style={{border:'1px solid #000', width: '10px', height:'10pt',fontFamily: '"Times New Roman"', fontSize: '20pt',}}>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;
                                                                                    <span style={{border:'1px solid #000', width: '10px', height:'10pt',fontFamily: '"Times New Roman"', fontSize: '20pt',}}>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;
            
                                                                                </span>
                                                                                    :
                                                                                    <span style={{display:this.state.mark === 1?'inline-block':'none', width:'250px'}}>
                                                                                            <span style={{ width: '10px', height:'10pt',fontFamily: '"Times New Roman"', fontSize: '15pt',}}>考生禁填</span>&nbsp;
                                                                                        <span style={{border:'1px solid #000', width: '10px', height:'10pt',fontFamily: '"Times New Roman"', fontSize: '20pt',}}>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;
                                                                                        <span style={{border:'1px solid #000', width: '10px', height:'10pt',fontFamily: '"Times New Roman"', fontSize: '20pt',}}>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;
                                                                            </span>

                                                                            }
                                                                        
                                                                </p>
                                                                    {
                                                                        item.qt_list.map((topic, smallNum) => {
                                                                            if(item.qt_name === '选择题' || item.qt_name === '单项选择'){
                                                                                return  (
                                                                                    <div key={smallNum +'ccs'}>
                                                                                        <span>&nbsp;&nbsp;</span>
                                                                                        <span>{smallNum+1}.</span>
                                                                                        <span style={{display:'inline-block', border:'1pt solid #000', width:'18pt', fontSize: '8pt',textAlign:'center',lineHeight:'10pt', height:'10pt'}}>&nbsp;A&nbsp;</span>&nbsp;
                                                                                        <span style={{display:'inline-block', border:'1pt solid #000', width:'18pt', fontSize: '8pt',textAlign:'center',lineHeight:'10pt', height:'10pt'}}>&nbsp;B&nbsp;</span>&nbsp;
                                                                                        <span style={{display:'inline-block', border:'1pt solid #000', width:'18pt', fontSize: '8pt',textAlign:'center',lineHeight:'10pt', height:'10pt'}}>&nbsp;C&nbsp;</span>&nbsp;
                                                                                        <span style={{display:'inline-block', border:'1pt solid #000', width:'18pt', fontSize: '8pt',textAlign:'center',lineHeight:'10pt', height:'10pt'}}>&nbsp;D&nbsp;</span> 
                                                                                    </div>
                                                                                )
                                                                                    
                                                                            }else  if(item.qt_name === '简答题' || item.qt_name === '问答题') {
                                                                                return (
                                                                                    <div key={smallNum +'ccs'}>
                                                                                        <div>&nbsp;</div>
                                                                                        <div>&nbsp;</div>
                                                                                        <div>&nbsp;</div>
                                                                                        <div>&nbsp;</div>
                                                                                        <div>&nbsp;</div>
                                                                                    </div>
                                                                                )
                                                                            }else {
                                                                                return(
                                                                                    <div key={smallNum +'ccs'}>
                                                                                        <span>&nbsp;&nbsp;</span>
                                                                                        <span>{smallNum+1}.</span>
                                                                                        <span style={{color:'#000',fontSize:'24pt',fontWeight:'100'}}>_______________________&nbsp;&nbsp;&nbsp;</span>
                                                                                    </div>
                                                                                )
                                                                            }
                                                                        })
                                                                    }
                                                                </td> 
                                                                    {/* <p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, textIndent: '10.5pt', widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>2</span><span style={{ fontFamily: '宋体', fontSize: '12pt' }}>、（</span><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>2</span><span style={{ fontFamily: '宋体', fontSize: '12pt' }}>分）</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, textIndent: '10.5pt', widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>3</span><span style={{ fontFamily: '宋体', fontSize: '12pt' }}>、（</span><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>2</span><span style={{ fontFamily: '宋体', fontSize: '12pt' }}>分）</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, textIndent: '10.5pt', widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>4</span><span style={{ fontFamily: '宋体', fontSize: '12pt' }}>、（</span><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>2</span><span style={{ fontFamily: '宋体', fontSize: '12pt' }}>分）</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, textIndent: '10.5pt', widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>5</span><span style={{ fontFamily: '宋体', fontSize: '12pt' }}>、（</span><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>2</span><span style={{ fontFamily: '宋体', fontSize: '12pt' }}>分）</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '12pt' }}>&nbsp;</span></p></td> */}
                                                            </tr>
                                                            <tr style={{ height: '1pt' }}>
                                                                <td style={{ borderBottomColor: '#000000', borderBottomStyle: 'solid', borderBottomWidth: '0.75pt', borderLeftColor: '#000000', borderLeftStyle: 'solid', borderLeftWidth: '0.75pt', borderRightColor: '#000000', borderRightStyle: 'solid', borderRightWidth: '0.75pt', verticalAlign: 'top' }}><p style={{ lineHeight: '17pt', margin: '0pt', orphans: 0, widows: 0 }}><span style={{ fontFamily: '"Times New Roman"', fontSize: '9pt' }}>&nbsp;</span></p></td>
                                                            </tr>
                                                            <tr>
                                                                <td>&nbsp;</td>
                                                            </tr>
                                        </tbody>
                                    </table>
                                        
                                    )
                                }
                                ):'':''
                            }
                            
                        </div>
                        {/* <div style={{ float: "left", width: '50%' }}>
                    
                        </div> */}
                    </div>
               </div>
            </>
        )
    }
}
