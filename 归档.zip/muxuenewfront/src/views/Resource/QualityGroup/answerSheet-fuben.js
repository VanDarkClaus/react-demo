import React, { Component } from 'react'
import { paperPreview, downLoadAnswerSheet, saveAnswerSheet, paperDetails } from '../../../requests'
import { Layout, Button, Modal, List, Row, Col, Table, Pagination, Radio, message, Switch } from 'antd'
import 'echarts/lib/chart/pie'

class AnswerSheet extends Component {

    constructor() {
        super()
        const a = window.location.href.split('/')
        const paper_id = a[a.length - 1]
        this.state = {
            paper_id,
            testList: {
                list:[]
            }, // 添加试题
            value1: 1, // 答题卡模式
            value2: 1, // 答题卡布局
            value3: 1, // 选择考号版式
            value4: 1, // 设置禁止作答区
            arrtest: ['1', '2', '3', '4', '5', '6', '7', '8'],
            arrtest2: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10'],
            tableName: '条形码',
            title: '',
            subtitle: '',
            visible: false
        }

    }

    componentDidMount() {
        paperDetails(this.state.paper_id)
            .then(resp => {
                console.log(resp)
                resp.body.list.reverse()
                this.setState({
                    testList: resp.body,
                    title: resp.body.title,
                    subtitle: resp.body.subtitle
                })
            })
    }

    // 答题卡模式
    onChange1 = e => {
        console.log('radio checked', e.target.value);
        this.setState({
            value1: e.target.value,
        });
    };

    // 答题卡布局
    onChange2 = e => {
        console.log('radio checked', e.target.value);
        this.setState({
            value2: e.target.value,
        });
    };

    // 选择考号版式
    onChange3 = e => {
        console.log('radio checked', e.target.value);
        this.setState({
            value3: e.target.value,
        });
    };

    // 设置禁止作答区
    onChange4 = e => {
        console.log('radio checked', e.target.value);
        this.setState({
            value4: e.target.value,
        });
    };

    // 下载答题卡
    downLoadAnswerSheetHandler(content) {
        // 截取url最后的paper_id
        const url = window.location.href
        const index = url.lastIndexOf("\/")
        const paper_id = url.substring(index + 1, url.length)
        downLoadAnswerSheet(paper_id, content)

    }

    render() {
        var counta = 1,
            countb = 1,
            counta1 = 0
        return (
            <div  style={{ width: '1000px', margin: '0 auto', height: '1108px', background: '#fff',  }}>
                {/* 左边布局 */}
                <div className='questionLeft' style={{ float: 'left', background: '#fff', }}>
                    <div style={{ width: '20px', height: '30px', marginTop: '50px', background: 'black' }}></div>
                    <div  style={{ width: '700px', boxSizing: 'border-box', marginTop:'-80px' }}>
                        <div style={{ height: '400px', display:'flex', justifyContent:'center'}}>
                            <div style={{float:'left',marginLeft:'75px',marginRight:'50px'}}>
                                <div style={{ width: this.state.tableName === '条形码' ? '500px' : '300px', height: '100px', border: '2px solid black', margin: 'auto', marginTop: "110px", textAlign: 'center', padding: '20px 0' }}>
                                    <div onSelect={(e) => { this.setState({ title: e.target.innerHTML }) }} suppressContentEditableWarning="true" contentEditable={true} style={{ fontSize: '18px', fontWeight: '500', color: 'black' }}>{this.state.title}</div>
                                    <div onSelect={(e) => { this.setState({ subtitle: e.target.innerHTML }) }} suppressContentEditableWarning="true" contentEditable={true} >{this.state.subtitle}</div>
                                </div>
                                <div style={{ background: '#fff', height: '150px', marginTop: '40px', fontColor: 'black' , marginLeft:'40px'}}>
                                    <div>
                                        <p>姓名：_________________</p>
                                        <p>班级：_________________</p>
                                        <p>考号：_________________</p>
                                    </div>
                                </div>
                            </div>

                            <table style={{float:'left', display: this.state.tableName === '条形码' ? 'none' : 'table',cellpadding: '0', cellspacing: '0', width: '220px', height: '200px', marginRight: '50px', marginTop: '80px' }}>
                                <tbody style={{ border: '1px solid black' }}>
                                    <tr><td style={{ width: '26px', height: '26px' }} colSpan="8" style={{ textAlign: 'center', border: '1px solid black', borderCollapse: 'collapse', paddingCop: '1mm', color: 'black' }}>{this.state.tableName}</td></tr>
                                    <tr>

                                        {
                                            this.state.arrtest.map(item => {
                                                return (
                                                    <td style={{ width: '26px', height: '26px' }} key={item + 'a'} style={{ border: '1px solid rgb(0, 0, 0)', borderCollapse: 'collapse', color: 'white' }}>*</td>
                                                )
                                            })
                                        }
                                    </tr>
                                    {
                                        this.state.arrtest2.map((item, index) => {
                                            return (
                                                <tr key={item + 'b'}>
                                                    {
                                                        this.state.arrtest.map((a) => {
                                                            return <td style={{ width: '26px', height: '26px' }} key={a} style={{ borderLeft: '1px solid rgb(0, 0, 0)', borderRight: '1px solid rgb(0, 0, 0)', borderCollapse: 'collapse', color: 'black', textAlign: 'center' }}>{'[' + index + ']'}</td>
                                                        })
                                                    }
                                                </tr>
                                            )
                                        })
                                    }
                                </tbody>
                            </table>
                        </div>

                             {
                                 this.state.testList.list.map((item, num) => {
                                     if(num>0){
                                         counta1 += this.state.testList.list[num-1].qt_list.length
                                     }
                                     console.log(counta1)
                                   return (
                                    <div key={item.qt_name} style={{ width: '600px', marginBottom: '50px',marginLeft:'50px' }}>
                                    <div style={{ color: 'black', fontSize: '16px', fontWeight: '500', marginLeft: '50px' }}>{item.qt_name}</div>
                                    <div style={{ width: '600px', minHeight: '180px', border: '1px solid #000', margin: 'auto', padding:'10px' }}>
                                        {item.qt_list.map((qt,index) =>{
                                            if(item.qt_name === '选择题') {
                                                return <div style={{display:'flex', alignItems:'center', justifyContent:'space-around', width:'33%', margin:'5px'}} key={qt.id}>
                                                   <div style={{width:'20px'}}>{counta1+index+1}</div>
                                                    <div style={{border:'1px solid #000', width:'24px',textAlign:'center',lineHeight:'16px', height:'16px'}}>A</div> 
                                                    <div style={{border:'1px solid #000', width:'24px',textAlign:'center',lineHeight:'16px', height:'16px'}}>B</div> 
                                                    <div style={{border:'1px solid #000', width:'24px',textAlign:'center',lineHeight:'16px', height:'16px'}}>C</div> 
                                                    <div style={{border:'1px solid #000', width:'24px',textAlign:'center',lineHeight:'16px', height:'16px'}}>D</div> 
                                                </div>
                                            }else if(item.qt_name === '单项选择') {
                                                return <div style={{display:'flex', alignItems:'center', justifyContent:'space-around', width:'33%', margin:'5px'}} key={qt.id}>
                                                   <div>{counta1+index+1}.</div>
                                                    <div style={{border:'1px solid #000', width:'24px',textAlign:'center',lineHeight:'16px', height:'16px'}}>A</div> 
                                                    <div style={{border:'1px solid #000', width:'24px',textAlign:'center',lineHeight:'16px', height:'16px'}}>B</div> 
                                                    <div style={{border:'1px solid #000', width:'24px',textAlign:'center',lineHeight:'16px', height:'16px'}}>C</div> 
                                                    <div style={{border:'1px solid #000', width:'24px',textAlign:'center',lineHeight:'16px', height:'16px'}}>D</div> 
                                                </div>
                                            }else if(item.qt_name === '填空题'){
                                                return <div style={{color:'black',marginTop:'10px'}} key={qt.id}>{
                                                    `${counta1+ index+1}.` 
                                                 }<hr style={{width:'80%', margin:'0 auto', marginTop:'-5px', marginLeft:'20px' }}/>
                                                    {/* <Button type='primary' onClick={() => { this.setState({ visible: true }) }}>编辑</Button> */}
                                                 </div>
                                            }else {
                                                return <div style={{color:'black',marginTop:'10px'}} key={qt.id}>{
                                                    `${counta1+index+1}.` 
                                                 }<hr style={{width:'90%', margin:'0 auto', marginTop:'-5px', marginLeft:'20px', }}/>
                                                 </div>
                                            }
                                        })}
                                    </div>
                                    </div>
                                   )
                                 })
                             }     
                    </div>
                </div>
                {/* 右边布局 */}
                <div style={{ float: 'right', backgroundColor: "#fff", width: 300, paddingTop: '50px', }}>
                    <div style={{ height: 150 }}>
                        <p style={{ backgroundColor: "#ccc", fontSize: "16px", fontWeight: 800, height: 30, lineHeight: '30px', paddingLeft: '20px' }}>选择答题卡模式</p>
                        <Radio.Group onChange={this.onChange1} value={this.state.value1}>
                            <Radio value={1}>网阅卡</Radio>
                            <Radio value={2}>手阅卡</Radio>
                        </Radio.Group>
                    </div>
                    <div style={{ height: 150 }}>
                        <p style={{ backgroundColor: "#ccc", fontSize: "16px", fontWeight: 800, height: 30, lineHeight: '30px', paddingLeft: '20px' }}>答题卡布局</p>
                        <Radio.Group onChange={this.onChange2} value={this.state.value2}>
                            <Radio value={1}>一栏</Radio>
                            <Radio value={2}>二栏</Radio>
                            <Radio value={3}>三栏</Radio>
                        </Radio.Group>
                    </div>
                    <div style={{ height: 150 }}>
                        <p style={{ backgroundColor: "#ccc", fontSize: "16px", fontWeight: 800, height: 30, lineHeight: '30px', paddingLeft: '20px' }}>选择考号版式</p>
                        <Radio.Group onChange={this.onChange3} value={this.state.value3}>
                            <Radio value={1} onChange={() => {
                                this.setState({ tableName: '条形码' })
                            }}>条形码</Radio>
                            <Radio value={2} onChange={() => {
                                this.setState({ tableName: '准考证号' })
                            }}>准考证号</Radio>
                            <Radio value={3} onChange={() => {
                                this.setState({ tableName: '学籍号' })
                            }}>学籍号</Radio>
                        </Radio.Group>
                    </div>
                    <div style={{ height: 150 }}>
                        <p style={{ backgroundColor: "#ccc", fontSize: "16px", fontWeight: 800, height: 30, lineHeight: '30px', paddingLeft: '20px' }}>设置禁止作答区</p>
                        <Radio.Group onChange={this.onChange4} value={this.state.value4}>
                            <Radio value={1}>启用</Radio>
                            <Radio value={2}>禁用</Radio>
                        </Radio.Group>
                    </div>
                    <div style={{ height: 150 }}>
                        <p style={{ backgroundColor: "#ccc", fontSize: "16px", fontWeight: 800, height: 30, lineHeight: '30px', paddingLeft: '20px' }}>题目列表</p>

                        <div >
                            {
                                this.state.testList.list.map((item, index) => {
                                    // switch(index)
                                    countb = counta
                                    counta += this.state.testList.list[index].qt_list.length
                                    return(
                                        <div key={index+'as'} style={{borderBottom:'1px dashed #dedede', marginBottom:'10px'}}>
                                            <span style={{width:'100px', display:'inline-block', fontSize:'14px', margin:''}}>{item.qt_name}</span>
                                            <span style={{width:'100px', display:'inline-block'}}>{
                                                   countb === (counta -1)?countb : `${countb} - ${counta-1}`
                                            }</span>
                                        </div>
                                    )
                                })
                            }
                        </div>
                    </div>
                    <p style={{ backgroundColor: "#ccc", fontSize: "16px", fontWeight: 800, height: 30, lineHeight: '30px', paddingLeft: '20px' }}>
                        <span style={{marginRight:'20px'}}>按题型排序</span>
                        <Switch onChange={()=>{this.setState({
                            testList: {
                                ...this.state.testList,
                                list:this.state.testList.list.reverse()
                            }
                        })}}></Switch>
                    </p>

                    <div style={{ width: '100%', display: "flex", justifyContent: "space-around", marginTop: 100 }}>
                        <Button type="primary" onClick={() => {
                            saveAnswerSheet(this.state.paper_id, document.querySelector('.questionLeft').outerHTML)
                                .then(res => {
                                    message.info(res.message)

                                })

                        }}>保存答题卡</Button>
                        <Button type="primary" onClick={() => {
                            downLoadAnswerSheet(this.state.paper_id, document.querySelector('.questionLeft').outerHTML)
                                .then(resp => {
                                    if (!resp) {
                                        return
                                    }
                                    let url = window.URL.createObjectURL(new Blob([resp]))
                                    let link = document.createElement('a')
                                    link.style.display = 'none'
                                    link.href = url
                                    link.setAttribute('download', `${this.state.title}-答题卡.pdf`)
                                    document.body.appendChild(link)
                                    link.click()
                                })
                        }}>下载答题卡
                            </Button>
                    </div>
                </div>
                <Modal
                    visible={this.state.visible}
                    onCancel={() => { this.setState({ visible: false }) }}
                    onOk={() => { }}
                >
                    <span style={{ marginRight: '20px' }}>编辑为选择题</span><Switch onChange={(a) => { this.setState() }}></Switch>
                </Modal>
            </div>
        )
    }
}

export default AnswerSheet