import React, { Component } from 'react'
import { Layout, Icon, Switch, Card, Input, Descriptions, Radio, Tree, Select, Button, Cascader, List, message  } from 'antd'
import { knowledgeTree, filterDetails, questionLists, addQuestion, deleteQuestion, testQuestionsAlreadyAdded, emptyQuestion } from 'requests'
import course from 'utils/course-grade.json'
import analysis from 'views/DataEntry/ExaminationProcess/DataCollection/problemLable'

const { Content, Sider } = Layout
const { Search } = Input
const { TreeNode } = Tree
const { Option } = Select

// 年级科目级联选择
const options = course.map(item => {
    return {
        value: item.name,
        label: item.name,
        children: item.contents.map(i => {
            return {
                key: i.id,
                value: i.name,
                label: i.name,
            }
        })
    }
})


// 下拉选项切换
function handleChange(value) {
    console.log(`selected ${value}`)
}


export default class QualityGroup extends Component {
    
    constructor() {
        super()
        this.state = {
            // “单选” “多选” 状态，设置初始值为 false
            checked: false,
            treeControl: [],
            treeNodes: [],
            treeData: [],
            grades:[],  // 不同年级
            q_types: [],  // 题型
            list: [],  // 试题列表
            gradeIndex: 14, // 科目id
            knowledge_id: 10855, // 知识点id
            grade_id: 0, // 年级id
            course_id: 0, // 课程id
            area_id: 0, //地区id
            diff_id: 5, //困难程度id
            quest_type_id: 0 , //类型id
            limit: 10, 
            point: 0, 
            page: 1,
            value: 0,
            addedQuestions: [], // 试题栏试题
            courseValue: ['高中', '语文'],
            analysis_id: '', // 试题分析id
            
        }
    }

    // 树形控件数据加载
    onLoadData = treeNode =>
    new Promise(resolve => {
      if (treeNode.props.children) {
        resolve();
        return;
      }
        // treeNode.props.dataRef.children = [
        //   { title: 'Child Node', key: `${treeNode.props.eventKey}-0` },
        //   { title: 'Child Node', key: `${treeNode.props.eventKey}-1` },
        // ];
        this.setState({
          treeData: [...this.state.treeData],
        });
        resolve();
    });

   

    renderTreeNodes = data =>
    data.map(item => {
      if (item.children) {
        return (
          <TreeNode title={item.title} key={item.key} dataRef={item}>
            {this.renderTreeNodes(item.children)}
          </TreeNode>
        );
      }
      return <TreeNode key={item.key} {...item} dataRef={item} />;
    });

    

    // 点击 “单选” “多选” 开关改变颜色和状态
    onChange = (checked) => {
        this.setState({
            // checked 状态取反
            checked: !this.state.checked
        })
    }

    // // 左侧树形控件选择知识点
    // onSelect = (selectedKeys, info) => {
    //     // console.log('selected', selectedKeys, info)
    // }

    componentDidMount(){
        // 知识点数据
        knowledgeTree(14)
            .then(resp => {
                // console.log('====初始化====')
                // console.log(resp)
                this.setState({
                    treeData: resp.body
                })
            })
        // 筛选列表
        filterDetails(14)
            .then(resp => {
                this.setState({
                    grades: resp.body.grades,
                    q_types: resp.body.q_types
                })
            })

        // 默认高一语文试题列表
        questionLists(this.state.gradeIndex, this.state.grade_id, this.state.course_id = 0, this.state.area_id = 0, this.state.diff_id = 0, this.state.quest_type_id , this.state.knowledge_id = 0 , this.state.limit = 10, this.state.point = 0, this.state.page= 1)
            .then(resp => {
                console.log(resp)
                this.setState({
                    list: resp.body.content
                })
            })

        // 试题蓝已经添加的试题
        testQuestionsAlreadyAdded()
            .then(resp => {
                console.log(resp)
                this.setState({
                    addedQuestions: resp.body
                })
            })
    }

    // 年级科目选择结果输出
    onChangeCourse = (value,id) => {
        console.log(value,id[1].key);
        this.setState({
            courseValue: value,
            gradeIndex: id[1].key
        },()=>{
            console.log(this.state.courseValue)
            console.log(this.state.gradeIndex)
        })
        knowledgeTree(id[1].key)
            .then(resp => {
                // console.log('======科目年级======')
                // console.log(resp)
                this.setState({
                    treeData: resp.body
                })
            })
        filterDetails(id[1].key)
            .then(resp => {
                // console.log('======年级题型等======')
                // console.log(resp)
                this.setState({
                    grades: resp.body.grades,
                    q_types: resp.body.q_types
                })
            })
        questionLists(id[1].key)
            .then(resp => {
                // console.log('=====试题列表=====')
                // console.log(resp)
                this.setState({
                    list: resp.body.content
                })
            })
    }

     // 左侧树形控件知识点选择不同试题列表
     selecteTreeNode = (knowledge_id) => {

        console.log(knowledge_id)
        this.setState({
            knowledge_id: knowledge_id
        }, () => {
            console.log(this.state.knowledge_id)
        })
        questionLists(this.state.gradeIndex, this.state.grade_id, this.state.course_id = 0, this.state.area_id = 0, this.state.diff_id, this.state.quest_type_id, knowledge_id, this.state.limit = 10, this.state.point = 0, this.state.page= 1)
        .then(resp => {
            console.log(resp)
            this.setState({
                list: resp.body.content
            })
        })
    } 

    // 年级选择
    handleGradeId = e => {
        console.log(e.target.value)
        this.setState({
                    grade_id: e.target.value
        },() =>{
            console.log(this.state.grade_id)
        })
        questionLists(this.state.gradeIndex, e.target.value, this.state.course_id = 0, this.state.area_id = 0, this.state.diff_id, this.state.quest_type_id , this.state.knowledge_id , this.state.limit = 10, this.state.point = 0, this.state.page= 1)
            .then(resp => {
                // console.log('=====试题列表=====')
                // console.log(resp)
                this.setState({
                    list: resp.body.content
                })
        })

    };

    // 题型选择
    selecteQuestionType = e =>{
        console.log(e.target.value)
        this.setState({
            quest_type_id: e.target.value
        })
        questionLists(this.state.gradeIndex, this.state.grade_id, this.state.course_id = 0, this.state.area_id = 0, this.state.diff_id, e.target.value , this.state.knowledge_id , this.state.limit = 10, this.state.point = 0, this.state.page= 1)
        .then(resp => {
            // console.log('=====试题列表=====')
            // console.log(resp)
            this.setState({
                list: resp.body.content
            })
        })
    }

    // 难度选择
    onChangeSelect = e => {
        console.log(e.target.value);
        this.setState({
            diff_id: e.target.value
        })

        questionLists(this.state.gradeIndex, this.state.grade_id, this.state.course_id = 0, this.state.area_id = 0, e.target.value, this.state.quest_type_id , this.state.knowledge_id , this.state.limit = 10, this.state.point = 0, this.state.page= 1)
        .then(resp => {
            // console.log('=====试题列表=====')
            // console.log(resp)
            this.setState({
                list: resp.body.content
            })
        })
    };

    // 难度选择
    handleDiffChange = (e) => {
        console.log(e.target.value);
        this.setState({
            diff_id: e.target.value
        })

        questionLists(this.state.gradeIndex, this.state.grade_id, this.state.course_id = 0, this.state.area_id = 0, e.target.value, this.state.quest_type_id , this.state.knowledge_id , this.state.limit = 10, this.state.point = 0, this.state.page= 1)
        .then(resp => {
            // console.log('=====试题列表=====')
            // console.log(resp)
            this.setState({
                list: resp.body.content
            })
        })
    }

    // 添加或者移除试题
    addQuestionHandler = (id,isAdd) => {
        console.log(id,isAdd)
        // 添加试题
        if(isAdd === false) {
            addQuestion(id)
                .then(resp => {
                    console.log(resp)
                    if(resp.code === 200) {
                        message.success('添加成功')
                        // 刷新试题列表
                        questionLists(this.state.gradeIndex, this.state.grade_id, this.state.course_id = 0, this.state.area_id = 0, this.state.diff_id, this.state.quest_type_id , this.state.knowledge_id , this.state.limit = 10, this.state.point = 0, this.state.page= 1)
                        .then(resp => {
                            this.setState({
                                list: resp.body.content
                            })
                        })
                        // 试题栏已经添加的试题
                        testQuestionsAlreadyAdded()
                            .then(resp => {
                                console.log(resp)
                                this.setState({
                                    addedQuestions: resp.body
                                })
                            })
                    }
                })
        }
        // 移除试题
        if(isAdd === true) {
            addQuestion(id) 
                .then(resp => {
                    console.log(resp)
                    if(resp.code === 200) {
                        message.success('移除成功')
                        // 刷新试题列表
                        questionLists(this.state.gradeIndex, this.state.grade_id, this.state.course_id = 0, this.state.area_id = 0, this.state.diff_id, this.state.quest_type_id , this.state.knowledge_id , this.state.limit = 10, this.state.point = 0, this.state.page= 1)
                        .then(resp => {
                            this.setState({
                                list: resp.body.content
                            })
                        })
                        // 试题栏已经添加的试题
                        testQuestionsAlreadyAdded()
                            .then(resp => {
                                console.log(resp)
                                this.setState({
                                    addedQuestions: resp.body
                                })
                            })
                    }
                })
        }
    }

    // 删除一类题型
    deleteQuestionHandler = (ids) =>{
        console.log(ids)
        deleteQuestion(ids)
            .then(resp => {
                console.log(resp)
                if(resp.code === 200) {
                    // 刷新试题列表
                    questionLists(this.state.gradeIndex, this.state.grade_id, this.state.course_id = 0, this.state.area_id = 0, this.state.diff_id, this.state.quest_type_id , this.state.knowledge_id , this.state.limit = 10, this.state.point = 0, this.state.page= 1)
                    .then(resp => {
                        this.setState({
                            list: resp.body.content
                        })
                    })
                    // 试题栏已经添加的试题
                    testQuestionsAlreadyAdded()
                        .then(resp => {
                            console.log(resp)
                            this.setState({
                                addedQuestions: resp.body
                            })
                        })
                }
            })
    }

    // 清空试题
    emptyQuestionHandler = () => {
        emptyQuestion()
            .then(resp => {
                console.log(resp)
                if(resp.code === 200) {
                    // 刷新试题列表
                    questionLists(this.state.gradeIndex, this.state.grade_id, this.state.course_id = 0, this.state.area_id = 0, this.state.diff_id, this.state.quest_type_id , this.state.knowledge_id , this.state.limit = 10, this.state.point = 0, this.state.page= 1)
                    .then(resp => {
                        this.setState({
                            list: resp.body.content
                        })
                    })
                    // 试题栏已经添加的试题
                    testQuestionsAlreadyAdded()
                        .then(resp => {
                            console.log(resp)
                            this.setState({
                                addedQuestions: resp.body
                            })
                        })
                }
            })
    }
    

    // 搜索
    searchKeyword = (keywords) => {
        console.log(keywords)
        questionLists(this.state.gradeIndex, this.state.grade_id, this.state.course_id = 0, this.state.area_id = 0, this.state.diff_id, this.state.quest_type_id , this.state.knowledge_id , this.state.limit = 10, keywords, this.state.page= 1)
            .then(resp => {
                this.setState({
                    list: resp.body.content
                })
        })
    }

    // 解析
    analysisHandler = (id) => {
        console.log(id)
        this.setState({
            analysis_id: id
        })
    }

    render() {
        return (
            <Layout>
                <div style={{position: "absolute" ,top: 135, right: 200}}>
                <Cascader options={options} onChange={this.onChangeCourse} placeholder="请选择年级和科目" value={this.state.courseValue} />,
                </div>
                <Layout>
                <Sider width={300} style={{ background: "#f3faff" }}>
                    <div style={{
                        width: "255px",
                        height: "105px",
                        marginLeft: "75px",
                        marginRight: "20px",
                        borderBottom: "2px solid #cce3f5",
                        position: "relative"
                    }}>
                    <p style={{
                        position: "absolute",
                        top: "30%",
                        left: 0,
                        color: "#0195ff",
                        fontSize: "16px",
                        fontWeight: 700
                    }}>
                        <Icon type="unordered-list" style={{marginRight: "5px"}}/>
                        知识点目录
                    </p>
                        {/* <div style={{position: "absolute", bottom: "10%", right: "10%",}}>
                            <span style={{marginRight: "5px", color: this.state.checked ? "#9ba9b2" : "#0195ff", fontSize: "14px"}}>单选</span>
                            <Switch onChange={this.onChange} checked={this.state.checked} />
                            <span style={{marginLeft: "5px", color: this.state.checked ? "#0195ff" : "#9ba9b2", fontSize: "14px"}}>多选</span>
                        </div> */}
                    </div>
                    <Card bordered={false} style={{ background: '#f3faff', paddingLeft: "12%"}}>
                    <Tree loadData={this.onLoadData}  onSelect={this.selecteTreeNode}>{this.renderTreeNodes(this.state.treeData)}</Tree>
                    </Card>
                </Sider>
                <Layout style={{ paddingTop: '24px', backgroundColor: "#f3faff"}}>
                    <Content
                    style={{
                        background: '#fff',
                        margin: 0,
                        minHeight: 280,
                    }}
                    >
                    <Card style={{borderBottom: "2px solid #cce3f5", marginLeft: "20px", marginRight: "20px"}} bordered={false}>
                        <Search onSearch={this.searchKeyword} enterButton style={{ width: 300, float:"right"}} />
                    </Card>
                    <Card  bordered={false}>
                    <Descriptions column={1}>
                        <Descriptions.Item>
                            <span style={{fontWeight: 700, color: "#5f6064"}}>年级：</span>
                            <Radio.Group defaultValue="0"  onChange={this.handleGradeId} style={{display: 'flex', flexWrap: 'wrap', marginTop:10, marginLeft: 20}}>
                                <Radio.Button value="0" >
                                    全部
                                </Radio.Button>
                                {
                                    this.state.grades.map(item => {
                                        return (
                                            <Radio.Button value={item.grade_id} key={item.grade_id}>
                                                {item.name}
                                            </Radio.Button>
                                        )
                                    })
                                }
                            </Radio.Group>
                        </Descriptions.Item>
                        <Descriptions.Item>
                            <span style={{fontWeight: 700, color: "#5f6064"}}>题型：</span>
                            <Radio.Group defaultValue="0"  onChange={this.selecteQuestionType} style={{display: 'flex', flexWrap: 'wrap', marginTop:10 , marginLeft: 20}}>
                                <Radio.Button value="0" >
                                    全部
                                </Radio.Button>
                                {
                                    this.state.q_types.map(item => {
                                        return (
                                            <Radio.Button value={item.quest_type_id} key={item.quest_type_id}>
                                                {item.quest_type_name}
                                            </Radio.Button>
                                        )
                                    })
                                }
                            </Radio.Group>
                        </Descriptions.Item>
                        <Descriptions.Item>
                            <span style={{fontWeight: 700, color: "#5f6064"}}>难度：</span>
                            <Radio.Group   defaultValue="5" onChange={this.handleDiffChange} style={{display: 'flex', flexWrap: 'wrap', marginTop:10, marginLeft: 20}}>
                                <Radio.Button value="5">困难</Radio.Button>
                                <Radio.Button value="4">较难</Radio.Button>
                                <Radio.Button value="3">一般</Radio.Button>
                                <Radio.Button value="2">较易</Radio.Button>
                                <Radio.Button value="1">容易</Radio.Button>
                            </Radio.Group>
                        </Descriptions.Item>
                        <Descriptions.Item>
                            <span style={{fontWeight: 700, color: "#5f6064"}}>来源：</span>
                            <Radio.Group defaultValue="a" style={{display: 'flex', flexWrap: 'wrap', marginTop:10, marginLeft: 20}}>
                                <Radio.Button value="a">全部</Radio.Button>
                                <Radio.Button value="b" disabled={true}>拓展题</Radio.Button>
                                {/* <Radio.Button value="c" style={{marginRight: "50px"}}>我的收藏</Radio.Button> */}
                            </Radio.Group>
                        </Descriptions.Item>
                    </Descriptions>
                    </Card>
                    {/* <Card bordered={false}>
                        <Select defaultValue="默认" style={{ width: 120 }} onChange={handleChange}>
                        </Select>
                        <Select defaultValue="组卷次数" style={{ width: 120 }} onChange={handleChange}>
                            <Option value="disabled" disabled>
                                Disabled
                            </Option>
                        </Select>
                        <Select defaultValue="作答次数" style={{ width: 120 }} onChange={handleChange}>
                            <Option value="disabled" disabled>
                                Disabled
                            </Option>
                        </Select>
                        <Select defaultValue="平均得分率" style={{ width: 120 }} onChange={handleChange}>
                            <Option value="disabled" disabled>
                                Disabled
                            </Option>
                        </Select>
                        <Select defaultValue="共204题" style={{ width: 120 }} onChange={handleChange}>
                        </Select>
                    </Card> */}
                    <Card bordered={false} style={{marginLeft: "25px", marginRight: "25px"}}>
                    <List
                        itemLayout="vertical"
                        size="large"
                        pagination={{
                        onChange: page => {
                            console.log(page);
                        },
                        pageSize: 5,
                        }}
                        dataSource={this.state.list}
                        renderItem={(item,index) => (
                            // console.log(item),
                        <List.Item
                            key={item.se_id}
                        >
                            <List.Item.Meta
                            />
                            <h3 style={{position: "absolute", left: -6}}>{index+1+ "."}</h3>
                            <div dangerouslySetInnerHTML = {{__html:item.title }}></div>
                            
                                <div style={{backgroundColor: '#f3faff', marginTop: 20}}>
                                    <div style={{display: "flex", justifyContent: "space-around", alignItems: "center", height: "58px"}}>
                                    <div>组卷<span style={{color: "#35bccf"}}>123</span>次</div>
                                    <div>作答<span style={{color: "#35bccf"}}>123</span>次</div>
                                    <div>平均得分率<span style={{color: "#35bccf"}}>90%</span></div>
                                    <div >
                                        <Radio.Group>
                                            <Radio.Button value="analysis" onClick={
                                                () => {
                                                    this.analysisHandler(item.id)
                                                }
                                            }>解析</Radio.Button>
                                            {/* <Radio.Button value="test">考情</Radio.Button>
                                            <Radio.Button value="error">纠错</Radio.Button> */}
                                        </Radio.Group>
                                    </div>
                                    <div>
                                        <Button type="primary" onClick={
                                            () => {
                                                return (
                                                    this.addQuestionHandler(item.id,item.isAdd)
                                                )
                                            }
                                        }>{item.isAdd ? "移除试题" : "加入试卷"}</Button>
                                    </div>
                                    </div>
                                    <div style={{backgroundColor: '#fff', display: item.id === this.state.analysis_id ? 'block' : 'none'}}>
                                        {
                                            <div style={{fontSize: 12}} dangerouslySetInnerHTML = {{__html: item.analysis }}></div>
                                        }
                                    </div>
                                </div>
                        </List.Item>
                        )}
                    />
              
                    </Card>

                    </Content>
                </Layout>
                <Sider width={250} style={{ background: "#f3faff"}}>
                <Card style={{ width: 220, position: "fixed", top: "207px" }} title="试题框">
                <table style={{border: "null", textAlign: "center"}}>
                    <thead>
                        <tr>
                            <th>已选试题</th>
                            <th>题量</th>
                            <th>分数</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.addedQuestions.map(item => {
                                return (
                                    <tr key={item.qt_name}>
                                        <td>{item.qt_name}</td>
                                        <td>{item.qt_count}</td>
                                        <td>{item.qt_score}</td>
                                        <td><a onClick={
                                            () => {
                                                this.deleteQuestionHandler(item.qt_ids)
                                            }
                                        }>删除</a></td>
                                    </tr>
                                )
                            })
                        }
                    </tbody>
                    {/* <tfoot>
                            <tr>
                            <td>合计</td>
                            <td>{}</td>
                            <td>{}</td>
                            </tr>
                    </tfoot> */}
                </table>
                    <Button type="primary" onClick={
                        () => {
                            if(this.state.addedQuestions.length == 0) {
                                message.warning('请添加试题')
                            }
                            if(this.state.addedQuestions.length !== 0) {
                                return(
                                    this.props.history.push(`/admin/resource/qualitygroup/paperPreview/${this.state.gradeIndex}`)
                                )
                            }
                        }
                    }>试卷预览</Button>
                    <Button type="danger" onClick={this.emptyQuestionHandler}>清空</Button>
                </Card>
                </Sider>
                </Layout>
            </Layout>
        )
    }
}
