import React, { Component } from 'react'
import { getExamListRequest, analysisPaper, cityAreasRequest, schoolsRequest, downLoadTextPaper } from '../../../requests'
import { Layout, Card, Button, Select, DatePicker , Modal, Row, Col, Table, Pagination } from 'antd'
// import './SchoolGroup.less'
import { connect } from 'react-redux'
import 'echarts/lib/chart/pie'
import ReactEcharts from 'echarts-for-react'
import moment from 'moment'
import dictionary from 'utils/dictionary.json'

const { Content, Footer } = Layout
const { Option } = Select
const { RangePicker } = DatePicker


// 将 state 中保存的通知状态数据映射为组件的属性
const mapStateToProps = (state) => {
    // 返回一个对象
    return {
      schoolgroup: state.schoolgroup
    }
}


@connect(
    mapStateToProps
)
class SchoolGroup extends Component {

    constructor() {
        super()
        this.state = {
            textPaperList: {
                contents:[]
            },
            visible: false,
            difficultyAnalysis: [],
            knowledgesAnalysis: [],
            paperAmountDistribution: [],
            data: [],

            privince: '510000',
            city: '',
            area: '',
            school: '',
            grade: '203',
            start_at: '',
            end_at: '',

            cityIndex: 0,

            cityList: [],
            areaList: [],
            schoolList: [],
            gradeList: [],

            page: 1
        }
        
    }

    // 分析试卷
    showModal = (se_id) => {
        // 显示模态框
        this.setState({
            visible: true,
        })
        analysisPaper(se_id)
            .then(resp => {
                console.log(resp.body)
                // 解构赋值
                const { difficultyAnalysis, knowledgesAnalysis, paperAmountDistribution } = resp.body
                this.setState({
                    difficultyAnalysis,
                    knowledgesAnalysis,
                    paperAmountDistribution,
                    data: difficultyAnalysis
                })
                // console.log(this.state.difficultyAnalysis)
                // console.log(this.state.data)
                // 更新 data 数据，改变属性名为 name、value
                this.setState({
                    data: this.state.data.map((item, index) => {
                        return {
                            value: item.number,
                            name: item.difficulty
                        }
                    })
                })
                console.log(this.state.data)
            })
    }

    // 模态框数据可视化展示
    getOption = () => {
        let option = {
        tooltip: {
            trigger: 'item',
            formatter: "{a} <br/>{b}: {c} ({d}%)"
        },
        legend: {
            orient: 'vertical',
            data:['容易', '较易', '一般', '较难', '困难'],
            right: 50
        },
        series: [
            {
                name:'难度',
                type:'pie',
                radius: ['50%', '70%'],
                avoidLabelOverlap: false,
                label: {
                    normal: {
                        show: false,
                        position: 'center'
                    },
                    emphasis: {
                        show: true,
                        textStyle: {
                            fontSize: '20',
                            fontWeight: 'bold'
                        }
                    }
                },
                labelLine: {
                    normal: {
                        show: false
                    }
                },
                data: this.state.data
            }
        ]
    }
        return option
    }

    // 列
    columns = [
        {
            title: '题型',
            dataIndex: 'name'
        },
        {
            title: '题量',
            dataIndex: 'number'
            
        },
        {
            title: '分值',
            dataIndex: 'score'
        },
        {
            title: '分值占比%',
            dataIndex: 'scorePercentage'
        },
    ]

    // 点击 “确认” 后隐藏模态框
    handleOk = e => {
        console.log(e);
        this.setState({
            visible: false,
        })
    }

    // 点击 “取消” 后隐藏模态框
    handleCancel = e => {
        console.log(e);
        this.setState({
            visible: false,
        })
    }
    
    // 获取试卷列表数据
    getTestListHandle() {
        const {city, area, school, grade, page, start_at, end_at } = this.state
        getExamListRequest(area, city, school, grade, 10, page, start_at, end_at)
        .then(resp => {
            this.setState({
                textPaperList: resp.body
            })
        })
    }
    //通过省请求到市和区
    getCityHandle() {
        cityAreasRequest(this.state.privince)
        .then(res =>{
            this.setState({cityList:res.body, city:res.body[0].area_id, areaList: res.body[0].nodes, area: res.body[0].nodes.length?res.body[0].nodes[0].area_id:''},()=>{
                this.getGradeHandle()
            })
        })
    }
    //通过区请求到学校
    getGradeHandle() {
        schoolsRequest(this.state.area)
        .then(res => {
            // console.log(res)
            this.setState({schoolList:res.body, school:res.body.length?res.body[0].school_id:'', page: 1},()=>{
                this.getTestListHandle()
            })
        })
    }
    componentDidMount = async()=> {
        
        await cityAreasRequest(this.state.privince)
        .then(res =>{
            this.setState({cityList:res.body, city:res.body.length?res.body[0].area_id:'', areaList: res.body.length?res.body[0].nodes:[], area: res.body.length?res.body[0].nodes[1].area_id:''})
        })
        await schoolsRequest(this.state.area)
        .then(res => {
            this.setState({schoolList:res.body, school:res.body.length?res.body[0].school_id:''})
        })
        this.getTestListHandle()
       
    }



    render() {
        return (
            <Layout className="layout">
                <Content style={{  backgroundColor: "#f3faff" }}>
                <div style={{ background: '#fff', width:'1450px', margin: 'auto', minHeight: 280, paddingTop:'20px',}}>
                    <div style={{textAlign: "center", width:'1360px', height:'55px',display:'flex', justifyContent:'space-around', alignItems:'center', background:'#f3faff', border:'1px solid #c2cdd3', margin:'auto'}}>
                       <Button type='primary'>全国</Button>
                        <Select value={this.state.privince} style={{ width: 100 }} onChange={privince => {
                            this.setState({privince},()=>{
                                this.getCityHandle()
                            })
                        }}>
                            {
                                dictionary.provinceDict.map(item => {
                                    return(
                                        <Option key={item.area_id} value={item.area_id}>{item.name}</Option>
                                    )
                                })
                            }
                        </Select>
                        <Select value={this.state.city} style={{ width: 100 }} onChange={city=>{
                            let cityIndex
                            this.state.cityList.some((item, index)=>{
                                cityIndex = index
                                return item.area_id === city
                            })
                            this.setState({city, areaList: this.state.cityList[cityIndex].nodes, area: this.state.cityList[cityIndex].nodes.length?this.state.cityList[cityIndex].nodes[0].area_id:''},()=>{
                                this.getGradeHandle()
                            })
                        }}>
                            {
                                this.state.cityList.map(item => {
                                    return(
                                        <Option key={item.area_id} value={item.area_id}>{item.name}</Option>
                                    )
                                })
                            }
                        </Select>
                        <Select value={this.state.area} style={{ width: 100 }} onChange={area=>{
                            this.setState({area},()=>{
                                this.getGradeHandle()
                            })
                        }}>
                            {
                                this.state.areaList.map(item => {
                                    return (
                                        <Option key={item.area_id} value={item.area_id}>{item.name}</Option>
                                    )
                                })
                            }
                        </Select>
                        <Select value={this.state.school} style={{ width: 200 }} onChange={school=>{
                            this.setState({school, page: 1}, ()=>{
                                this.getTestListHandle()
                            })
                        }}>
                            {
                                this.state.schoolList.map(item => {
                                    return(
                                        <Option key={item.school_id} value={item.school_id}>{item.name}</Option>
                                    )
                                })
                            }
                        </Select>
                        <Select value={this.state.grade} style={{ width: 100 }} onChange={grade=>{
                            this.setState({grade, page:1},()=>{
                                this.getTestListHandle()
                            })
                        }}>
                            {
                                dictionary.grade.map(item =>{
                                    return(
                                        <Option key={item.id} value={item.id}>{item.name}</Option>
                                    )
                                })
                            }
                        </Select>
                        <RangePicker onChange={(a,b) =>{
                            console.log(a,b)
                            console.log(a[0].format('X'))
                            this.setState({page: 1, start_at: a[0].format('X'), end_at: a[1].format('X')},()=>{
                                this.getTestListHandle()
                            })
                        }} />
                    </div >
                    <div style={{paddingTop:'50px',width:'1230px',margin:'auto', minHeight:'100px'}}>
                    {
                        this.state.textPaperList.contents.map(item=>{
                            return(
                                <div key={item.se_id} style={{width:'100%',height:'120px',border: '1px solid #c4cdd4',padding:'0 18px 0 92px', marginBottom:'15px', display:'flex', flexDirection:'column',justifyContent:'space-around'}}>
                                    <div style={{fontSize:'20px', fontWeight:'800'}}>{item.me_name}</div>
                                    <div style={{display:'flex',justifyContent:'space-between'}}>
                                        <div style={{display:'flex',width:'500px', justifyContent:'space-between'}}>
                                            <div>考试时间：{
                                                moment((item.created_at)._i).format('YYYY-MM-DD')
                                            }</div>
                                            <div >年级：{item.grade_name}</div>
                                            <div>科目：{item.course_name}</div>
                                        </div>
                                        <Button.Group >
                                            {/* <Button>
                                                收藏
                                            </Button> */}
                                            <Button onClick={
                                                () => {
                                                    this.showModal(item.se_id)
                                                }
                                            }>
                                                试卷分析
                                            </Button >
                                            {/* <Button>
                                                选题组卷
                                            </Button> */}
                                            <Button  
                                                onClick={
                                                () => {
                                                    //下载
                                                    downLoadTextPaper(item.se_id,item.se_name)
                                                }
                                                }
                                                disabled = {!item.canDownloadFile}
                                            >
                                                下载试卷
                                            </Button>
                                        </Button.Group>
                                    </div>
                                </div>
                            )
                        })
                    }
                    <Pagination onChange={page=>{
                        this.setState({page},()=>{
                            this.getTestListHandle()
                        })
                    }}
                    current={this.state.page} 
                    total={this.state.textPaperList.count} 
                    style={{display:'flex',justifyContent:'flex-end'}}                    
                    /> 
                    </div>
                </div>
                <Modal
                    title="试卷分析"
                    visible={this.state.visible}
                    onOk={this.handleOk}
                    onCancel={this.handleCancel}
                    width={1000}
                    >
                        <Row gutter={16} style={{height: 400}}>
                        <Col span={12}>
                            <Card title="总体分布分析" bordered={false}>
                                <Table dataSource={this.state.paperAmountDistribution} columns={this.columns} rowKey="name"  pagination={{ pageSize: 3 }}>
                                </Table>
                            </Card>
                        </Col>
                        <Col span={12}>
                            <ReactEcharts option={this.getOption()}/>
                        </Col>
                        </Row>
                    <div>
                        <p>知识点分析</p>
                            <table style={{border: "1", cellpadding: "0", cellspacing: "0", width:"100%", textAlign: "center"}}>
                                <thead>
                                    <tr style={{border:"1px solid #ccc"}}>
                                        <th style={{border:"1px solid #ccc"}}>序号</th>
                                        <th style={{border:"1px solid #ccc"}}>知识点</th>
                                        <th style={{border:"1px solid #ccc"}}>分值</th>
                                        <th style={{border:"1px solid #ccc"}}>分值占比</th>
                                        <th style={{border:"1px solid #ccc"}}>对应题号</th>
                                    </tr>
                                </thead>
                            <tbody>
                                {
                                    this.state.knowledgesAnalysis.map((prod, index) => {
                                        return (
                                            <tr style={{border:"1px solid #ccc"}} key={prod.name}>
                                                <td style={{border:"1px solid #ccc"}}>{index+1}</td>
                                                <td style={{border:"1px solid #ccc"}}>{prod.name}</td>
                                                <td style={{border:"1px solid #ccc"}}>{prod.score}</td>
                                                <td style={{border:"1px solid #ccc"}}>{prod.scorePercentage}</td>
                                                <td style={{border:"1px solid #ccc"}}>{prod.topicSerialNumber}</td>
                                            </tr>
                                        )
                                    })
                                }
                            </tbody>
                        </table>
                    </div>
                </Modal>
                </Content>
                <Footer style={{ textAlign: 'center', backgroundColor: "#f3faff" }}></Footer>
            </Layout>
        )
    }
}

export default SchoolGroup