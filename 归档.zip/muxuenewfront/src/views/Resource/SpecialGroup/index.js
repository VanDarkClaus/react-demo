import React, { Component } from 'react'
import { Tabs, Layout, Card, Descriptions, Radio, Input, Button } from 'antd'

const { TabPane } = Tabs
const { Content, Footer } = Layout

// 改变选中标签页返回函数
function callback(key) {
    console.log(key)
}

export default class SpecialGroup extends Component {

    state = {
        indeterminate: true,
        checkAll: false
    }

    render() {
        return (
            <Layout className="layout">
                <Content style={{ padding: '0 15%', backgroundColor: "#f3faff" }}>
                <div style={{ background: '#fff', margin: 24, minHeight: 280 }}>
                <Tabs defaultActiveKey="1" onChange={callback} style={{marginLeft: "40px", marginRight: "40px"}}>
                    <TabPane tab="试卷设置" key="1">
                    <Card bordered={false}  style={{borderBottom: "1px dashed #ccc"}} >
                        <span style={{fontWeight: 600}}>试卷名称</span>
                        <Input value="2018-11-04初中数学月考卷" style={{marginTop: 20}} />
                    </Card>
                    <Card bordered={false}  style={{borderBottom: "1px dashed #ccc"}} > 
                        <span style={{fontWeight: 600}}>试卷类别</span>
                        <Descriptions column={1} style={{marginTop: 20}}>
                            <Descriptions.Item>
                                <Radio.Group defaultValue="a" buttonStyle="solid" style={{marginLeft: "35px"}} >
                                    <Radio.Button value="a">同步练习</Radio.Button>
                                    <Radio.Button value="b">单元测试</Radio.Button>
                                    <Radio.Button value="c">月考试卷</Radio.Button>
                                    <Radio.Button value="d">期中考试</Radio.Button>
                                    <Radio.Button value="e">期末考试</Radio.Button>
                                    <Radio.Button value="f">入学测验</Radio.Button>
                                    <Radio.Button value="g">模拟题</Radio.Button>
                                    <Radio.Button value="h">其他题型</Radio.Button>
                                </Radio.Group>
                            </Descriptions.Item>
                        </Descriptions>
                    </Card>
                    <Card bordered={false}  style={{borderBottom: "1px dashed #ccc"}} >
                        <span style={{fontWeight: 600}}>试卷题型题量</span>
                        <Button style={{display: "block", marginTop: 20, marginLeft:35}}>自定义</Button>
                    </Card>
                    <Card bordered={false}> 
                        <span style={{fontWeight: 600}}>试卷难度</span>
                        <Descriptions column={1} style={{marginTop: 20}}>
                            <Descriptions.Item>
                                <Radio.Group defaultValue="a" buttonStyle="solid" style={{marginLeft: "35px"}} >
                                    <Radio.Button value="a">容易</Radio.Button>
                                    <Radio.Button value="b">较易</Radio.Button>
                                    <Radio.Button value="c">一般</Radio.Button>
                                    <Radio.Button value="d">较难</Radio.Button>
                                    <Radio.Button value="e">困难</Radio.Button>
                                </Radio.Group>
                            </Descriptions.Item>
                        </Descriptions>
                    </Card>
                    </TabPane>

                    <TabPane tab="出题范围" key="2">
                        待开发
                    </TabPane>
                </Tabs>
                </div>
                </Content>
                <Footer style={{ textAlign: 'center', backgroundColor: "#f3faff" }}></Footer>
            </Layout>
        )
    }
}
