import React, { Component } from 'react'
import {smartTeach} from 'routes'
import {Switch, Redirect, Route} from 'react-router-dom'

export default class index extends Component {
    render() {
        return (
            <Switch>
            {
                smartTeach.map(item =>{
                    return <Route
                            path = {item.path}
                            key = {item.path}
                            component = {item.component}
                            exact = {item.exact}
                            />
                })
            }
            <Redirect from = '/admin/testcenter/studybigdata/smartteach' to = '/admin/testcenter/studybigdata/smartteach/teachingone' exact/>
            <Redirect to = '/404'/>
        </Switch>
        )
    }
}
