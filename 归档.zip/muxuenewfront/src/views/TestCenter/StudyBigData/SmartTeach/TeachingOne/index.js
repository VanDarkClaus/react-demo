import React, { Component } from 'react'

export default class index extends Component {
    render() {
        const url =`http://www.mymuxue.com//build/index.html#/TeachingOne?username=${JSON.parse(sessionStorage.getItem('old')).username}&se_id=${JSON.parse(sessionStorage.getItem('old')).item.se_id}`
        console.log(url)
        return (
            <div style={{overflow: 'hidden', width:'100%', height:'1500px'}}>
                <iframe style={{border:0, marginTop:'-140px', width:"100%",height:'1500px'}} src={url}/>
            </div>
        )
    }
}
