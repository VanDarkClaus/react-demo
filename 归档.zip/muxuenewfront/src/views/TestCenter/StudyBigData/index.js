import React, { Component } from 'react'
import { getExamListRequest, cityAreasRequest, schoolsRequest, exmExamSchoolsRequest, exmExamclassesRequest, exmExamStudentsRequest, productMistakesCollection } from '../../../requests'
import { Layout, Button, Select, DatePicker, Modal, Pagination, Checkbox } from 'antd'
// import './SchoolGroup.less'
import { connect } from 'react-redux'
import moment from 'moment'
import dictionary from 'utils/dictionary.json'
import {isShowByRoot} from 'utils/isShowByRoot'

const { Content, Footer } = Layout
const { Option } = Select
const { RangePicker } = DatePicker




@connect()
class SchoolGroup extends Component {

    constructor() {
        super()
        this.state = {
            h_me_id: '',
            textPaperList: {
                contents: []
            },
            visible: false,
            difficultyAnalysis: [],
            knowledgesAnalysis: [],
            paperAmountDistribution: [],
            data: [],

            wrongVisible: false,

            privince: '510000',
            city: '',
            area: '',
            school: '',
            grade: '203',
            start_at: '',
            end_at: '',

            cityIndex: 0,

            cityList: [],
            areaList: [],
            schoolList: [],
            gradeList: [],

            wrongSchool_id: '',
            wrongClass_id: '',
            wrongStudent_id: '',
            wrongSchoolList: [],
            wrongClassList: [],
            wrongStudentsList: [],
            knowledge_point: 0, 
            answer: 0,
            analysis: 0,
            expand: 0, 
            selfProposition: 0,


            page: 1
        }

    }


    handleOk = e => {
        console.log(e);
        this.setState({
            visible: false,
        });
    };

    handleCancel = e => {
        console.log(e);
        this.setState({
            visible: false,
        });
    };
    showModal = () => {
        this.setState({
            visible: true,
        });
    };

    // 获取试卷列表数据
    getTestListHandle() {
        const { city, area, school, grade, page, start_at, end_at } = this.state
        getExamListRequest(area, city, school, grade, 10, page, start_at, end_at)
            .then(resp => {
                this.setState({
                    textPaperList: resp.body
                })
            })
    }
    //通过省请求到市和区
    getCityHandle() {
        cityAreasRequest(this.state.privince)
            .then(res => {

                this.setState({ cityList: res.body, city: res.body[0].area_id, areaList: res.body[0].nodes, area: res.body[0].nodes.length ? res.body[0].nodes[0].area_id : '' }, () => {
                    this.getGradeHandle()
                })
            })
    }
    //通过区请求到学校
    getGradeHandle() {
        schoolsRequest(this.state.area)
            .then(res => {
                // console.log(res)
                this.setState({ schoolList: res.body, school: res.body.length ? res.body[0].school_id : '', page: 1 }, () => {
                    this.getTestListHandle()
                })
            })
    }
    //通过se_id和schoolid请求到班级
    exmExamclassesHandle() {
        exmExamclassesRequest(this.state.se_id, this.state.wrongSchool_id)
            .then(res => {
                res.body.unshift({ class_id: '', class_name: '全部班级' })
                this.setState({ wrongClassList: res.body, wrongClass_id: res.body[0].class_id }, () => {
                    this.exmExamStudentsHandle()
                })
            })
    }
    //获取学生
    exmExamStudentsHandle() {
        exmExamStudentsRequest(this.state.se_id, this.state.wrongClass_id, this.state.wrongSchool_id)
            .then(res => {
                res.body.unshift({ student_id: '', student_name: '全部学生' })
                this.setState({ wrongStudentsList: res.body, wrongStudent_id: res.body[0].student_id })
            })
    }
    componentDidMount = async () => {

        await cityAreasRequest(this.state.privince)
            .then(res => {
                this.setState({ cityList: res.body, city: res.body[0].area_id, areaList: res.body[0].nodes, area: res.body[0].nodes[0].area_id })
            })
        await schoolsRequest(this.state.area)
            .then(res => {
                this.setState({ schoolList: res.body, school: res.body.length?res.body[0].school_id:'' })
            })
        this.getTestListHandle()

    }



    render() {
        // this.state.wrongStudentsList.push({student_id:'',student_name:'全部班级'})
        // this.state.wrongClassList.push({class_id:0,class_name:'全部班级'})
        return (
            <Layout className="layout">
                <Content style={{ backgroundColor: "#f3faff" }}>
                    <div style={{ background: '#fff', width: '1450px', margin: 'auto', minHeight: 280, paddingTop: '20px', }}>
                        <div style={{ textAlign: "center", width: '1360px', height: '55px', display: 'flex', justifyContent: 'space-around', alignItems: 'center', background: '#f3faff', border: '1px solid #c2cdd3', margin: 'auto' }}>
                            <Button type='primary'>全国</Button>
                            <Select value={this.state.privince} style={{ width: 100 }} onChange={privince => {
                                this.setState({ privince }, () => {
                                    this.getCityHandle()
                                })
                            }}>
                                {
                                    dictionary.provinceDict.map(item => {
                                        return (
                                            <Option key={item.area_id} value={item.area_id}>{item.name}</Option>
                                        )
                                    })
                                }
                            </Select>
                            <Select value={this.state.city} style={{ width: 100 }} onChange={city => {
                                let cityIndex
                                this.state.cityList.some((item, index) => {
                                    cityIndex = index
                                    return item.area_id === city
                                })
                                this.setState({ city, areaList: this.state.cityList[cityIndex].nodes, area: this.state.cityList[cityIndex].nodes.length ? this.state.cityList[cityIndex].nodes[0].area_id : '' }, () => {
                                    this.getGradeHandle()
                                })
                            }}>
                                {
                                    this.state.cityList.map(item => {
                                        return (
                                            <Option key={item.area_id} value={item.area_id}>{item.name}</Option>
                                        )
                                    })
                                }
                            </Select>
                            <Select value={this.state.area} style={{ width: 100 }} onChange={area => {
                                this.setState({ area }, () => {
                                    this.getGradeHandle()
                                })
                            }}>
                                {
                                    this.state.areaList.map(item => {
                                        return (
                                            <Option key={item.area_id} value={item.area_id}>{item.name}</Option>
                                        )
                                    })
                                }
                            </Select>
                            <Select value={this.state.school} style={{ width: 200 }} onChange={school => {
                                this.setState({ school, page: 1 }, () => {
                                    this.getTestListHandle()
                                })
                            }}>
                                {
                                    this.state.schoolList.map(item => {
                                        return (
                                            <Option key={item.school_id} value={item.school_id}>{item.name}</Option>
                                        )
                                    })
                                }
                            </Select>
                            <Select value={this.state.grade} style={{ width: 100 }} onChange={grade => {
                                this.setState({ grade, page: 1 }, () => {
                                    this.getTestListHandle()
                                })
                            }}>
                                {
                                    dictionary.grade.map(item => {
                                        return (
                                            <Option key={item.id} value={item.id}>{item.name}</Option>
                                        )
                                    })
                                }
                            </Select>
                            <RangePicker onChange={(a, b) => {
                                console.log(a, b)
                                console.log(a[0].format('X'))
                                this.setState({ page: 1, start_at: a[0].format('X'), end_at: a[1].format('X') }, () => {
                                    this.getTestListHandle()
                                })
                            }} />
                        </div >
                        <div style={{ paddingTop: '50px', width: '1230px', margin: 'auto', minHeight: '100px' }}>
                            {
                                this.state.textPaperList.contents.map(item => {
                                    return (
                                        <div key={item.se_id} style={{ width: '100%', height: '120px', border: '1px solid #c4cdd4', padding: '0 18px 0 92px', marginBottom: '15px', display: 'flex', flexDirection: 'column', justifyContent: 'space-around' }}>
                                            <div style={{ fontSize: '20px', fontWeight: '800' }}>{item.me_name}</div>
                                            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                                <div style={{ display: 'flex', width: '500px', justifyContent: 'space-between' }}>
                                                    <div>考试时间：{
                                                        moment((item.created_at)._i).format('YYYY-MM-DD')
                                                    }</div>
                                                    <div >年级：{item.grade_name}</div>
                                                    <div>科目：{item.course_name}</div>
                                                </div>
                                                <Button.Group >
                                                    <Button type="primary" style={isShowByRoot('mark_exam_btn')} onClick={
                                                        () => {
                                                            // this.setState({h_me_id:item.me_id})
                                                            window.location.href = 'http://yuejuan.mymuxue.com/qiq/navigator/ExamMark_UE_OR/ExamMark_UE_OR.html'
                                                        }}>
                                                        进入评卷
                                            </Button >
                                                    <Button type="primary" style={isShowByRoot('view_learning_btn')} onClick={() => {
                                                        this.showModal()
                                                        this.setState({ h_me_id: item.me_id })
                                                    }}>
                                                        查看学情
                                            </Button>
                                                    <Button
                                                        type="primary"
                                                        style={isShowByRoot('export_wrong_btn')}
                                                        onClick={
                                                            async () => {
                                                                this.setState({ se_id: item.se_id, wrongVisible: true })
                                                                await exmExamSchoolsRequest(item.se_id)
                                                                    .then(res => {
                                                                        this.setState({ wrongSchoolList: res.body, wrongSchool_id: res.body.length ? res.body[0].school_id : '' })
                                                                    })
                                                                await exmExamclassesRequest(item.se_id, this.state.wrongSchool_id)
                                                                    .then(res => {
                                                                        res.body.unshift({ class_id: '', class_name: '全部班级' })
                                                                        this.setState({ wrongClassList: res.body, wrongClass_id: res.body.length ? res.body[0].class_id : '' })
                                                                    })
                                                                await exmExamStudentsRequest(this.state.se_id, this.state.wrongClass_id, this.state.wrongSchool_id)
                                                                    .then(res => {
                                                                        res.body.unshift({ student_id: '', student_name: '全部学生' })
                                                                        this.setState({ wrongStudentsList: res.body, wrongStudent_id: res.body.length ? res.body[0].student_id : '' })
                                                                    })
                                                            }}
                                                    >
                                                        导出错题
                                            </Button>
                                            <Button type='primary' style={isShowByRoot('smart_teach_btn')} onClick={async()=>{
                                                const username = JSON.parse(sessionStorage.getItem('token')).username
                                               await sessionStorage.setItem('old',JSON.stringify({item, username}))
                                                console.log('http://120.79.205.35:9001/v1/teach-package/first-preview?user_name=' + JSON.parse(sessionStorage.getItem('old')).username  + '&se_id=' + JSON.parse(sessionStorage.getItem('old')).item.se_id,)
                                                this.props.history.push('/admin/testcenter/studybigdata/smartteach')
                                            }}>智能授课</Button>
                                                </Button.Group>
                                            </div>
                                        </div>
                                    )
                                })
                            }
                            <Pagination onChange={page => {
                                this.setState({ page }, () => {
                                    this.getTestListHandle()
                                })
                            }}
                                current={this.state.page}
                                total={this.state.textPaperList.count}
                                style={{ display: 'flex', justifyContent: 'flex-end' }}
                            />
                        </div>
                    </div>
                    {/* 学情列表模态框 */}
                    <Modal
                        title="学情列表"
                        visible={this.state.visible}
                        onOk={this.handleOk}
                        onCancel={this.handleCancel}
                        width={500}
                        height={500}
                        footer={
                            [] // 设置footer为空，去掉 取消 确定默认按钮
                        }

                    >
                        <div style={{ display: 'flex', justifyContent: 'center', flexDirection:'column', alignItems: 'center' }}>

                            <div style={{width:'100%', height:'100px', display: 'flex', justifyContent: 'space-around', alignItems: 'center'}}>

                                <Button size='large' type='primary' onClick={() => { this.props.history.push(`/admin/testcenter/studybigdata/overallreport?me_id=${this.state.h_me_id}`) }} style={{ margin: '5px 10px', }}>总体报告</Button>
                                <Button size='large' type='primary' onClick={() => { this.props.history.push(`/admin/testcenter/studybigdata/classreport?me_id=${this.state.h_me_id}`) }} style={{ margin: '5px 10px', }}>班级报告</Button>
                            </div>
                            <div style={{width:'100%', height:'100px', display: 'flex', justifyContent: 'space-around', alignItems: 'center'}}>
                                <Button size='large' type='primary' onClick={() => { this.props.history.push(`/admin/testcenter/studybigdata/schoolreport?me_id=${this.state.h_me_id}`) }} style={{ margin: '5px 10px', }}>学校报告</Button>
                                <Button size='large' type='primary' onClick={() => { this.props.history.push(`/admin/testcenter/studybigdata/personalreport?me_id=${this.state.h_me_id}`) }} style={{ margin: '5px 10px', }}>个人报告</Button>
                            </div>
                        </div>
                    </Modal>

                    <Modal
                        title="导出错题集"
                        visible={this.state.wrongVisible}
                        onOk={() => {
                            let { knowledge_point, answer, analysis, expand, selfProposition, se_id, wrongSchool_id, wrongStudent_id, wrongClass_id } = this.state
                            productMistakesCollection(knowledge_point, answer, analysis, expand, selfProposition, se_id, wrongSchool_id, wrongStudent_id, wrongClass_id)
                                .then(res => {
                                    console.log(res)
                                })
                        }}
                        okText='导出'
                        onCancel={() => { this.setState({ wrongVisible: false }) }}
                        width={500}
                    >
                        <div style={{ margin: '20px 5px' }}>
                            <span style={{ fontSize: '16px', fontWeight: '500', marginRight: '20px' }}>内容: </span>
                            <Checkbox value="A" onChange={(e) => {
                                this.setState({ knowledge_point: e.target.checked ? 1 : 0 })
                            }}>知识点</Checkbox>
                            <Checkbox value="b" onChange={(e) => {
                                this.setState({ answer: e.target.checked ? 1 : 0 })
                            }}>答案</Checkbox>
                            <Checkbox value="c" onChange={(e) => {
                                this.setState({ analysis: e.target.checked ? 1 : 0 })
                            }}>解析</Checkbox>
                            <Checkbox value="d" onChange={(e) => {
                                this.setState({ expand: e.target.checked ? 1 : 0 })
                            }}>拓展题</Checkbox>
                            <Checkbox value="e" onChange={(e) => {
                                this.setState({ selfProposition: e.target.checked ? 1 : 0 })
                            }}>自命题</Checkbox>
                        </div>
                        <div style={{ margin: '20px 5px' }}>
                            <span style={{ fontSize: '16px', fontWeight: '500', marginRight: '20px' }}>学校: </span>
                            <Select value={this.state.wrongSchool_id} style={{ width: '300px' }} onChange={wrongSchool_id => {
                                this.setState({ wrongSchool_id }, () => {
                                    this.exmExamclassesHandle()
                                })
                            }}>
                                {
                                    this.state.wrongSchoolList.map(item => {
                                        return (
                                            <Option key={item.school_id} value={item.school_id}>{item.school_name}</Option>
                                        )
                                    })
                                }
                            </Select>
                        </div>
                        <div style={{ margin: '20px 5px' }}>
                            <span style={{ fontSize: '16px', fontWeight: '500', marginRight: '20px' }}>班级: </span>
                            <Select style={{ width: '300px' }} value={this.state.wrongClass_id} onChange={wrongClass_id => {
                                this.setState({ wrongClass_id }, () => {
                                    this.exmExamStudentsHandle()
                                })
                            }}>
                                {
                                    this.state.wrongClassList.map(item => {
                                        return (
                                            <Option key={item.class_id} value={item.class_id}>{item.class_name}</Option>
                                        )
                                    })
                                }
                            </Select>
                        </div>
                        <div style={{ margin: '20px 5px' }}>
                            <span style={{ fontSize: '16px', fontWeight: '500', marginRight: '20px' }}>学生: </span>
                            <Select style={{ width: '300px' }} value={this.state.wrongStudent_id} onChange={wrongStudent_id => {
                                this.setState({ wrongStudent_id })
                            }}>
                                {
                                    this.state.wrongStudentsList.map(item => {
                                        return (
                                            <Option key={item.student_id} value={item.student_id}>{item.student_name}</Option>
                                        )
                                    })
                                }
                            </Select>
                        </div>
                    </Modal>
                </Content>
                <Footer style={{ textAlign: 'center', backgroundColor: "#f3faff" }}></Footer>
            </Layout>
        )
    }
}

export default SchoolGroup
