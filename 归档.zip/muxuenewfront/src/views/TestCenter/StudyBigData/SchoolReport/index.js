import React, { Component, createRef } from 'react'
import { Select, Button, BackTop, Icon, Table } from 'antd'
import {
    exportPdfRequest, examSchoolsRequest, reportDetailRequest, reportSchaScoreSectionRequest, reportSchaClassAvgRequest, reportSchaSubTotalRequest,
    reportSchaTotalScorRequest, reportSchaRangeRankRequest, reportSchaClsSubAvgRequest, reportSchaClsSubTotalRequest
} from 'requests'
import moment from 'moment'
import echarts from 'echarts'

const { Option } = Select
const totalScoreColumns = [
    {
        title: '科目',
        dataIndex: 'subject_name'
    }, {
        title: '时间满分',
        dataIndex: 'full_score'
    }, {
        title: '实考人数',
        dataIndex: 'student_count'
    }, {
        title: '最高分',
        dataIndex: 'max_score'
    }, {
        title: '最低分',
        dataIndex: 'min_score'
    }, {
        title: '平均分',
        dataIndex: 'school_avg_score'
    },
    // {
    //     title: '中位数',
    //     dataIndex: ''
    // },  {
    //     title: '全距',
    //     dataIndex: ''
    // }, {
    //     title: '标准差',
    //     dataIndex: ''
    // }, {
    //     title: '难度',
    //     dataIndex: ''
    // }, {
    //     title: '信度',
    //     dataIndex: ''
    // }, {
    //     title: '超均率',
    //     dataIndex: ''
    // },
]
const scoreFiveColumns = [
    {
        title: '班级',
        dataIndex: 'name'
    }, {
        title: '前5%',
        children: [
            {
                title: '人数',
                dataIndex: 's1_count'
            }, {
                title: '比例(%)',
                dataIndex: 's1_rate'
            }
        ]
    }, {
        title: '前5%-25%',
        children: [
            {
                title: '人数',
                dataIndex: 's2_count'
            }, {
                title: '比例(%)',
                dataIndex: 's2_rate'
            }
        ]
    }, {
        title: '后5%-25%',
        children: [
            {
                title: '人数',
                dataIndex: 's3_count'
            }, {
                title: '比例(%)',
                dataIndex: 's3_rate'
            }
        ]
    }, {
        title: '后5%',
        children: [
            {
                title: '人数',
                dataIndex: 's4_count'
            }, {
                title: '比例(%)',
                dataIndex: 's4_rate'
            }
        ]
    }

]
const eachClassColumns = [
    {
        title: '班级',
        dataIndex: 'class_name',
    }, {
        title: '平均分',
        dataIndex: 'avg_score',
    }, {
        title: '最低分',
        dataIndex: 'min_score',
    }, {
        title: '最高分',
        dataIndex: 'max_score',
    }, {
        title: '优秀率(%)',
        dataIndex: 'good_rate',
    }, {
        title: '良好率(%)',
        dataIndex: 'medium_rate',
    }, {
        title: '及格率(%)',
        dataIndex: 'pass_rate',
    }, {
        title: '低分率(%)',
        dataIndex: 'low_rate',
    }
]

export default class index extends Component {
    constructor() {
        super()
        const arr = window.location.href.split('/')
        const me_id = arr[arr.length - 1].slice(19)
        this.sumScoreSectionRef = createRef()
        this.avgScoreSectionRef = createRef()
        this.subTotalRef = createRef()
        this.subAvgRef = createRef()
        this.fourRateRef = createRef()
        this.state = {
            schoolList: [],
            me_id,
            school_id: '',
            sumScoreData: [],
            avgScoreData: [],
            subTotalData: [],
            totalScoreData: [],
            header_details: {
                subjects: []
            },
            course_id: '',
            course_name: '',
            subAvgData: [],
            fourRateData: []
        }
    }
    //获取学校
    examSchools = () => {
        examSchoolsRequest(this.state.me_id)
            .then(res => {
                this.setState({ schoolList: res.body }, () => {
                    this.reportSchaScoreSectionHandle()
                    this.reportSchaClassAvgHandle()
                    this.reportSubTotalHandle()
                })
            })
    }
    //获取总分分段人数分布
    reportSchaScoreSectionHandle = () => {
        reportSchaScoreSectionRequest(this.state.me_id, this.state.school_id)
            .then(res => {
                this.setState({ sumScoreData: res.body }, () => {
                    this.setCompareKnowledgeCharts()
                })
            })
    }
    //获取各班平均分统计
    reportSchaClassAvgHandle = () => {
        reportSchaClassAvgRequest(this.state.me_id, this.state.school_id)
            .then(res => {
                this.setState({ avgScoreData: res.body }, () => {
                    this.setScoreAvgCharts()
                })
            })
    }
    //获取各科四率统计
    reportSubTotalHandle = () => {
        reportSchaSubTotalRequest(this.state.me_id, this.state.school_id)
            .then(res => {
                this.setState({ subTotalData: res.body }, () => {
                    this.subTotalCharts()
                })
            })
    }
    //获取总分及各科得分概述
    totalScoreHandle = () => {
        reportSchaTotalScorRequest(this.state.me_id, this.state.school_id)
            .then(res => {
                this.setState({ totalScoreData: res.body })
            })
    }
    //获取//总分前后5%、25%人数各校分布比例情况
    rangeRankHandle = () => {
        reportSchaRangeRankRequest(this.state.me_id, this.state.school_id)
            .then(res => {
                this.setState({ rangeRankData: res.body })
            })
    }
    //获取各班各科平均分
    subAvgHandle = () => {
        reportSchaClsSubAvgRequest(this.state.me_id, this.state.course_id, this.state.school_id)
            .then(res => {
                this.setState({ subAvgData: res.body }, () => {
                    this.setSubAvgCharts()
                })
            })
    }
    //获取各科各班四率统计
    fourRateHandle = () => {
        reportSchaClsSubTotalRequest(this.state.me_id, this.state.course_id, this.state.school_id)
            .then(res => {
                console.log(res)
                this.setState({ fourRateData: res.body }, () => {
                    this.fourRateCharts()
                })
            })
    }
    //设置总分分段人数分布比较图
    setCompareKnowledgeCharts = () => {
        const mycharts = echarts.init(this.sumScoreSectionRef.current)
        mycharts.setOption({
            color: ['#4cd7ff', '#fdb82d', '#c23531', '#dddddd'],
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross',
                    crossStyle: {
                        color: '#dedede'
                    }
                }
            },
            toolbox: {
                feature: {
                    dataView: { show: true, readOnly: false },
                    magicType: { show: true, type: ['line', 'bar'] },
                    restore: { show: true },
                    saveAsImage: { show: true }
                }
            },
            legend: {
                data: ['本校人数', '校比例']
            },
            xAxis: [
                {
                    type: 'category',
                    data: this.state.sumScoreData.reduce((sum, curr) => {
                        sum.push(curr.segmentation)
                        return sum
                    }, []),
                    axisPointer: {
                        type: 'shadow'
                    }
                }
            ],
            yAxis: [
                {
                    type: 'value',
                    name: '本校人数',
                    // min: 0,
                    // max: 80,
                    // interval: 20,
                    axisLabel: {
                        formatter: '{value}'
                    }
                },
                {
                    type: 'value',
                    name: '校比例',
                    // min: 0,
                    // max: 80,
                    // interval: 20,
                    axisLabel: {
                        formatter: '{value}%'
                    }
                },
            ],
            series: [
                {
                    name: '本校人数',
                    type: 'bar',
                    data: this.state.sumScoreData.reduce((sum, curr) => {
                        sum.push(curr.school_number)
                        return sum
                    }, []),
                },
                {
                    name: '校比例',
                    type: 'line',
                    data: this.state.sumScoreData.reduce((sum, curr) => {
                        sum.push(curr.school_rate)
                        return sum
                    }, []),
                    yAxisIndex: 1,

                }
            ]
        })
    }
    //各班平均分统计图
    setScoreAvgCharts = () => {
        const mycharts = echarts.init(this.avgScoreSectionRef.current)
        mycharts.setOption({
            color: ['#ffb435', '#0096fd', '#c23531', '#dddddd'],
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross',
                    crossStyle: {
                        color: '#dedede'
                    }
                }
            },
            toolbox: {
                feature: {
                    dataView: { show: true, readOnly: false },
                    magicType: { show: true, type: ['line', 'bar'] },
                    restore: { show: true },
                    saveAsImage: { show: true }
                }
            },
            legend: {
                data: ['平均分', '学校平均分']
            },
            xAxis: [
                {
                    type: 'category',
                    data: this.state.avgScoreData.reduce((sum, curr) => {
                        sum.push(curr.name)
                        return sum
                    }, []),
                    axisPointer: {
                        type: 'shadow'
                    }
                }
            ],
            yAxis: [
                {
                    type: 'value',
                    name: '平均分',
                    // min: 0,
                    // max: 80,
                    // interval: 20,
                    axisLabel: {
                        formatter: '{value}'
                    }
                }
            ],
            series: [
                {
                    name: '平均分',
                    type: 'bar',
                    data: this.state.avgScoreData.reduce((sum, curr) => {
                        sum.push(curr.avg_score)
                        return sum
                    }, []),

                }, {
                    name: '学校平均分',
                    type: 'line',
                    data: this.state.avgScoreData.reduce((sum, curr) => {
                        sum.push(curr.school_avg_score)
                        return sum
                    }, []),
                }
            ]
        })
    }
    //设置总分分段人数分布比较图
    subTotalCharts = () => {
        const mycharts = echarts.init(this.subTotalRef.current)
        mycharts.setOption({
            color: ['#ffeb4c', '#4cd7ff', '#30ffcb', '#ff744b'],
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross',
                    crossStyle: {
                        color: '#dedede'
                    }
                }
            },
            toolbox: {
                feature: {
                    dataView: { show: true, readOnly: false },
                    magicType: { show: true, type: ['line', 'bar'] },
                    restore: { show: true },
                    saveAsImage: { show: true }
                }
            },
            legend: {
                data: ['优秀[125,150]', '良好[105,125]', '合格[90,105]', '待合格[0,90]']
            },
            xAxis: [
                {
                    type: 'category',
                    data: this.state.subTotalData.reduce((sum, curr) => {
                        sum.push(curr.subject_name)
                        return sum
                    }, []),
                    axisPointer: {
                        type: 'shadow'
                    },
                }
            ],
            yAxis: [
                {
                    type: 'value',
                    name: '分',
                    // min: 0,
                    // max: 80,
                    // interval: 20,
                    axisLabel: {
                        formatter: '{value}'
                    }
                }
            ],
            series: [
                {
                    name: '优秀[125,150]',
                    type: 'bar',
                    data: this.state.subTotalData.reduce((sum, curr) => {
                        sum.push(curr.good_rate)
                        return sum
                    }, []),
                }, {
                    name: '良好[105,125]',
                    type: 'bar',
                    data: this.state.subTotalData.reduce((sum, curr) => {
                        sum.push(curr.medium_rate)
                        return sum
                    }, []),
                }, {
                    name: '合格[90,105]',
                    type: 'bar',
                    data: this.state.subTotalData.reduce((sum, curr) => {
                        sum.push(curr.pass_rate)
                        return sum
                    }, []),
                }, {
                    name: '待合格[0,90]',
                    type: 'bar',
                    data: this.state.subTotalData.reduce((sum, curr) => {
                        sum.push(curr.low_rate)
                        return sum
                    }, []),
                }
            ]
        })
    }
    //设置各科平均分统计图
    setSubAvgCharts = () => {
        const mycharts = echarts.init(this.subAvgRef.current)
        mycharts.setOption({
            color: ['#ffb435', '#0096fd', '#c23531', '#dddddd'],
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross',
                    crossStyle: {
                        color: '#dedede'
                    }
                }
            },
            toolbox: {
                feature: {
                    dataView: { show: true, readOnly: false },
                    magicType: { show: true, type: ['line', 'bar'] },
                    restore: { show: true },
                    saveAsImage: { show: true }
                }
            },
            legend: {
                data: ['班级平均分', '学校平均分']
            },
            xAxis: [
                {
                    type: 'category',
                    data: this.state.subAvgData.reduce((sum, curr) => {
                        sum.push(curr.class_name)
                        return sum
                    }, []),
                    axisPointer: {
                        type: 'shadow'
                    }
                }
            ],
            yAxis: [
                {
                    type: 'value',
                    name: '平均分',
                    // min: 0,
                    // max: 80,
                    // interval: 20,
                    axisLabel: {
                        formatter: '{value}'
                    }
                }
            ],
            series: [
                {
                    name: '班级平均分',
                    type: 'bar',
                    data: this.state.subAvgData.reduce((sum, curr) => {
                        sum.push(curr.avg_score)
                        return sum
                    }, []),

                }, {
                    name: '学校平均分',
                    type: 'line',
                    data: this.state.subAvgData.reduce((sum, curr) => {
                        sum.push(curr.school_avg_score)
                        return sum
                    }, []),
                }
            ]
        })
    }
    //设置总分分段人数分布比较图
    fourRateCharts = () => {
        const mycharts = echarts.init(this.fourRateRef.current)
        mycharts.setOption({
            color: ['#ffeb4c', '#4cd7ff', '#30ffcb', '#ff744b'],
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross',
                    crossStyle: {
                        color: '#dedede'
                    }
                }
            },
            toolbox: {
                feature: {
                    dataView: { show: true, readOnly: false },
                    magicType: { show: true, type: ['line', 'bar'] },
                    restore: { show: true },
                    saveAsImage: { show: true }
                }
            },
            legend: {
                data: ['优秀[125,150]', '良好[105,125]', '合格[90,105]', '待合格[0,90]']
            },
            xAxis: [
                {
                    type: 'category',
                    data: this.state.fourRateData.reduce((sum, curr) => {
                        sum.push(curr.class_name)
                        return sum
                    }, []),
                    axisPointer: {
                        type: 'shadow'
                    },
                }
            ],
            yAxis: [
                {
                    type: 'value',
                    name: '分',
                    // min: 0,
                    // max: 80,
                    // interval: 20,
                    axisLabel: {
                        formatter: '{value}'
                    }
                }
            ],
            series: [
                {
                    name: '优秀[125,150]',
                    type: 'bar',
                    data: this.state.fourRateData.reduce((sum, curr) => {
                        sum.push(curr.good_rate)
                        return sum
                    }, []),
                }, {
                    name: '良好[105,125]',
                    type: 'bar',
                    data: this.state.fourRateData.reduce((sum, curr) => {
                        sum.push(curr.medium_rate)
                        return sum
                    }, []),
                }, {
                    name: '合格[90,105]',
                    type: 'bar',
                    data: this.state.fourRateData.reduce((sum, curr) => {
                        sum.push(curr.pass_rate)
                        return sum
                    }, []),
                }, {
                    name: '待合格[0,90]',
                    type: 'bar',
                    data: this.state.fourRateData.reduce((sum, curr) => {
                        sum.push(curr.low_rate)
                        return sum
                    }, []),
                }
            ]
        })
    }
    componentDidMount = async () => {
        //获取报告详情
        await reportDetailRequest(this.state.me_id)
            .then(res => {
                this.setState({ header_details: res.body, course_id: res.body.subjects[0].course_id, course_name: res.body.subjects[0].name })
            })
        //获取学校
        await examSchoolsRequest(this.state.me_id)
            .then(res => {
                this.setState({ schoolList: res.body })
            })
        await this.setState({ school_id: this.state.schoolList[0].school_id })
        this.reportSchaScoreSectionHandle()
        this.reportSchaClassAvgHandle()
        this.reportSubTotalHandle()
        this.totalScoreHandle()
        this.rangeRankHandle()
        this.subAvgHandle()
        this.fourRateHandle()
    }
    render() {
        const { schoolList } = this.state
        const { examDate, gradeName, examName } = this.state.header_details
        return (
            <div id='classreport' style={{ width: '1150px', margin: 'auto', background: '#fff', padding: '0 30px', boxSizing: 'border-box',paddingTop: '20px', }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: '1080px', margin: 'auto', border: '2px solid #cae4f5', height: '70px', padding: '0 15px', boxSizing: 'border-box' }}>
                    <div style={{ fontSize: '16px', width: '330px', whiteSpace: 'nowrap', textOverflow: 'ellipsis', overflow: 'hidden' }}>{examName}</div>

                    <Select style={{ width: '250px' }}
                        placeholder={schoolList.length ? schoolList[0].school_name : ''}
                        onChange={school_id => {
                            this.setState({ school_id }, () => {
                                this.reportSchaScoreSectionHandle()
                                this.reportSchaClassAvgHandle()
                                this.reportSubTotalHandle()
                                this.totalScoreHandle()
                                this.rangeRankHandle()
                                this.subAvgHandle()
                                this.fourRateHandle()
                            })
                        }}>
                        {
                            schoolList.map(item => {
                                return (
                                    <Option key={item.school_id} value={item.school_id}>{item.school_name}</Option>
                                )
                            })
                        }
                    </Select>
                    <div>考试时间：{moment(examDate * 1000).format('YYYY-MM-DD')}</div>
                    <div>年级：{gradeName}</div>
                    {/* <Button
                        type='primary'
                        onClick={() => {
                            exportPdfRequest(document.querySelector('#classreport').outerHTML, this.state.me_id)
                        }}
                    >下载</Button> */}
                </div>
                <div style={{ width: '150px', height: '40px', textAlign: 'center', lineHeight: '40px', color: '#fff', fontSize: '20px', background: '#0195ff', marginTop: '33px', borderRadius: '5px', marginBottom: '45px' }}>整体概述-全科</div>

                <h3 style={{ width: '100%', textAlign: 'center', marginTop: '55px', color: 'rgba(0, 0, 0, 0.65)' }}>各班平均分统计</h3>
                <div ref={this.avgScoreSectionRef} style={{ width: '100%', margin: 'auto', height: '400px' }}></div>
                <h3 style={{ width: '100%', textAlign: 'center', marginTop: '55px', color: 'rgba(0, 0, 0, 0.65)' }}>各科四率统计</h3>
                <div ref={this.subTotalRef} style={{ width: '100%', margin: 'auto', height: '300px' }}></div>
                <hr style={{ border: '1px solid #cae4f5' }} />
                <div style={{ width: '200px', height: '40px', textAlign: 'center', lineHeight: '40px', color: '#fff', fontSize: '20px', background: '#0195ff', marginTop: '33px', borderRadius: '5px', marginBottom: '45px' }}>总分及各科得分概况</div>
                <Table
                    style={{ marginBottom: '50px' }}
                    columns={totalScoreColumns}
                    dataSource={this.state.totalScoreData}
                    rowKey='subject_name'
                    bordered
                    size="middle"
                    pagination={false}
                />
                <hr style={{ border: '1px solid #cae4f5' }} />
                <div style={{ width: '200px', height: '40px', textAlign: 'center', lineHeight: '40px', color: '#fff', fontSize: '20px', background: '#0195ff', marginTop: '33px', borderRadius: '5px', marginBottom: '45px' }}>总分分数段人数分布</div>
                <h3 style={{ width: '100%', textAlign: 'center', marginTop: '55px', color: 'rgba(0, 0, 0, 0.65)' }}>总分分数段人数分布</h3>
                <div ref={this.sumScoreSectionRef} style={{ width: '100%', margin: 'auto', height: '400px' }}></div>
                <hr style={{ border: '1px solid #cae4f5' }} />
                <div style={{ width: '390px', height: '40px', textAlign: 'center', lineHeight: '40px', color: '#fff', fontSize: '20px', background: '#0195ff', marginTop: '33px', borderRadius: '5px', marginBottom: '45px' }}>总分前后5%、25%人数各校比例分布情况</div>
                <Table
                    columns={scoreFiveColumns}
                    dataSource={this.state.rangeRankData}
                    rowKey='name'
                    bordered
                    size="middle"
                    pagination={false}
                />
                <div style={{ marginBottom: '50px', background: '#fedf60', marginTop: '30px', width: '700px', padding: '10px 0 10px 30px', height: '65px', boxSizing: 'border-box' }}>
                    <p style={{ margin: '0' }}>说明:</p>
                    <p>表格中的比例为达到全市前N名的人数占全校达到全市前N名总人数的比例</p>
                </div>
                <hr style={{ border: '1px solid #cae4f5' }} />
                <div style={{ width: '470px', margin: 'auto', height: '40px', textAlign: 'center', lineHeight: '40px', color: '#fff', fontSize: '20px', background: '#0195ff', marginTop: '33px', borderRadius: '5px', marginBottom: '45px', display: 'flex', alignItems: 'center', justifyContent: 'space-around' }}>
                    <div>各班各科成绩分析</div>
                    <Select
                        style={{ width: '80px' }}
                        onChange={(course_id, option) => {
                            this.setState({ course_id, course_name: option.props.children }, () => {
                                this.subAvgHandle()
                                this.fourRateHandle()
                            })
                        }}
                        placeholder={this.state.header_details.subjects.length ? this.state.header_details.subjects[0].name : ''}
                    >
                        {
                            this.state.header_details.subjects.map(item => {
                                return <Option key={item.course_id}>{item.name}</Option>
                            })
                        }
                    </Select>
                </div>
                <div style={{ width: '300px', height: '40px', textAlign: 'center', lineHeight: '40px', color: '#fff', fontSize: '20px', background: '#0195ff', marginTop: '33px', borderRadius: '5px', marginBottom: '45px' }}>{this.state.course_name}各班四率统计</div>
                <Table
                    columns={eachClassColumns}
                    dataSource={this.state.fourRateData}
                    rowKey='class_name'
                    bordered
                    size="middle"
                    pagination={false}
                />
                <h3 style={{ width: '100%', textAlign: 'center', marginTop: '55px', color: 'rgba(0, 0, 0, 0.65)' }}>各班{this.state.course_name}平均分</h3>
                <div ref={this.subAvgRef} style={{ width: '100%', margin: 'auto', height: '400px' }}></div>
                <h3 style={{ width: '100%', textAlign: 'center', marginTop: '55px', color: 'rgba(0, 0, 0, 0.65)' }}>各班{this.state.course_name}四率统计</h3>
                <div ref={this.fourRateRef} style={{ width: '100%', margin: 'auto', height: '400px' }}></div>

                <BackTop style={{ position: 'fixed', width: '70px', height: '70px', right: '5%', top: '50%', background: '#0195ff', color: '#fff', display: 'flex', flexDirection: 'column', justifyContent: 'center', borderRadius: '50%' }}>
                    <Icon style={{ fontSize: '24px' }} type="vertical-align-top" />
                    <div style={{ textAlign: 'center' }}>回到顶部</div>
                </BackTop>
            </div>
        )
    }
}
