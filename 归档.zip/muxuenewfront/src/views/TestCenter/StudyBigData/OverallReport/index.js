import React, { Component } from 'react'
import { BackTop, Icon, Button, Card, Col, Row, Table, Popover, Select, Spin, Anchor, Progress, Modal } from 'antd'
import { exportPdfRequest, overallReport, reportDetailRequest } from 'requests'
import ReactEcharts from 'echarts-for-react'
import moment from 'moment'
import './overall.less'


const { Option } = Select
const { Link } = Anchor

const h_fourRateColumns = [
    {
        title: '范围',
        dataIndex: 'range'
    }, {
        title: '优秀人数',
        dataIndex: 'a_num'
    }, {
        title: '优秀率(%)',
        dataIndex: 'a_rate'
    }, {
        title: '良好人数',
        dataIndex: 'b_num'
    }, {
        title: '良好率(%)',
        dataIndex: 'b_rate'
    }, {
        title: '及格人数',
        dataIndex: 'c_num'
    }, {
        title: '及格率(%)',
        dataIndex: 'c_rate'
    }, {
        title: '低分人数',
        dataIndex: 'd_num'
    }, {
        title: '低分率(%)',
        dataIndex: 'd_rate'
    }
]
    , h_scoreSectionColumns = [
        {
            title: '范围',
            dataIndex: 'range',
        }, {
            title: '下四分位Q1',
            dataIndex: 'q1',
        }, {
            title: '上四分位Q3',
            dataIndex: 'q3',
        }, {
            title: '四分位距IQR',
            dataIndex: 'iqr',
        }, {
            title: '峰度',
            dataIndex: 'kurt',
        }, {
            title: '偏度',
            dataIndex: 'skew',
        }, {
            title: '异常值个数',
            dataIndex: 'exception',
        },
    ]
    , h_allSubjectColumns = [
        {
            title: '范围',
            dataIndex: 'range'
        }, {
            title: '总人数',
            dataIndex: 'all_count'
        }, {
            title: '实考人数',
            dataIndex: 'actual_count'
        }, {
            title: '缺考人数',
            dataIndex: 'lack_count'
        }, {
            title: '满分人数',
            dataIndex: 'full_score'
        }, {
            title: '零分人数',
            dataIndex: 'zero_score'
        }, {
            title: '最高分',
            dataIndex: 'max_score'
        }, {
            title: '最低分',
            dataIndex: 'min_score'
        }, {
            title: '平均分',
            dataIndex: 'avg_score'
        }, {
            title: '中位数',
            dataIndex: 'median_score'
        }, {
            title: '众数',
            dataIndex: 'mode_score'
        }, {
            title: '全距',
            dataIndex: 'full_distance'
        }, {
            title: '标准差',
            dataIndex: 'standard_deviation'
        }, {
            title: '超均率',
            dataIndex: 'super_average_rate'
        },
    ]
    , h_scoreSituationColumns = [
        {
            title: '范围',
            dataIndex: 'range'
        }, {
            title: '试卷满分',
            dataIndex: 'all_core'
        }, {
            title: '实考人数',
            dataIndex: 'actual_count'
        }, {
            title: '最高分',
            dataIndex: 'max_score'
        }, {
            title: '最低分',
            dataIndex: 'min_score'
        }, {
            title: '平均分',
            dataIndex: 'avg_score'
        }, {
            title: '中位数',
            dataIndex: 'median_score'
        }, {
            title: '全距',
            dataIndex: ''
        }, {
            title: '标准差',
            dataIndex: 'standard_deviation'
        }, {
            title: '难度',
            dataIndex: 'difficult'
        }, {
            title: '信度',
            dataIndex: 'reliability'
        }, {
            title: '超均率',
            dataIndex: 'super_average_rate'
        },
    ]
    , h_reachLineColumns = [
        {
            title: '统计对象',
            dataIndex: 'range'
        }, {
            title: '一本人数',
            dataIndex: 'vla_count'
        }, {
            title: '一本率',
            dataIndex: 'vla_rate'
        }, {
            title: '二本人数',
            dataIndex: 'vlb_count'
        }, {
            title: '二本率',
            dataIndex: 'vlb_rate'
        }, {
            title: '三本人数',
            dataIndex: 'vlc_count'
        }, {
            title: '三本率',
            dataIndex: 'vlc_rate'
        },
    ]
    , h_NumberOfPeopleColumns = [
        {
            title: '分段',
            dataIndex: 'd',
            render: (a) => {
                return ('[' + a + ']')
            }
        }, {
            title: '人数',
            dataIndex: 'a'
        }, {
            title: '百分比',
            dataIndex: 'c'
        }
    ]
    , h_scoreRankColumns = [
        {
            title: '统计对象',
            dataIndex: 'range'
        }, {
            title: '实考人数',
            dataIndex: 'actual_count'
        }, {
            title: '排名前10名',
            children: [
                {
                    title: '人数',
                    dataIndex: 'count_b_10'
                }, {
                    title: '比例(%)',
                    dataIndex: 'count_b_10_rate'
                }
            ]
        }, {
            title: '排名前50名',
            children: [
                {
                    title: '人数',
                    dataIndex: 'count_b_50'
                }, {
                    title: '比例(%)',
                    dataIndex: 'count_b_50_rate'
                }
            ]
        }, {
            title: '排名前100名',
            children: [
                {
                    title: '人数',
                    dataIndex: 'count_b_100'
                }, {
                    title: '比例(%)',
                    dataIndex: 'count_b_100_rate'
                }
            ]
        }, {
            title: '排名前200名',
            children: [
                {
                    title: '人数',
                    dataIndex: 'count_b_200'
                }, {
                    title: '比例(%)',
                    dataIndex: 'count_b_200_rate'
                }
            ]
        }, {
            title: '排名前300名',
            children: [
                {
                    title: '人数',
                    dataIndex: 'count_b_300'
                }, {
                    title: '比例(%)',
                    dataIndex: 'count_b_300_rate'
                }
            ]
        },
    ]
const h_explain = (
    <div>此处为说明</div>
)

export default class index extends Component {
    constructor() {
        super()
        //获取me_id
        const arr = window.location.href.split('/')
        const me_id = arr[arr.length - 1].split('=')[1]
        this.state = {
            me_id,
            header_details: {
                subjects: []
            },
            h_totalData: {},
            h_fourRate: [],
            h_scoreSectionData: [],
            h_allSubjectData: [],
            h_scoreSituationData: [],
            h_reachLineData: [],
            h_NumberOfPeopleData: [],
            h_NumberofPeopleOption: [],
            checkedValue: 0,
            checkedName: 'area',
            h_scoreRankData: [],
            course_id: '',
            realPeopleTag: 'area',
            fourRateTag: 'area',
            reachLineTag: 'area',
            scoreNameTag: 'area',
            targetOffset: undefined,
            scoreSituName: 'area',
            totalDataTag: 'area',
            variousSections:[],
            percent: 0,
            visible: false
        }
    }

    // 实考人数
    numberOfPeople = () => {
        function iData(data) {
            let max = Math.max.apply(null, data)
            return max
        }
        const bgData = this.state.h_totalData[`${this.state.realPeopleTag}`] ? this.state.h_totalData[`${this.state.realPeopleTag}`].reduce((sum, curr) => {
            sum.push(curr.actual_count)
            return sum
        }, []) : []
        let option = {
            title: {
                text: '实考人数',
                top: '0',
                left: '230',
                textStyle: {
                    color: '#5b5e63'
                }
            },
            tooltip: {
                axisPointer: {            // 坐标轴指示器，坐标轴触发有效
                    type: 'shalinedow'        // 默认为直线，可选为：'line' | 'shadow'
                }
            },
            xAxis: {
                data: this.state.h_totalData[`${this.state.realPeopleTag}`] ? this.state.h_totalData[`${this.state.realPeopleTag}`].reduce((sum, curr) => {
                    sum.push(curr.range)
                    return sum
                }, []) : [],
                axisTick: { show: false },
            },
            yAxis: {
                name: '人数',
                splitLine: { show: false },

            },
            animationDurationUpdate: 1200,
            series: [{
                type: 'bar',
                itemStyle: {
                    normal: {
                        color: '#e9eef4',
                        barBorderRadius: 20
                    }
                },
                silent: true,
                barMaxWidth: 40,
                barGap: '-100%', // Make series be overlap iData(bgData)
                data: this.state.h_totalData[`${this.state.realPeopleTag}`] ? this.state.h_totalData[`${this.state.realPeopleTag}`].map((item) => {
                    item = iData(bgData)
                    return item
                }, []) : [],
            }, {
                type: 'bar',
                barMaxWidth: 40,
                z: 10,
                itemStyle: {
                    normal: {
                        barBorderRadius: 20
                    }
                },
                color: {
                    type: 'linear',
                    x: 0,
                    y: 0,
                    x2: 0,
                    y2: 1,
                    colorStops: [{
                        offset: 0, color: '#4bd6ff' // 0% 处的颜色
                    }, {
                        offset: 1, color: '#2db2ff' // 100% 处的颜色
                    }],
                    global: false // 缺省为 false
                },
                data: this.state.h_totalData[`${this.state.realPeopleTag}`] ? this.state.h_totalData[`${this.state.realPeopleTag}`].reduce((sum, curr) => {
                    sum.push(curr.actual_count)
                    return sum
                }, []) : [],
            }]
        }
        return option
    }

    // 四率情况
    FourRateSituation = () => {
        let option = {
            title: {
                text: '四率情况',
                top: '0',
                left: '230',
                textStyle: {
                    color: '#5b5e63'
                }
            },
            tooltip: {
                trigger: 'axis',
                axisPointer: {            // 坐标轴指示器，坐标轴触发有效
                    type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                }
            },
            legend: {
                data: ['优秀[125-150]', '良好[105-124]', '合格[90-105]', '待合格[0-90]'],
                top: '30'
            },

            xAxis: {
                type: 'category',
                data: this.state.h_totalData[`${this.state.fourRateTag}`] ? this.state.h_totalData[`${this.state.fourRateTag}`].reduce((sum, curr) => {
                    sum.push(curr.range)
                    return sum
                }, []) : [],
            },
            yAxis: {
                type: 'value',
                axisLabel: {
                    show: true,
                    interval: 'auto',
                    formatter: '{value} %'
                },
                show: true
            },
            series: [
                {
                    name: '优秀[125-150]',
                    type: 'bar',
                    stack: '总量',
                    label: {
                        normal: {
                            show: false,
                        }
                    },
                    barMaxWidth: 40,
                    data: this.state.h_totalData[`${this.state.fourRateTag}`] ? this.state.h_totalData[`${this.state.fourRateTag}`].reduce((sum, curr) => {
                        sum.push(curr.a_rate)
                        return sum
                    }, []) : [],
                    itemStyle: {
                        normal: {
                            color: '#ff744b',
                            // barBorderRadius: [20, 20, 0, 0]
                        }
                    }
                },
                {
                    name: '良好[105-124]',
                    type: 'bar',
                    stack: '总量',
                    label: {
                        normal: {
                            show: false,
                        }
                    },
                    data: this.state.h_totalData[`${this.state.fourRateTag}`] ? this.state.h_totalData[`${this.state.fourRateTag}`].reduce((sum, curr) => {
                        sum.push(curr.b_rate)
                        return sum
                    }, []) : [],
                    itemStyle: {
                        normal: {
                            color: '#2dffcd',
                        }
                    },
                },
                {
                    name: '合格[90-105]',
                    type: 'bar',
                    stack: '总量',
                    label: {
                        normal: {
                            show: false,
                        }
                    },
                    data: this.state.h_totalData[`${this.state.fourRateTag}`] ? this.state.h_totalData[`${this.state.fourRateTag}`].reduce((sum, curr) => {
                        sum.push(curr.c_rate)
                        return sum
                    }, []) : [],
                    itemStyle: {
                        normal: {
                            color: '#4ad8ff',
                        }
                    },
                },
                {
                    name: '待合格[0-90]',
                    type: 'bar',
                    stack: '总量',
                    label: {
                        normal: {
                            show: false,

                        }
                    },
                    data: this.state.h_totalData[`${this.state.fourRateTag}`] ? this.state.h_totalData[`${this.state.fourRateTag}`].reduce((sum, curr) => {
                        sum.push(curr.d_rate)
                        return sum
                    }, []) : [],
                    itemStyle: {
                        normal: {
                            color: '#ffeb4c',
                            // barBorderRadius: [20, 20, 0, 0]
                        }
                    },
                },
            ]
        }
        return option
    }

    // 达线情况
    LineCondition = () => {
        let option = {
            title: {
                text: '达线情况',
                top: '0',
                left: '230',
                textStyle: {
                    color: '#5b5e63'
                }
            },
            tooltip: {
                trigger: 'item',
                formatter: "{a} <br/>{b}: ({d}%)"
            },
            legend: {
                orient: 'vertical',
                left: '30',
                data: ['一本线', '二本线', '三本线']
            },
            series: [
                {
                    name: '达线情况',
                    type: 'pie',
                    radius: ['50%', '70%'],
                    avoidLabelOverlap: false,
                    label: {
                        normal: {
                            show: false,
                            position: 'center'
                        },
                        emphasis: {
                            show: true,
                            textStyle: {
                                fontSize: '30',
                                fontWeight: 'bold'
                            }
                        }
                    },
                    labelLine: {
                        normal: {
                            show: false
                        }
                    },
                    data: [
                        {
                            value: this.state.h_totalData[`${this.state.reachLineTag}`] ? this.state.h_totalData[`${this.state.reachLineTag}`][0].vla_rate : '',
                            name: '一本线',
                            itemStyle: {
                                normal: {
                                    color: '#fc945d'
                                }
                            }
                        },
                        {
                            value: this.state.h_totalData[`${this.state.reachLineTag}`] ? this.state.h_totalData[`${this.state.reachLineTag}`][0].vlb_rate : '',
                            name: '二本线',
                            itemStyle: {
                                normal: {
                                    color: '#fbd95e'
                                }
                            }
                        },
                        {
                            value: this.state.h_totalData[`${this.state.reachLineTag}`] ? this.state.h_totalData[`${this.state.reachLineTag}`][0].vlc_rate : '',
                            name: '三本线',
                            itemStyle: {
                                normal: {
                                    color: '#39cb9e'
                                }
                            }
                        },
                        // {
                        //     value: 48,
                        //     name: '其他',
                        //     itemStyle: {
                        //         normal: {
                        //             color: '#de56f4'
                        //         }
                        //     }
                        // }
                    ]
                }
            ]
        }
        return option
    }


    // 武侯区学业水平分段统计人数百分比
    academicOption() {
        return ({
            color: ['#0096fd', '#c23531', '#dddddd'],
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross',
                    crossStyle: {
                        color: '#dedede'
                    }
                }
            },
            toolbox: {
                feature: {
                    dataView: { show: true, readOnly: false },
                    magicType: { show: true, type: ['line', 'bar'] },
                    restore: { show: true },
                    saveAsImage: { show: true }
                }
            },
            legend: {
                data: ['人数（%）']
            },
            xAxis: [
                {
                    type: 'category',
                    data: this.state.h_totalData[`${this.state.checkedName}`] ? this.state.h_totalData[`${this.state.checkedName}`][this.state.checkedValue].dist.reduce((sum, curr) => {
                        sum.push('['+curr.d+']')
                        return sum
                    }, []) : [],
                    axisPointer: {
                        type: 'shadow'
                    }
                }
            ],
            yAxis: [
                {
                    type: 'value',
                    name: '百分比',
                    axisLabel: {
                        formatter: '{value}%'
                    }
                }
            ],
            series: [
                {
                    name: '人数（%）',
                    type: 'line',
                    data: this.state.h_totalData[`${this.state.checkedName}`] ? this.state.h_totalData[`${this.state.checkedName}`][this.state.checkedValue].dist.reduce((sum, curr) => {
                        sum.push(curr.c)
                        return sum
                    }, []) : [],
                }
            ]
        })
    }
        //判断按钮是否选中
    buttonClick(tag, area) {
        return{
            background: this.state[tag] === area? 'rgb(1, 149, 255)':'#fff',
            color:this.state[tag] === area? '#fff':'rgba(0, 0, 0, 0.65)'
        }
    }

    // 分数段占比
    // FractionalPercentage = () => {

    //     let option = {
    //         color: ['#2fb4ff', '#fdb82d', '#c23531', '#dddddd'],
    //         tooltip: {
    //             trigger: 'axis',
    //             axisPointer: {
    //                 type: 'cross',
    //                 crossStyle: {
    //                     color: '#dedede'
    //                 }
    //             }
    //         },
    //         toolbox: {
    //             feature: {
    //                 dataView: { show: true, readOnly: false },
    //                 magicType: { show: true, type: ['line', 'bar'] },
    //                 restore: { show: true },
    //                 saveAsImage: { show: true }
    //             }
    //         },
    //         legend: {
    //             data: ['占比']
    //         },
    //         yAxis: [
    //             {
    //                 type: 'category',
    //                 // data: this.state.classKnowledgeData.class.reduce((sum, curr)=>{
    //                 //     sum.push(curr.class_name)
    //                 //     return sum
    //                 // },[]),
    //                 axisPointer: {
    //                     type: 'shadow'
    //                 }
    //             }
    //         ],
    //         xAxis: [
    //             {
    //                 type: 'value',
    //                 name: '占比',
    //                 // min: 0,
    //                 // max: 80,
    //                 // interval: 20,
    //                 axisLabel: {
    //                     formatter: '{value}%'
    //                 }
    //             }
    //         ],
    //         series: [
    //             {
    //                 name: '班级得分率',
    //                 type: 'bar',
    //                 // data:this.state.classKnowledgeData.class.reduce((sum, curr)=>{
    //                 //     sum.push(curr.classKnowledgeProbability)
    //                 //     return sum
    //                 // },[]),
    //                 barMaxWidth: 40,
    //                 itemStyle: {
    //                     normal: {
    //                         barBorderRadius: 20
    //                     }
    //                 },
    //                 color: {
    //                     type: 'linear',
    //                     x: 0,
    //                     y: 0,
    //                     x2: 0,
    //                     y2: 1,
    //                     colorStops: [{
    //                         offset: 0, color: '#4bd6ff' // 0% 处的颜色
    //                     }, {
    //                         offset: 1, color: '#2db2ff' // 100% 处的颜色
    //                     }],
    //                     global: false // 缺省为 false
    //                 },
    //             }
    //         ]
    //     }

    //     return option
    // }
    //

    componentDidMount() {
        this.interval = setInterval(() => {
            this.setState({
                percent: this.state.percent + Math.floor(Math.random()*10+1)
            })
        }, 500)
        this.setState({
            targetOffset: window.innerHeight / 2,
            visible: true,
        });
        //获取报告详情
        reportDetailRequest(this.state.me_id)
            .then(res => {
                this.setState({ header_details: res.body, course_id: res.body.subjects[0].course_id })
            })
        overallReport(this.state.me_id)
        
            .then(resp => {
                console.log(resp)
                if(resp.code === 200) {
                    clearInterval(this.interval)

                    this.setState({
                        percent: 100,
                        visible: false,
                    })
                }
                this.setState({
                    h_totalData: resp.body,
                    h_scoreSectionData: resp.body.area,
                    h_fourRate: resp.body.area,
                    h_allSubjectData: resp.body.area,
                    h_scoreSituationData: resp.body.variousSections?resp.body.variousSections[0].area:[],
                    scoreSituNumber: 0,
                    h_reachLineData: resp.body.area,
                    h_NumberOfPeopleData: resp.body.variousSections?resp.body.area[0].dist:[],
                    h_scoreRankData: resp.body.area,
                    h_NumberofPeopleOption: resp.body.area.map((item, index) => {
                        item = {
                            range: item.range,
                            index
                        }
                        return item
                    })
                })
            })
    }

    componentWillUnmount () {
        clearInterval(this.interval)
    }
    render() {
        return (
                <div>
                    <div>
                        {/* 进度条模态框 */}
                        <Modal
                        visible={this.state.visible}
                        onOk={this.handleOk}
                        onCancel={this.handleCancel}
                        footer={false}
                        closable={false}
                        >
                            <p>数据计算中...</p>
                            <Progress
                            strokeColor={{
                                from: '#108ee9',
                                to: '#87d068',
                            }}
                            percent={this.state.percent}
                            status="active"
                            />
                        </Modal>
                    </div>
                <div id='overalldownload' style={{ width: '85%', marginLeft:'3%', background: '#fff', padding: '0 1%', boxSizing: 'border-box',paddingTop: '20px', }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: '90%', margin: 'auto', border: '2px solid #cae4f5', height: '70px', padding: '0 15px', boxSizing: 'border-box',borderRadius: 10 }}>
                        <div style={{ fontSize: '24px', width: '500px', whiteSpace: 'nowrap' }}>{this.state.header_details.examName}</div>
                        <div style={{marginLeft: 100}}>考试时间：{moment(this.state.header_details.examDate * 1000).format('YYYY-MM-DD')}</div>
                        <div>{this.state.header_details.gradeName}</div>
                        {/* <div>
                            <Button
                                style={{ marginRight: '10px' }}
                                type='primary'
                                onClick={() => {
                                }}
                            >自定义</Button>
                            <Button
                                type='primary'
                                onClick={() => {
                                    exportPdfRequest(document.querySelector('html').outerHTML, this.state.me_id)
                                }}
                            >下载</Button>
                        </div> */}
                    </div>
                    <div id='allsubj' style={{ width: '150px', height: '40px', textAlign: 'center', lineHeight: '40px', color: '#fff', fontSize: '20px', background: '#0195ff', marginTop: '33px', borderRadius: '5px', marginBottom: '45px' }}>整体概述-全科</div>
                    <div >
                        <Row gutter={16}>
                            <Col span={12}>
                                <ReactEcharts option={this.numberOfPeople()} />
                            </Col>
                            <Col span={12}>
                                <ReactEcharts option={this.FourRateSituation()} />
                            </Col>
                        </Row>
                        <Row gutter={16} style={{ marginTop: 50 }}>
                            <Col span={12}>
                                <ReactEcharts option={this.LineCondition()} />
                            </Col>
                            <Col span={12}>
                                <ReactEcharts option={this.academicOption()} />
                            </Col>
                        </Row>
                    </div>

                    <Anchor className='overall-anchor' style={{ width:'10%', position: 'fixed', right: '1%', top: '200px' }} targetOffset={this.state.targetOffset}>
                        <div className='overall-anchor-first' >

                            <Link href="#allsubj"  title='考试整体概述'>
                                <Icon type="container" style={{position:'absolute', left:'8px', top:'10px', fontSize:'20px'}}/>
                            </Link>
                        </div>
                        <Link href="#eachScore" title='各科得分概览'>
                            <Icon type="calculator" style={{position:'absolute', left:'8px', top:'57px', fontSize:'20px'}}/>
                        </Link>
                        <Link href="#fourtate" title='全科四率情况'>
                            <Icon type="rise" style={{position:'absolute', left:'8px', top:'104px', fontSize:'20px'}}/>
                        </Link>
                        <Link href="#scoreSection" title='分数段分布形态'>
                            <Icon type="bar-chart" style={{position:'absolute', left:'8px', top:'148px', fontSize:'20px'}}/>
                        </Link>
                        <Link href="#reachline" title='达线情况'>
                            <Icon type="pie-chart" style={{position:'absolute', left:'8px', top:'193px', fontSize:'20px'}}/>
                        </Link>
                        <Link href="#peopleSection" title='分数段人数情况'>
                            <Icon type="team" style={{position:'absolute', left:'8px', top:'240px', fontSize:'20px'}}/>
                        </Link>
                        <Link href="#rank" title='分数排名情况'>
                            <Icon type="deployment-unit" style={{position:'absolute', left:'8px', top:'280px', fontSize:'20px'}}/>
                        </Link>
                    </Anchor>

                    <BackTop style={{ position: 'fixed', width: '70px', height: '70px', right: '2%', bottom: '10%', background: '#0195ff', color: '#fff', display: 'flex', flexDirection: 'column', justifyContent: 'center', borderRadius: '50%' }}>
                        <Icon style={{ fontSize: '24px' }} type="vertical-align-top" />
                        <div style={{ textAlign: 'center' }}>回到顶部</div>
                    </BackTop>
                    {/* 整体概述-全科 */}
                    <div  style={{ display: 'flex', justifyContent: 'space-between' ,marginTop: 100 }}>
                        <div style={{ fontWeight: '700', fontSize: '20px' }}>整体概述-全科</div>
                        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                            <Popover content={h_explain}>
                                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                    <span style={{ background: '#ffd646', borderRadius: '50%', width: '15px', height: '15px', display: 'inline-block' }}></span>
                                    <span style={{ marginRight: '15px' }}>说明 |</span>
                                </div>
                            </Popover>
                            <Button onClick={() => { this.setState({ h_allSubjectData: this.state.h_totalData.area, realPeopleTag: 'area' }) }} style={{...{ borderRadius: '0px' },...this.buttonClick('realPeopleTag', 'area')}}>区县</Button>
                            <Button onClick={() => { this.setState({ h_allSubjectData: this.state.h_totalData.school, realPeopleTag: 'school' }) }} style={{...{ borderRadius: '0px' },...this.buttonClick('realPeopleTag', 'school')}}>学校</Button>
                            <Button onClick={() => { this.setState({ h_allSubjectData: this.state.h_totalData.class, realPeopleTag: 'class' }) }} style={{...{ borderRadius: '0px' },...this.buttonClick('realPeopleTag', 'class')}}>班级</Button>
                        </div>
                    </div>
                    <Table
                        columns={h_allSubjectColumns}
                        style={{ marginTop: '5px' }}
                        dataSource={this.state.h_allSubjectData}
                        rowKey='range'
                    />
                    <ReactEcharts option={this.numberOfPeople()} />
                    {/* 各科得分概览 */}
                    <div id='eachScore' style={{ display: 'flex', justifyContent: 'space-between', marginTop: '100px' }}>
                        <div style={{ fontWeight: '700', fontSize: '20px' }}>各科得分概览</div>
                        <Select
                            style={{ width: '150px' }}
                            onChange={course_id => {
                                var scoreSituNumber
                                this.state.h_totalData.variousSections.some((item, index) =>{
                                    scoreSituNumber = index
                                    return item.course_id === course_id
                                })
                                this.setState({ course_id, scoreSituNumber,h_scoreSituationData:this.state.h_totalData.variousSections[scoreSituNumber][this.state.scoreSituName]  })
                            }}
                            value={this.state.course_id}
                        >
                            {
                                this.state.header_details.subjects.map(item => {
                                    return (
                                        <Option key={item.course_id} value={item.course_id}>{item.name}</Option>
                                    )
                                })
                            }
                        </Select>
                        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                            <Popover content={h_explain}>
                                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                    <span style={{ background: '#ffd646', borderRadius: '50%', width: '15px', height: '15px', display: 'inline-block' }}></span>
                                    <span style={{ marginRight: '15px' }}>说明 |</span>
                                </div>
                            </Popover>
                            <Button onClick={() => {this.setState({ h_scoreSituationData: this.state.h_totalData.variousSections[this.state.scoreSituNumber].area, scoreSituName: 'area' }) }} style={{...{ borderRadius: '0px' },...this.buttonClick('scoreSituName', 'area')}}>区县</Button>
                            <Button onClick={() => { this.setState({ h_scoreSituationData: this.state.h_totalData.variousSections[this.state.scoreSituNumber].school,scoreSituName: 'school' }) }} style={{...{ borderRadius: '0px' },...this.buttonClick('scoreSituName', 'school')}}>学校</Button>
                            <Button onClick={() => { this.setState({ h_scoreSituationData: this.state.h_totalData.variousSections[this.state.scoreSituNumber].class,scoreSituName: 'class' }) }} style={{...{ borderRadius: '0px' },...this.buttonClick('scoreSituName', 'class')}}>班级</Button>
                        </div>
                    </div>
                    <Table
                        columns={h_scoreSituationColumns}
                        style={{ marginTop: '5px' }}
                        dataSource={this.state.h_scoreSituationData}
                        rowKey='range'
                    />
                    {/* 四率情况 */}
                    <div id="fourtate" style={{ display: 'flex', justifyContent: 'space-between',marginTop: 100 }}>
                        <div style={{ fontWeight: '700', fontSize: '20px' }}>四率情况</div>
                        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                            <Popover content={h_explain}>
                                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                    <span style={{ background: '#ffd646', borderRadius: '50%', width: '15px', height: '15px', display: 'inline-block' }}></span>
                                    <span style={{ marginRight: '15px' }}>说明 |</span>
                                </div>
                            </Popover>
                            <Button onClick={() => { this.setState({ h_fourRate: this.state.h_totalData.area, fourRateTag: 'area' }) }} style={{...{ borderRadius: '0px' },...this.buttonClick('fourRateTag','area')}}>区县</Button>
                            <Button onClick={() => { this.setState({ h_fourRate: this.state.h_totalData.school, fourRateTag: 'school' }) }} style={{...{ borderRadius: '0px' },...this.buttonClick('fourRateTag','school')}}>学校</Button>
                            <Button onClick={() => { this.setState({ h_fourRate: this.state.h_totalData.class, fourRateTag: 'class' }) }} style={{...{ borderRadius: '0px' },...this.buttonClick('fourRateTag','class')}}>班级</Button>
                        </div>
                    </div>
                    <Table
                        columns={h_fourRateColumns}
                        style={{ marginTop: '5px' }}
                        dataSource={this.state.h_fourRate}
                        rowKey='range'
                    />
                    <ReactEcharts option={this.FourRateSituation()} />
                    {/* 分数段分布形态 */}
                    <div id='scoreSection' style={{ display: 'flex', justifyContent: 'space-between',marginTop: 100 }}>
                        <div style={{ fontWeight: '700', fontSize: '20px' }}>分数段分布形态</div>
                        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                            <Button onClick={() => { this.setState({ h_scoreSectionData: this.state.h_totalData.area ,scoreNameTag:'area' }) }} style={{...{ borderRadius: '0px' },...this.buttonClick('scoreNameTag','area')}}>区县</Button>
                            <Button onClick={() => { this.setState({ h_scoreSectionData: this.state.h_totalData.school, scoreNameTag:'school' }) }} style={{...{ borderRadius: '0px' },...this.buttonClick('scoreNameTag','school')}}>学校</Button>
                            <Button onClick={() => { this.setState({ h_scoreSectionData: this.state.h_totalData.class, scoreNameTag:'class' }) }} style={{...{ borderRadius: '0px' },...this.buttonClick('scoreNameTag','class')}}>班级</Button>
                        </div>
                    </div>
                    <Table
                        columns={h_scoreSectionColumns}
                        style={{ marginTop: '5px' }}
                        dataSource={this.state.h_scoreSectionData}
                        rowKey='range'
                    />
                    {/* <ReactEcharts option={this.FractionalPercentage()} /> */}
                    {/* 达线情况 */}
                    <div id='reachline' style={{ display: 'flex', justifyContent: 'space-between',marginTop: 100 }}>
                        <div style={{ fontWeight: '700', fontSize: '20px' }}>达线情况</div>
                        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                            <Button onClick={() => { this.setState({ h_reachLineData: this.state.h_totalData.area, reachLineTag: 'area' }) }} style={{...{ borderRadius: '0px' },...this.buttonClick('reachLineTag','area')}}>区县</Button>
                            <Button onClick={() => { this.setState({ h_reachLineData: this.state.h_totalData.school, reachLineTag: 'school' }) }} style={{...{ borderRadius: '0px' },...this.buttonClick('reachLineTag','school')}}>学校</Button>
                            <Button onClick={() => { this.setState({ h_reachLineData: this.state.h_totalData.class, reachLineTag: 'class' }) }} style={{...{ borderRadius: '0px' },...this.buttonClick('reachLineTag','class')}}>班级</Button>
                        </div>
                    </div>
                    <Table
                        columns={h_reachLineColumns}
                        style={{ marginTop: '5px' }}
                        dataSource={this.state.h_reachLineData}
                        rowKey='range'
                    />
                    <ReactEcharts option={this.LineCondition()} />

                    {/* 分数段人数情况 */}
                    <div id='peopleSection' style={{ display: 'flex', justifyContent: 'space-between',marginTop: 100 }}>
                        <div style={{ fontWeight: '700', fontSize: '20px' }}>分数段人数情况</div>
                        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                            <Button onClick={() => {
                                this.setState({
                                    h_NumberOfPeopleData: this.state.h_totalData.area[0].dist, checkedValue: 0, checkedName: 'area',
                                    h_NumberofPeopleOption: this.state.h_totalData.area.map((item, index) => {
                                        item = {
                                            range: item.range,
                                            index
                                        }
                                        return item
                                    })
                                })
                            }} style={{ borderRadius: '0px' }}>区县</Button>
                            <Button onClick={() => {
                                this.setState({
                                    h_NumberOfPeopleData: this.state.h_totalData.school[0].dist, checkedValue: 0, checkedName: 'school',
                                    h_NumberofPeopleOption: this.state.h_totalData.school.map((item, index) => {
                                        item = {
                                            range: item.range,
                                            index
                                        }
                                        return item
                                    })
                                })
                            }} style={{ borderRadius: '0px' }}>学校</Button>
                            <Button onClick={() => {
                                this.setState({
                                    h_NumberOfPeopleData: this.state.h_totalData.class[0].dist, checkedValue: 0, checkedName: 'class',
                                    h_NumberofPeopleOption: this.state.h_totalData.class.map((item, index) => {
                                        item = {
                                            range: item.range,
                                            index
                                        }
                                        return item
                                    })
                                })
                            }} style={{ borderRadius: '0px' }}>班级</Button>
                        </div>
                        <Select
                            style={{ width: '250px' }}
                            value={this.state.checkedValue}
                            onChange={checkedValue => {
                                this.setState({
                                    checkedValue,
                                }, () => {
                                    this.setState({
                                        h_NumberOfPeopleData: this.state.h_totalData[`${this.state.checkedName}`][this.state.checkedValue].dist,
                                    })
                                })
                            }}
                        >
                            {
                                this.state.h_NumberofPeopleOption.map(item => {
                                    return (
                                        <Option key={item.index} value={item.index}>{item.range}</Option>
                                    )
                                })
                            }
                        </Select>
                      
                    </div>
                    <Table
                        columns={h_NumberOfPeopleColumns}
                        style={{ marginTop: '5px' }}
                        dataSource={this.state.h_NumberOfPeopleData}
                        rowKey='d'
                    />
                    <ReactEcharts option={this.academicOption()} />
                    {/* 分数排名情况 */}
                    <div id='rank' style={{ display: 'flex', justifyContent: 'space-between',marginTop: 100 }}>
                        <div style={{ fontWeight: '700', fontSize: '20px' }}>分数排名情况</div>

                        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                            <Button onClick={() => { this.setState({ h_scoreRankData: this.state.h_totalData.area, totalDataTag:'area' }) }} style={{...{ borderRadius: '0px' },...this.buttonClick('totalDataTag','area')}}>区县</Button>
                            <Button onClick={() => { this.setState({ h_scoreRankData: this.state.h_totalData.school, totalDataTag:'school' }) }} style={{...{ borderRadius: '0px' },...this.buttonClick('totalDataTag','school')}}>学校</Button>
                            <Button onClick={() => { this.setState({ h_scoreRankData: this.state.h_totalData.class, totalDataTag:'class' }) }} style={{...{ borderRadius: '0px' },...this.buttonClick('totalDataTag','class')}}>班级</Button>
                        </div>
                    </div>
                    <Table
                    columns={h_scoreRankColumns}
                    style={{ marginTop: '5px' }}
                    dataSource={this.state.h_scoreRankData}
                    rowKey='range'
                />
                </div>
                </div>
        )
    }
}
