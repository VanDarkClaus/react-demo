import React, { Component } from 'react'
import { Select, Table } from 'antd'
import { examSchoolsRequest, examClassesRequest, getStudentListRequest, reportDetailRequest, personalAllRequest, summaryRequest, individualsOnlyBranchRequest } from 'requests'
import ReactEcharts from 'echarts-for-react';
import moment from 'moment'


const { Option } = Select
const scoreGapColumns = [
    {
        title: '科目',
        dataIndex: 'subject'
    }, {
        title: '最高分差值',
        dataIndex: 'data0'
    }, {
        title: '最高分',
        dataIndex: 'data1'
    }, {
        title: '我的成绩',
        dataIndex: 'data2'
    }, {
        title: '平均分',
        dataIndex: 'data3'
    }, {
        title: '平均分差值',
        dataIndex: 'data4'
    },
]

export default class index extends Component {
    constructor() {
        super()
        const arr = window.location.href.split('/')
        const me_id = arr[arr.length - 1].split('=')[1]
        this.state = {
            me_id,
            schoolListData: [],
            school_id: '',
            examClassesData: [],
            class_id: '',
            studentListData: [],
            student_id: '',
            reportDetailData: {
                examName: '',
                subjects: []
            },
            subjectsList: [],
            course_id: '',
            personalAllData: {},
            summaryData: '',
            individualsData: ''
        }
    }
    //根据考试me_id ,school获取所有考试的班级
    examClassesHandle() {
        examClassesRequest(this.state.me_id, this.state.school_id)
            .then(res => {
                this.setState({
                    examClassesData: res.body,
                    class_id: res.body.length ? res.body[0].class_id : ''
                }, () => {
                    this.getStudentListHandle()
                })
            })
    }
    //获取班级学生列表
    getStudentListHandle() {
        getStudentListRequest(this.state.class_id, this.state.school_id, this.state.me_id)
            .then(res => {
                this.setState({
                    studentListData: res.body,
                    student_id: res.body.length ? res.body[0].student_id : '',
                    student_name: res.body.length ? res.body[0].student_name : ''
                }, () => {
                    this.personalAllHandle()
                    this.summaryHandle()
                    this.individualsOnlyBranchHandle()
                })
            })
    }
    //获取个人总体成绩
    personalAllHandle() {
        personalAllRequest(this.state.me_id, this.state.student_id)
            .then(res => {
                this.setState({
                    personalAllData: res.body
                })
            })
    }
    //获取个人单科成绩报告
    individualsOnlyBranchHandle() {
        if (this.state.course_id) {
            individualsOnlyBranchRequest(this.state.me_id, this.state.course_id, this.state.student_id)
                .then(res => {
                    this.setState({ individualsData: res.body })
                })
        }
    }
    //小结
    summaryHandle = () => {
        summaryRequest(this.state.me_id, this.state.student_id)
            .then(res => {
                this.setState({ summaryData: res.body })
            })
    }
    //各知识点比较图
    compareKnowledgeCharts() {
        return ({
            color: ['#ffb435', '#0096fd', '#c23531', '#dddddd'],
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross',
                    crossStyle: {
                        color: '#dedede'
                    }
                }
            },
            toolbox: {
                feature: {
                    dataView: { show: true, readOnly: false },
                    magicType: { show: true, type: ['line', 'bar'] },
                    restore: { show: true },
                    saveAsImage: { show: true }
                }
            },
            legend: {
                data: ['本班', '本年级']
            },
            xAxis: [
                {
                    type: 'category',
                    data: this.state.personalAllData.resultsChange ? this.state.personalAllData.resultsChange.reduce((sum, curr) => {
                        sum.push(moment(curr.created_at * 1000).format('YYYY-MM-DD'))
                        return sum
                    }, []) : [],
                    axisPointer: {
                        type: 'shadow'
                    }
                }
            ],
            yAxis: [
                {
                    type: 'value',
                    name: '排名',
                    axisLabel: {
                        formatter: '{value}%'
                    }
                }
            ],
            series: [
                {
                    name: '本班',
                    type: 'line',
                    data: this.state.personalAllData.resultsChange ? this.state.personalAllData.resultsChange.reduce((sum, curr) => {
                        sum.push(curr.class_rate)
                        return sum
                    }, []) : [],
                }, {
                    name: '本年级',
                    type: 'line',
                    data: this.state.personalAllData.resultsChange ? this.state.personalAllData.resultsChange.reduce((sum, curr) => {
                        sum.push(curr.grade_rate)
                        return sum
                    }, []) : [],
                }
            ]
        })
    }
    //稳固优势学科图
    advantageCharts() {
        return ({
            color: ['#ffb435', '#0096fd', '#c23531', '#dddddd'],
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross',
                    crossStyle: {
                        color: '#dedede'
                    }
                }
            },
            toolbox: {
                feature: {
                    dataView: { show: true, readOnly: false },
                    magicType: { show: true, type: ['line', 'bar'] },
                    restore: { show: true },
                    saveAsImage: { show: true }
                }
            },
            legend: {
                data: ['个人得分率']
            },
            xAxis: [
                {
                    type: 'category',
                    data: this.state.personalAllData.scoringRate ? this.state.personalAllData.scoringRate.reduce((sum, curr) => {
                        sum.push(curr.subject_name)
                        return sum
                    }, []) : [],
                    axisPointer: {
                        type: 'shadow'
                    }
                }
            ],
            yAxis: [
                {
                    type: 'value',
                    name: '得分率',
                    axisLabel: {
                        formatter: '{value}%'
                    }
                }
            ],
            series: [
                {
                    name: '个人得分率',
                    type: 'line',
                    data: this.state.personalAllData.scoringRate ? this.state.personalAllData.scoringRate.reduce((sum, curr) => {
                        sum.push(curr.rate)
                        return sum
                    }, []) : [],
                }
            ]
        })
    }

    componentDidMount = async () => {
        await examSchoolsRequest(this.state.me_id)
            .then(res => {
                this.setState({
                    schoolListData: res.body,
                    school_id: res.body.length ? res.body[0].school_id : ''
                })
            })
        await examClassesRequest(this.state.me_id, this.state.school_id)
            .then(res => {
                this.setState({
                    examClassesData: res.body,
                    class_id: res.body.length ? res.body[0].class_id : '',

                })
            })
        await getStudentListRequest(this.state.class_id, this.state.school_id, this.state.me_id)
            .then(res => {
                this.setState({
                    studentListData: res.body,
                    student_id: res.body.length ? res.body[0].student_id : '',
                    student_name: res.body.length ? res.body[0].student_name : ''
                }, () => {
                    this.personalAllHandle()
                    this.summaryHandle()
                })
            })
        //获取报告信息
        reportDetailRequest(this.state.me_id, this.state.student_id)
            .then(res => {
                res.body.subjects.unshift({
                    course_id: '',
                    name: '全科'
                })
                this.setState({ reportDetailData: res.body, course_id: res.body.subjects ? res.body.subjects[0].course_id : '' })
            })
    }
    render() {
        let scoreGapData = []
        let arr = this.state.personalAllData.scoreGap ? this.state.personalAllData.scoreGap.subject_name.map((item, index) => {
            scoreGapData[index] = {
                subject: item,
                'data0': this.state.personalAllData.scoreGap.contents[0].score[index],
                'data1': this.state.personalAllData.scoreGap.contents[1].score[index],
                'data2': this.state.personalAllData.scoreGap.contents[2].score[index],
                'data3': this.state.personalAllData.scoreGap.contents[3].score[index],
                'data4': this.state.personalAllData.scoreGap.contents[4].score[index],
            }
            return item
        }) : []
        return (
            <div style={{ width: '1150px', margin: 'auto', background: '#fff', padding: '20px 30px', boxSizing: 'border-box', paddingTop: '20px', }}>
                <div>
                    <Select style={{ width: '250px' }}
                        value={this.state.school_id}
                        onChange={school_id => {
                            this.setState({ school_id }, () => {
                                this.examClassesHandle()
                            })

                        }}
                    >
                        {
                            this.state.schoolListData.map(item => {
                                return (
                                    <Option key={item.school_id} value={item.school_id}>{item.school_name}</Option>
                                )
                            })
                        }
                    </Select>
                    <Select style={{ width: '100px' }}
                        value={this.state.class_id}
                        onChange={class_id => {
                            this.setState({ class_id }, () => {
                                this.getStudentListHandle()
                            })
                        }}
                    >
                        {
                            this.state.examClassesData.map(item => {
                                return (
                                    <Option key={item.class_id} value={item.class_id}>{item.name}</Option>
                                )
                            })
                        }
                    </Select>
                    <Select style={{ width: '100px' }}
                        value={this.state.student_id}
                        onChange={(student_id, option) => {
                            this.setState({ student_id, student_name: option.props.children }, () => {
                                this.summaryHandle()
                                this.personalAllHandle()
                                this.individualsOnlyBranchHandle()
                            })
                        }}
                    >
                        {
                            this.state.studentListData.map(item => {
                                return (
                                    <Option key={item.student_id} value={item.student_id}>{item.student_name}</Option>
                                )
                            })
                        }
                    </Select>

                </div>
                <div style={{ width: '100%', height: '45px', marginTop: '30px', display: 'flex', justifyContent: 'center', alignItems: 'center', background: '#0195ff', color: '#fff', borderRadius: '5px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', height: '100%', width: 'auto' }}>
                        {
                            this.state.reportDetailData.subjects.map(item => {
                                return (
                                    <div
                                        key={item.course_id}
                                        onClick={() => {
                                            this.setState({ course_id: item.course_id },()=>{
                                                this.individualsOnlyBranchHandle()
                                            })
                                        }}
                                        style={{ height: '100%', background: this.state.course_id === item.course_id ? '#ffb72f' : 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0 25px' }}
                                    >{item.name}</div>
                                )
                            })
                        }
                    </div>
                </div>
                <div style={{ width: '100%', textAlign: 'center', marginTop: '50px', fontSize: '20px', fontWeight: '500' }}>{this.state.student_name} 的分析报告</div>
                <div style={{ width: '100%', textAlign: 'center', marginTop: '20px' }}>{this.state.reportDetailData.examName}</div>
                <hr style={{ border: '1px solid #cae4f5' }} />
                <div style={{ width: '150px', height: '40px', textAlign: 'center', lineHeight: '40px', color: '#fff', fontSize: '20px', background: '#0195ff', marginTop: '33px', borderRadius: '5px', marginBottom: '45px' }}>成绩单</div>
                <div style={{ width: '980px', margin: 'auto', border: '1px solid #c9e4f9', display: 'flex', flexWrap: 'wrap', justifyContent: 'space-around', marginBottom: '65px' }}>
                    {
                        this.state.course_id === '' ?
                            this.state.personalAllData.scoringRate ? this.state.personalAllData.scoringRate.map(item => {
                                return (
                                    <div key={item.subject_name} style={{ width: '21%', height: '120px', border: '2px solid #c9e4f9', margin: '40px 0 ', display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column' }}>
                                        <div style={{ marginBottom: '15px', fontSize: '22px', }}>
                                            <span style={{ color: '#0097ff' }}>{item.ess_score}</span>
                                            <span>/{item.full_score}</span>
                                        </div>
                                        <div style={{ fontSize: '18px' }}>
                                            <span>{item.subject_name}</span>
                                            <span>/满分</span>
                                        </div>
                                    </div>
                                )
                            }) : ''
                            :
                            <>
                            <div style={{ width: '21%', height: '120px', border: '2px solid #c9e4f9', margin: '40px 0 ', display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column' }}>
                                    <div style={{ marginBottom: '15px', fontSize: '22px', }}>
                                        <span style={{ color: '#0097ff' }}>{this.state.individualsData.individualsOnlyBranch ? this.state.individualsData.individualsOnlyBranch.student_score : ''}</span>
                                        <span>/{this.state.individualsData.individualsOnlyBranch ? this.state.individualsData.individualsOnlyBranch.full_score : ''}</span>
                                    </div>
                                    <div style={{ fontSize: '18px' }}>
                                        <span>总分</span>
                                        <span>/满分</span>
                                    </div>
                                </div>                         
                            <div style={{ width: '21%', height: '120px', border: '2px solid #c9e4f9', margin: '40px 0 ', display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column' }}>
                                
                                    <div style={{ marginBottom: '15px', fontSize: '22px', }}>
                                        <span style={{ color: '#0097ff' }}>{this.state.individualsData.individualsOnlyBranch ? this.state.individualsData.individualsOnlyBranch.class_avg_score : ''}</span>
                                    </div>
                                    <div style={{ fontSize: '18px' }}>
                                        <span>班级平均分</span>
                                    </div>
                                </div>
                            <div style={{ width: '21%', height: '120px', border: '2px solid #c9e4f9', margin: '40px 0 ', display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column' }}>
                                
                                    <div style={{ marginBottom: '15px', fontSize: '22px', }}>
                                        <span style={{ color: '#0097ff' }}>{this.state.individualsData.individualsOnlyBranch ? this.state.individualsData.individualsOnlyBranch.school_avg_score : ''}</span>
                                    </div>
                                    <div style={{ fontSize: '18px' }}>
                                        <span>学校平均分</span>
                                    </div>
                                </div>
                                </>
                                }
                </div>
                            <hr style={{ border: '1px solid #cae4f5' }} />
                            <div style={{ width: '300px', height: '40px', textAlign: 'center', lineHeight: '40px', color: '#fff', fontSize: '20px', background: '#0195ff', marginTop: '33px', borderRadius: '5px', marginBottom: '45px' }}>关注成绩变化，确保稳步提升</div>
                            <h3 style={{ width: '100%', textAlign: 'center', marginTop: '55px', color: 'rgba(0, 0, 0, 0.65)' }}>各知识点比较</h3>
                            <ReactEcharts option={this.compareKnowledgeCharts()} />
                            <hr style={{ border: '1px solid #cae4f5' }} />
                            <div style={{ width: '300px', height: '40px', textAlign: 'center', lineHeight: '40px', color: '#fff', fontSize: '20px', background: '#0195ff', marginTop: '33px', borderRadius: '5px', marginBottom: '45px' }}>稳固优势学科，关注弱势科目</div>
                            <ReactEcharts option={this.advantageCharts()} />
                            <hr style={{ border: '1px solid #cae4f5' }} />
                            <div style={{ width: '300px', height: '40px', textAlign: 'center', lineHeight: '40px', color: '#fff', fontSize: '20px', background: '#0195ff', marginTop: '33px', borderRadius: '5px', marginBottom: '45px' }}>了解分数差距，合理设定目标</div>
                            <Table
                                style={{ marginBottom: '50px' }}
                                columns={scoreGapColumns}
                                dataSource={scoreGapData}
                                rowKey='subject'
                                bordered
                                size="middle"
                                pagination={false}
                            />
                            <hr style={{ border: '1px solid #cae4f5' }} />
                            <div style={{ width: '840px', height: '200px', margin: 'auto', background: '#ffd586', marginTop: '50px', color: '#5f6064' }}>
                                <h2 style={{ width: '100%', textAlign: 'center', color: '#5f6064', paddingTop: '15px' }}>小结</h2>
                                <div style={{ width: '80%', margin: 'auto' }}>{this.state.summaryData}</div>
                            </div>
            </div>
                )
            }
        }
