import React, { Component, createRef } from 'react'
import { Form, Select, Button, BackTop, Icon, Table } from 'antd'
import { examClassesRequest, examSchoolsRequest, reportDetailRequest, overallDataRequest, exportPdfRequest,teacherGetInfoRequest, compareKnowledgeRequest, classKnowledgeRequest, classKnowledgeAnalysisRequest } from 'requests'
import moment from 'moment'
// import html2canvas from 'html2canvas'
import * as echarts from 'echarts'

@Form.create()
class index extends Component {
    constructor() {
        super()
        const arr = window.location.href.split('/')
        const me_id = arr[arr.length - 1].slice(18)
        this.scoreSectionRef = createRef()
        this.compareKnowledgeRef = createRef()
        this.classKnowledgeRef = createRef()
        this.state = {
            me_id,
            class_id: '',
            course_id: '',
            school_id: '',
            kid:'',
            kname:'',
            overall: [],
            classKnowledgeAnalysis:[],
            header_details: {
                subjects: [
                ],
            },
            schoolList: [],
            classesList: [],
            compareKnowledgeData:{
                knowledges:[
                 {   kid:'',
                    name: ''}
                ]
            },
            scoreSection:{
                area:[],
                school: []
            }
        }
    }
    //获取学校
    examSchools = () => {
        examSchoolsRequest(this.state.me_id)
            .then(res => {
                this.setState({ schoolList: res.body })
            })
    }
    //根据me_id,school获取所有考试的班级
    examClasses = () => {
        examClassesRequest(this.state.me_id, this.state.school_id)
            .then(res => {
                this.setState({ classesList: res.body, class_id:res.body.class_id })
            })
    }
    //知识点分析
    compareKnowledgeHandle = ()=>{
        compareKnowledgeRequest(this.state.me_id, this.state.class_id, this.state.course_id)
        .then(res=>{
            this.setState({compareKnowledgeData: res.body,
                kid:res.body.knowledges?res.body.knowledges[0].kid:'',
                kname:res.body.knowledges?res.body.knowledges[0].name:''
            },()=>{
                this.setCompareKnowledgeCharts()
                this.classKnowledgeHandle()

            })
        })
    }
    //分数分段人数分布
    teacherGetInfoHandle = () => {
        teacherGetInfoRequest(this.state.me_id, this.state.class_id, this.state.course_id, this.state.school_id)
        .then(res =>{
            this.setState({scoreSection: res.body},()=>{
                this.setScoreSectionCharts()
            })
        })
    }
    //请求整体数据
    overallData = async () => {
        await overallDataRequest(this.state.me_id, this.state.class_id, this.state.course_id)
            .then(res => {
                this.setState({overall: res.body})
            })
    }
    //各班知识点统计
    classKnowledgeHandle = () => {
        classKnowledgeRequest(this.state.me_id,this.state.kid,this.state.class_id,this.state.course_id)
        .then(res =>{
            this.setState({
                classKnowledgeData: res.body
            },()=>{
                this.setClassKnowledgeCharts()
            })
        })
    }
    //各班知识点分析
    classKnowledgeAnalysisHandle = () =>{
        classKnowledgeAnalysisRequest(this.state.me_id, this.state.class_id, this.state.course_id)
        .then(res=>{
            this.setState({classKnowledgeAnalysis:res.body})
        })
    }
    //设置分数分段图
    setScoreSectionCharts = () =>{
        const scoreSectionCharts = echarts.init(this.scoreSectionRef.current)
        scoreSectionCharts.setOption({
            color: ['#2fb4ff','#fdb82d','#c23531','#dddddd'],
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross',
                    crossStyle: {
                        color: '#999'
                    }
                }
            },
            toolbox: {
                feature: {
                    dataView: {show: true, readOnly: false},
                    magicType: {show: true, type: ['line', 'bar']},
                    restore: {show: true},
                    saveAsImage: {show: true},
                }
            },
            legend: {
                data:['本校人数','校比例','市比例']
            },
            xAxis: [
                {
                    type: 'category',
                    data: this.state.scoreSection.school.reduce((sum, curr)=>{
                        sum.push(curr.segmentation)
                        return sum
                    },[]),
                    axisPointer: {
                        type: 'shadow'
                    }
                }
            ],
            yAxis: [
                {
                    type: 'value',
                    name: '人数',
                    // min: 0,
                    // max: 80,
                    // interval: 20,
                    axisLabel: {
                        formatter: '{value}人'
                    }
                }, {
                    type: 'value',
                    name: '百分比',
                    min: 0,
                    max: 60,
                    // interval: 25,
                    axisLabel: {
                        formatter: '{value}%'
                    }
                }
            ],
            series: [
                {
                    name:'本校人数',
                    type:'bar',
                    data:this.state.scoreSection.school.reduce((sum, curr)=> {
                        sum.push(curr.number)
                        return sum
                    },[])
                },
                {
                    name:'校比例',
                    type:'line',
                    data: this.state.scoreSection.school.reduce((sum, curr)=>{
                        sum.push(curr.rate)
                        return sum
                    },[])
                },
                {
                    name:'市比例',
                    type:'line',
                    data: this.state.scoreSection.area.reduce((sum, curr)=>{
                        sum.push(curr.rate)
                        return sum
                    },[])
                }
            ]
        })
    }
    //设置知识点比较图
    setCompareKnowledgeCharts = () => {
        const scoreSectionCharts = echarts.init(this.compareKnowledgeRef.current)
        scoreSectionCharts.setOption({
            color: ['#2fb4ff','#fdb82d','#c23531','#dddddd'],
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross',
                    crossStyle: {
                        color: '#dedede'
                    }
                }
            },
            toolbox: {
                feature: {
                    dataView: {show: true, readOnly: false},
                    magicType: {show: true, type: ['line', 'bar']},
                    restore: {show: true},
                    saveAsImage: {show: true}
                }
            },
            legend: {
                data:['学校得分率','全班得分率','全市得分率']
            },
            xAxis: [
                {
                    type: 'category',
                    data: this.state.compareKnowledgeData.knowledges?this.state.compareKnowledgeData.knowledges.reduce((sum, curr)=>{
                        sum.push(curr.name)
                        return sum
                    },[]):[],
                    axisPointer: {
                        type: 'shadow'
                    }
                }
            ],
            yAxis: [
                {
                    type: 'value',
                    name: '百分比',
                    // min: 0,
                    // max: 80,
                    // interval: 20,
                    axisLabel: {
                        formatter: '{value}%'
                    }
                }
            ],
            series: [
                {
                    name:'学校得分率',
                    type:'bar',
                    data:this.state.compareKnowledgeData.knowledges?this.state.compareKnowledgeData.knowledges.reduce((sum, curr)=> {
                        sum.push(curr.schoolKnowledgeProbability)
                        return sum
                    },[]):[]
                },
                {
                    name:'全班得分率',
                    type:'line',
                    data: this.state.compareKnowledgeData.knowledges?this.state.compareKnowledgeData.knowledges.reduce((sum, curr)=>{
                        sum.push(curr.classKnowledgeProbability)
                        return sum
                    },[]):[]
                },
                {
                    name:'全市得分率',
                    type:'line',
                    data: this.state.compareKnowledgeData.knowledges?this.state.compareKnowledgeData.knowledges.reduce((sum, curr)=>{
                        sum.push(curr.countyKnowledgeProbability)
                        return sum
                    },[]):[]
                }
            ]
        })
    }
      //设置各班知识点统计图
    setClassKnowledgeCharts = () => {
        const scoreSectionCharts = echarts.init(this.classKnowledgeRef.current)
        scoreSectionCharts.setOption({
            color: ['#2fb4ff','#fdb82d','#c23531','#dddddd'],
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross',
                    crossStyle: {
                        color: '#dedede'
                    }
                }
            },
            toolbox: {
                feature: {
                    dataView: {show: true, readOnly: false},
                    magicType: {show: true, type: ['line', 'bar']},
                    restore: {show: true},
                    saveAsImage: {show: true}
                }
            },
            legend: {
                data:['班级得分率','全市得分率','全校得分率']
            },
            yAxis: [
                {
                    type: 'category',
                    data: this.state.classKnowledgeData.class.reduce((sum, curr)=>{
                        sum.push(curr.class_name)
                        return sum
                    },[]),
                    axisPointer: {
                        type: 'shadow'
                    }
                }
            ],
            xAxis: [
                {
                    type: 'value',
                    name: '百分比',
                    // min: 0,
                    // max: 80,
                    // interval: 20,
                    axisLabel: {
                        formatter: '{value}%'
                    }
                }
            ],
            series: [
                {
                    name:'班级得分率',
                    type:'bar',
                    data:this.state.classKnowledgeData.class.reduce((sum, curr)=>{
                        sum.push(curr.classKnowledgeProbability)
                        return sum
                    },[]),
                },
                {
                    name:'全市得分率',
                    type:'line',
                    data: this.state.classKnowledgeData.class.reduce((sum, curr)=>{
                        sum.push(this.state.classKnowledgeData.county.countyKnowledgeProbability)
                        return sum
                    },[]),
                },
                {
                    name:'全校得分率',
                    type:'line',
                    data: this.state.classKnowledgeData.class.reduce((sum, curr)=>{
                        sum.push(this.state.classKnowledgeData.school.schoolKnowledgeProbability)
                        return sum
                    },[])
                }
            ]
        })
    }
    componentDidMount = async () => {
        await examSchoolsRequest(this.state.me_id)
        .then(res => {
            this.setState({ schoolList: res.body })
        })
        //获取报告详情
        await reportDetailRequest(this.state.me_id)
        .then(async res => {
            this.setState({ header_details: res.body })
        })
        await examClassesRequest(this.state.me_id, this.state.schoolList?this.state.schoolList[0].school_id:'')
        .then((res) => {
            this.setState({ classesList: res.body })
        })
        // const school_id = this.state.schoolList.length ? this.state.schoolList[0].school_id: ''
        // const class_id = this.state.classesList.length ? this.state.classesList[0].class_id : ''
        // const course_id = this.state.header_details.subjects.length ? this.state.header_details.subjects[0].course_id : ''
        await this.setState({ course_id:  this.state.header_details.subjects[0].course_id, 
                class_id: this.state.classesList[0].class_id, 
                school_id: this.state.schoolList[0].school_id 
            })
        
        this.overallData()
        this.teacherGetInfoHandle()
        this.compareKnowledgeHandle()
        this.classKnowledgeAnalysisHandle()
    }
    render() {
        const { getFieldDecorator } = this.props.form
        const { Option } = Select
        const { examDate, examName, gradeName, subjects } = this.state.header_details
        const {
            schoolList,
            classesList
        } = this.state
        const columns = [
            {
                title: '单位',
                dataIndex: 'row_name'
            },
            {
                title: '试卷满分',
                dataIndex: 'full_score',
            },
            {
                title: '实考人数',
                dataIndex: 'student_count',
            },
            {
                title: '最高分',
                dataIndex: 'max_score',
            },
            {
                title: '最低分',
                dataIndex: 'min_score',
            },
            {
                title: '平均分',
                dataIndex: 'avg_score',
            },
            {
                title: '标准差',
                dataIndex: 'standard',
            },
        ];
      
        const columnsLast = this.state.classKnowledgeAnalysis.length?[
            {
                title: '得分率',
                dataIndex: 'title'
            },
            {
                title: '区学校最高',
                dataIndex: 'best'
            },
            {
                title: this.state.classKnowledgeAnalysis[0].knowledgeAnalysis.county.relation_name,
                dataIndex: 'countyKnowledgeProbability'
            },
            {
                title: this.state.classKnowledgeAnalysis[0].knowledgeAnalysis.school.name,
                dataIndex: 'schoolKnowledgeProbability'
            },
            ...this.state.classKnowledgeAnalysis[0].knowledgeAnalysis.class.map((item, index) =>{
                item = {
                    title: item.class_name,
                    dataIndex: index,
                }
                return item
            })
        ]:[]
        let dataArr = this.state.classKnowledgeAnalysis.length?this.state.classKnowledgeAnalysis[0].knowledgeAnalysis.class.map((every, index) =>{
               return this.state.classKnowledgeAnalysis[0].knowledgeAnalysis.class[index].classKnowledgeProbability + '%'
        }):[]
        const dataSourceLast = this.state.classKnowledgeAnalysis.length? [
                ...this.state.classKnowledgeAnalysis.map(item => {
                     item = {
                         title: item.name,
                         best: item.knowledgeAnalysis.best + '%',
                         countyKnowledgeProbability: item.knowledgeAnalysis.county.countyKnowledgeProbability + '%',
                         schoolKnowledgeProbability: item.knowledgeAnalysis.school.schoolKnowledgeProbability + '%',
                         ...dataArr
                         
                     }
                     return item
                }),
        ]: []
        return (
            <div id='classreport' style={{ width: '1150px', margin: 'auto', background: '#fff', padding: '0 30px', boxSizing: 'border-box', paddingTop: '20px', }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: '1080px', margin: 'auto', border: '2px solid #cae4f5', height: '70px', padding: '0 15px', boxSizing: 'border-box' }}>
                    <div style={{ fontSize: '16px', width: '330px', whiteSpace: 'nowrap', textOverflow: 'ellipsis', overflow: 'hidden' }}>{examName}</div>
                    <Select style={{ width: 85 }}
                        placeholder={subjects.length ? subjects[0].name : ''}
                        onChange={async (course_id) => {
                            await this.setState({ course_id })
                            await this.overallData()
                            this.teacherGetInfoHandle()
                            this.compareKnowledgeHandle()
                            this.classKnowledgeAnalysisHandle()
                            this.classKnowledgeHandle()
                        }}
                    >
                        {subjects.map(item => {
                            return (
                                <Option key={item.course_id} value={item.course_id}>{item.name}</Option>
                            )
                        })}
                    </Select>
                    <Select style={{ width: 200 }} 
                        placeholder={schoolList.length ? schoolList[0].school_name : ''} 
                        onChange={value => {
                            this.setState({school_id: value},async()=>{
                                await examClassesRequest(this.state.me_id, this.state.school_id)
                                    .then(res => {
                                        this.setState({ classesList: res.body, class_id:res.body.class_id })
                                    })

                                const class_id = this.state.classesList.length ? this.state.classesList[0].class_id : ''
                                await this.setState({class_id})
                                await this.props.form.setFieldsValue({
                                    classes: class_id
                                })
                                await this.overallData()
                                await this.teacherGetInfoHandle()
                        })
                    }}>
                        {
                            schoolList.map(item => {
                                return (
                                    <Option key={item.school_id} value={item.school_id}>{item.school_name}</Option>
                                )
                            })
                        }
                    </Select>
                   <Form.Item style = {{marginTop: '25px'}}>
                        {
                            getFieldDecorator('classes', {
                              })(
                                    <Select style={{ width: 85 }}
                                        placeholder={classesList.length ? classesList[0].name : ''}
                                        onChange={async class_id => {
                                            await this.setState({ class_id })
                                            this.teacherGetInfoHandle()
                                            this.compareKnowledgeHandle()
                                            this.classKnowledgeAnalysisHandle()
                                            this.classKnowledgeHandle()
                                        }}>
                                        {
                                            classesList.map(item => {
                                                return (
                                                    <Option key={item.class_id} value={item.class_id}>{item.name}</Option>
                                                )
                                            })
                                        }
                                    </Select>
                              )
                        }
                   </Form.Item>
                    <div>考试时间：{moment(examDate * 1000).format('YYYY-MM-DD')}</div>
                    <div>年级：{gradeName}</div>
                    {/* <Button
                        type='primary'
                        onClick={()=> {
                            exportPdfRequest(document.querySelector('#classreport').outerHTML, this.state.me_id)
                        }}
                    >下载</Button> */}
                </div>
                <div style={{ width: '105px', height: '40px', textAlign: 'center', lineHeight: '40px', color: '#fff', fontSize: '20px', background: '#0195ff', marginTop: '33px', borderRadius: '5px', marginBottom: '45px' }}>整体数据</div>
                <Table 
                    columns={columns} 
                    dataSource={this.state.overall} 
                    rowKey='row_name'
                    bordered
                    size="middle"
                    pagination = {false}
                />
                <hr style={{border:'1px solid #cae4f5'}}/>
                <div style={{ width: '105px', height: '40px', textAlign: 'center', lineHeight: '40px', color: '#fff', fontSize: '20px', background: '#0195ff', marginTop: '33px', borderRadius: '5px', marginBottom: '45px' }}>分数段人数分布(校)</div>
                <table style={{width:'100%',color:'rgba(0, 0, 0, 0.65)',transition: 'all 0.3s, height 0s' }}>
                    <tbody>
                    <tr style={{height:'45px', lineHeight:'45px'}}>
                        <td style={{border: ' 1px solid #dedede', paddingLeft:'5px', boxSizing:'borderBox'}}>分数</td>
                        {this.state.scoreSection.school.map(item =>{
                            return(
                                <td style={{border: ' 1px solid #dedede', paddingLeft:'5px', boxSizing:'borderBox'}} key={item.segmentation}>{item.segmentation}</td>
                            )
                        })}
                    </tr>
                    <tr style={{height:'45px', lineHeight:'45px'}}>
                        <td style={{border: ' 1px solid #dedede', paddingLeft:'5px', boxSizing:'borderBox'}}>人数</td>
                        {this.state.scoreSection.school.map(item =>{
                            return(
                                <td style={{border: ' 1px solid #dedede', paddingLeft:'5px', boxSizing:'borderBox'}} key={item.segmentation}>{item.number}</td>
                            )
                        })}
                    </tr>
                    <tr style={{height:'45px', lineHeight:'45px'}}>
                        <td style={{border: ' 1px solid #dedede', paddingLeft:'5px', boxSizing:'borderBox'}}>百分比</td>
                        {this.state.scoreSection.school.map(item =>{
                            return(
                                <td style={{border: ' 1px solid #dedede', paddingLeft:'5px', boxSizing:'borderBox'}} key={item.segmentation + 1}>{item.rate}</td>
                            )
                        })}
                    </tr>
                    </tbody>
                </table>
                <h3 style={{width:'100%', textAlign:'center',marginTop:'55px',color:'rgba(0, 0, 0, 0.65)'}}>总分分段人数分布</h3>
                <div ref={this.scoreSectionRef} style={{width:'100%', margin:'auto', height:'400px',}}></div>
                <hr style={{border:'1px solid #cae4f5'}}/> 
                <div style={{ width: '150px', height: '40px', textAlign: 'center', lineHeight: '40px', color: '#fff', fontSize: '20px', background: '#0195ff', marginTop: '33px', borderRadius: '5px', marginBottom: '45px' }}>知识点分析</div>
                <h3 style={{width:'100%', textAlign:'center',marginTop:'55px',color:'rgba(0, 0, 0, 0.65)'}}>各知识点比较</h3>
                <div ref={this.compareKnowledgeRef} style={{width:'100%', margin:'auto', height:'400px',}}></div>
                <hr style={{border:'1px solid #cae4f5'}}/>
                <div style={{ width:'150px', height: '40px', textAlign: 'center', lineHeight: '40px', color: '#fff', fontSize: '20px', background: '#0195ff', marginTop: '33px', borderRadius: '5px', marginBottom: '45px' }}>各班知识点统计</div>
                <div style={{display:'flex'}}>
                    <h3 style={{width:'50%', textAlign:'right',marginTop:'55px',color:'rgba(0, 0, 0, 0.65)'}}>{this.state.kname}</h3>
                    <Select 
                        style={{marginTop:'55px', width:'150px', marginLeft:'40%'}}
                        placeholder={this.state.compareKnowledgeData.knowledges?this.state.compareKnowledgeData.knowledges[0].name:''}
                        onChange={(value, option) => {
                            this.setState({
                                kname: option.props.children,
                                kid: value
                            },()=>{
                                this.classKnowledgeHandle()
                            })
                        }}
                    >
                        {this.state.compareKnowledgeData.knowledges?this.state.compareKnowledgeData.knowledges.map(item=>{
                            return(
                                <Option key={item.kid} value={item.kid}>{item.name}</Option>
                            )
                        }):''}
                    </Select>
                
                </div>
                <div ref={this.classKnowledgeRef} style={{width:'100%', margin:'auto', height:'400px'}}></div>
                <hr style={{border:'1px solid #cae4f5'}}/>
                <div style={{ width: '150px', height: '40px', textAlign: 'center', lineHeight: '40px', color: '#fff', fontSize: '20px', background: '#0195ff', marginTop: '33px', borderRadius: '5px', marginBottom: '45px' }}>各班知识点分析</div>
                <Table 
                    style={{marginBottom:'50px'}}
                    columns={columnsLast} 
                    dataSource={dataSourceLast}
                    rowKey='title'
                    bordered
                    size="middle"
                    pagination = {false}
                />
                <BackTop style={{ position: 'fixed', width: '70px', height: '70px', right: '5%', top: '50%', background: '#0195ff', color: '#fff', display: 'flex', flexDirection: 'column', justifyContent: 'center', borderRadius: '50%' }}>
                    <Icon style={{ fontSize: '24px' }} type="vertical-align-top" />
                    <div style={{ textAlign: 'center' }}>回到顶部</div>
                </BackTop>
            </div>
        )
    }
}

export default index