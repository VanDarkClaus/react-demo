export const isShowByRoot = (componentName) =>{
    if(!JSON.parse(sessionStorage.getItem('token')).permission_list.some(item => item === componentName)){
        return {
            display: 'none'
        }
    }
}
export const addNewRoleShow = id => {
    if(sessionStorage.getItem('token')){

        if (!(id === 13 || id === 16 || id === 17 || id === 18 || id === 19 || id === 20 || id === 21)){
            return {
                display: 'none'
            }
        }else {
            return {
                display: 'block'
            }
        }
    }
}

//通过控制样式显示隐藏
export const RoleThanThree = (role) => {
    if(sessionStorage.getItem('token')){
        if(JSON.parse(sessionStorage.getItem('token')).user_info.role>role) {
            return {
                display:'none'
            }
        }
    }
}
//通过控制路由来显示隐藏
export const routesThanThree =(role) =>{
    if(sessionStorage.getItem('token')){
        if(JSON.parse(sessionStorage.getItem('token')).user_info.role>role) {
            return false
        }else{
            return true
        }
    }else {
        return true
    }
}