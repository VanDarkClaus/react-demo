import Loadable from 'react-loadable'
import React from 'react' 

//过场的组件
const myLoadingComponent = ({isLoading, err}) => {
    if(isLoading){
        return <div>loading..........</div>
    } else if(err){
        return <div>sorry this page hava some problem</div>
    }else {
        return null
    }
}
 //第一个参数是需要包装的组件，第二个参数是过场等待组件
export default (loader, loading = myLoadingComponent) =>{
    return  Loadable({
        loader,
        loading
      });
}