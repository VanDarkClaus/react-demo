import h_actionTypes from './actionTypes/h_actionTypes'
import { loginRequest } from '../requests'

//登录
export const loginDispatch = values => dispatch => {
    loginRequest(values)
    .then(res=> {
        sessionStorage.setItem('token',JSON.stringify({
            ...res.body,
            username: values.username
        }))
        dispatch({
            type: h_actionTypes.LOGIN,
            payload: {
                loginValues: {
                    ...res.body,
                    username: values.username
                }
            }
        })
    })
}

//登出
export const loginoutDispatch = () => dispatch =>{
    sessionStorage.removeItem('token')
    dispatch({
        type: h_actionTypes.LOGINOUT,
    })
}