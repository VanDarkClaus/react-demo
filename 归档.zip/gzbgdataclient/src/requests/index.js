import axios from 'axios'
import {message} from 'antd'

const baseURL =  'http://server.mymuxue.com/'
// const baseURL = process.env.NODE_ENV === 'production' ? 'http://preview.mymuxue.com/':'http://192.168.1.60:8084'
var instance = axios.create({
  baseURL,
  headers:{
    "Content-Type": "application/json;charset=UTF-8"
  }
})

instance.interceptors.request.use(config=>{
  if(sessionStorage.getItem("token")){
    config.headers['Authorization']=JSON.parse(sessionStorage.getItem("token")).access_token
  }
  return config
})

instance.interceptors.response.use(res=>{
  //判断token是否过期
  if(res.data.code === 401) {
    message.error(res.data.message)
    sessionStorage.removeItem('token')
    window.location.href="/login"
  }
  return res.data
})

//登录请求
export const loginRequest=({username,password})=>{
  return instance.post("/v2/auth/login", {
    username,
    password,
    grant_type: 'password'
  })
}

//获取知识点类型?XDEBUG_SESSION_START=8084
export const getKnowledge = () => { 
  return instance.post('/v2/user/account-info')
}

// 校本组卷试卷列表
export const testPaperList = () => {
  return instance.get('/v2/dict/get-exam-list')
}

// 校本组卷下载试卷
export const downLoadTextPaper = (se_id) => {
  return instance.get(`v2/exam/download-test-paper?se_id=${se_id}`)
}

// 试卷分析
export const analysisPaper = (se_id) => {
  return instance.get(`v2/exam/get-analysis?se_id=${se_id}`)
}

// 学情大数据
export const getExamList = () => {
  return instance.get(`v2/dict/get-exam-list`)
}

// 导出错题
export const exportProblem = (knowledge_point, answer, analysis, expand, selfProposition, se_id, school_id, student_ids, class_id) => {
  return instance.get(`v2/exam/product-mistakes-collection?knowledge_point=${knowledge_point}&answer=${answer}&analysis=${analysis}&expand=${expand}&selfProposition=${selfProposition}&se_id=${se_id}&school_id=${school_id}&student_ids=${student_ids}&class_id=${class_id}`)
}

// 添加学校
export const addSchool = (area_id, name) => {
  return instance.post('/v2/base-data/add-school', {
    area_id,
    name
  })
}

// 数据采集获取学校列表
export const getSchoolList = (me_id) => {
  return instance.post('/v2/student/upload-statistics', {
    me_id
  })
}

// 考生信息录入-点击学校获取该学校下的所有学生信息
export const getStudentsList = ( me_id, school_id, limit = 10, student_id, page = 1) => {
  const offset = limit * (page - 1)
  return instance.post('/v2/student/upload-detail', {
    me_id,
    school_id,
    offset,
    student_id
  })
}

// 学生信息导出-学校/学生列表
export const exportSchoolList = (me_id) => {
  return instance.get(`/v2/down/student-excel?me_id=${me_id}`,{timeout: 60000})
}

// 下载学生列表模板
export const downSchoolList = () => {
  return instance.get('/v2/down/template?type=student')
}

// 学生信息导入--检查校验
export const checkStudents = (me_id) => {
  return instance.post('/v2/student/examming-students', {
    me_id
  })
}

// 导入学生信息-检查文件列表
export const checkFileList = (me_id) => {
  return instance.post('/v2/student/upload-data-state', {
    me_id
  })
}
// 创建考试-获取考试详情
export const creatDetail = (me_id) => {
  return instance.get(`/v2/exam/detail?me_id=${me_id}&XDEBUG_SESSION_START=8084`)
}

// 导入学生信息-检查文件列表详情-删除已上传
export const deleteFileList = (id) => {
  return instance.post('/v2/student/delete-data-state', {
    id
  })
}

//修改个人信息
export const updateSelfRequest = (nick, phone) => {
  return instance.post('/v2/user/update-self', {
    nick,
    phone
  })
}

//修改密码
export const modifyPswRequest = (new_pass, old_pass) => {
  return instance.post('/v2/user/modify-passwd', {
    new_pass,
    old_pass
  })
}

//角色列表
export const roleListRequest = () => {
  return instance.get('/v2/admin/role-list')
}

//操作日志
export const operationLogRequest = (page, limit) => {
  let offset = (page - 1) * limit
  return instance.get(`/v2/admin/operation-log?limit=${limit}&offset=${offset}`)
}

//登录日志
export const LoginLogRequest = (page, limit) => {
  let offset = (page - 1) * limit
  return instance.get(`/v2/admin/login-log?limit=${limit}&offset=${offset}`)
}

//用户列表
export const userListRequest = (page, limit) => {
  let offset = (page - 1) * limit
  return instance.get(`/v2/admin/user-list?limit=${limit}&offset=${offset}`)
}

//获取城市-地区字典
export const cityAreasRequest = (province_id, role_id) => {
  return instance.get(`/v2/dict/city-areas?province_id=${province_id}&role_id=${role_id}`)
}

//获取地区下的学校列表
export const schoolsRequest = area_id => {
  return instance.get(`/v2/dict/schools?area_id=${area_id}`)
}

//获取学校下指定年级的班级列表
export const schoolClassesRequest = (school_id, grade_id) => {
  return instance.get(`/v2/dict/school-classes?school_id=${school_id}&grade_id=${grade_id}`)
}

//用户添加
export const userCreateRequest = (login_name, name, password, mobile, type, city_id, area_id, school_id, grade_id, arr_class_id, arr_course_id) =>{
  return instance.post('/v2/admin/user-create', {
    login_name, name, password, mobile, type, city_id, area_id, school_id, grade_id, arr_class_id, arr_course_id
  })
}
//用户编辑
export const userUpdateRequest = (user_id = '', name = '', password = '', mobile = '', type ='', city_id ='', area_id ='', school_id = '' , grade_id = '', arr_class_id ='', arr_course_id ='') =>{
  return instance.post('/v2/admin/user-update', {
    user_id, name, password, mobile, type, city_id, area_id, school_id, grade_id, arr_class_id, arr_course_id
})
}

//用户删除
export const userDeleteRequest = user_id => {
  return instance.post('/v2/admin/user-delete', {
    user_id
  })
}

//获取考试列表
export const examListRequest = (limit, page) => {
  const offset = (page-1)*limit
  return instance.get(`/v2/exam/exam-list?limit=${limit}&offset=${offset}`)
}

//创建考试
export const examCreateRequest = (school_id, grade_id, time, name, enter_year, term_code, course_arr, course_type, area_id, city_id, name_suffix, exam_type, exam_number_length, collection_time_start, collection_time_end) => {
  console.log(school_id, grade_id, time, name, enter_year, term_code, course_arr, course_type, area_id, city_id, name_suffix, exam_type, exam_number_length, collection_time_start, collection_time_end)
  return instance.post('v2/exam/create', {
    school_id, grade_id, time, name, enter_year, term_code, course_arr, course_type, area_id, city_id, name_suffix, exam_type, exam_number_length, collection_time_start, collection_time_end
  })
}

//修改考试
export const examUpdateRequest = (school_id, grade_id, time, name, enter_year, term_code, course_arr, course_type, area_id, city_id, name_suffix, exam_type, exam_number_length, collection_time_start, collection_time_end, me_id) => {
  // console.log('this is edit',school_id, grade_id, time, name, enter_year, term_code, course_arr, course_type, area_id, city_id, name_suffix, exam_type, exam_number_length, collection_time_start, collection_time_end, me_id)
  return instance.post('v2/exam/update?XDEBUG_SESSION_START=8084', {
    school_id, grade_id, time, name, enter_year, term_code, course_arr, course_type, area_id, city_id, name_suffix, exam_type, exam_number_length, collection_time_start, collection_time_end, me_id
  })
}

//删除考试
export const examDeleteRequest = me_id =>{
  return instance.post('/v2/exam/delete', {me_id})
}

//考试成绩导入-录入学生excle成绩
export const putScoreByExcel = (se_id, file) =>{
  return instance.post('/v2/upload/put-score-by-excel', {se_id, file})
}

//获取指定学生成绩
export const searchStudent = (student_id, se_id) => {
  student_id = parseInt(student_id)
  console.log(typeof student_id, typeof se_id)
  return instance.get(`/v2/score/search-student?student_id=${student_id}&se_id=${se_id}&XDEBUG_SESSION_START=8084`)
}