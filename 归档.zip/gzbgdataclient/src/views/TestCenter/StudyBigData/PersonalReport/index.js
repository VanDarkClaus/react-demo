import React, { Component } from 'react'

export default class index extends Component {
    render() {
        return (
            <div>
                个人报告
            </div>
        )
    }
}
