import React, { Component } from 'react'
import { getExamList } from '../../../requests'
import { exportProblemDispatch } from '../../../actions/exportProble'
import { Layout, Card, Button, Select, DatePicker , Modal } from 'antd'
import './StudyBigData.less'
import { connect } from 'react-redux'



const { Content, Footer } = Layout
const { Option } = Select
const { RangePicker } = DatePicker



// 下拉菜单的选中项
function handleChange(value) {
    console.log(`selected ${value}`);
  }

// 选择日期
function onChange(date, dateString) {
  console.log(date, dateString);
}

// 将 state 中保存的通知状态数据映射为组件的属性
const mapStateToProps = (state) => {
    // 返回一个对象
    return {
      cloudscore: state.cloudscore
    }
}

@connect(
    mapStateToProps,
    { exportProblemDispatch }
)
class StudyBigData extends Component {

    constructor() {
        super()
        this.state = {
            visible: false,
            textPaperList: [],
            visible: false,
            difficultyAnalysis: [],
            knowledgesAnalysis: [],
            paperAmountDistribution: [],
            data: []
        }
    }

    handleOk = e => {
        console.log(e);
        this.setState({
          visible: false,
        });
      };
    
      handleCancel = e => {
        console.log(e);
        this.setState({
          visible: false,
        });
      };
      showModal = () => {
        this.setState({
          visible: true,
        });
      };
    // 获取试卷列表数据
    componentDidMount() {
        getExamList()
            .then(resp => {
                console.log(resp)
                this.setState({
                    textPaperList: resp.body.contents
                })
                console.log(this.state.textPaperList)
            })
    }

    // 导出错题
    exportProblem = (knowledge_point, answer, analysis, expand, selfProposition, se_id, school_id, student_ids, class_id) => {
        console.log(knowledge_point, answer, analysis, expand, selfProposition, se_id, school_id, student_ids, class_id)
       this.props.exportProblemDispatch(knowledge_point, answer, analysis, expand, selfProposition, se_id, school_id, student_ids, class_id)
    }



    render() {
        return (
            <Layout className="layout chen-layout">
                <Content style={{ padding: '0 15%', backgroundColor: "#f3faff" }}>
                <div style={{ background: '#fff', margin: 24, minHeight: 280}}>
                    <div style={{textAlign: "center", paddingTop: 20}}>
                        <Select defaultValue="请选择" style={{ width: 80 }} onChange={handleChange}>
                            <Option value="请选择">请选择</Option>
                            <Option value="lucy">Lucy</Option>
                            <Option value="Yiminghe">yiminghe</Option>
                        </Select>
                        <Select defaultValue="请选择" style={{ width: 80 }} onChange={handleChange}>
                            <Option value="请选择">请选择</Option>
                            <Option value="lucy">Lucy</Option>
                            <Option value="Yiminghe">yiminghe</Option>
                        </Select>
                        <Select defaultValue="请选择" style={{ width: 80 }} onChange={handleChange}>
                            <Option value="请选择">请选择</Option>
                            <Option value="lucy">Lucy</Option>
                            <Option value="Yiminghe">yiminghe</Option>
                        </Select>
                        <Select defaultValue="请选择" style={{ width: 80 }} onChange={handleChange}>
                            <Option value="请选择">全部年级</Option>
                            <Option value="lucy">Lucy</Option>
                            <Option value="Yiminghe">yiminghe</Option>
                        </Select>
                        <Select defaultValue="请选择" style={{ width: 80 }} onChange={handleChange}>
                            <Option value="请选择">语文</Option>
                            <Option value="lucy">Lucy</Option>
                            <Option value="Yiminghe">yiminghe</Option>
                        </Select>
                        <RangePicker onChange={onChange} />
                    </div>
                    <Card bordered={false} title={this.state.textPaperList.map((item) => {
                        return (
                        <Card style={{margin: "20px 20px"}} title={item.se_name} key={item.se_id}>
                            <div style={{display: "flex", justifyContent: "space-bwtten"}}>
                                <span>考试时间：</span>
                                <span>{
                                    new Date(parseInt(item.created_at) * 1000).toLocaleString().replace(/:\$/)
                                }</span>
                                <span style={{marginLeft: "4%"}}>年级：</span><span>{item.grade_name}</span>
                                <span style={{marginLeft: "4%"}}>科目：</span><span>{item.course_name}</span>
                                <span style={{marginLeft: "4%"}}>浏览：</span><span>121</span>
                            </div>
                            <Button.Group style={{marginLeft: "10%", float: "right"}}>
                            <Button type="primary">
                                进入评卷
                            </Button>
                            <Button type="primary" onClick={
                                () => {
                                    this.showModal()
                                    // this.setState()
                                    console.log(item)
                                }
                            }>
                                查看学情
                            </Button >
                            <Button type="primary" onClick={
                                () => {
                                    this.exportProblem(item.knowledge_point, item.answer, item.analysis, item.expand, item.selfProposition, item.se_id, item.school_id, item.student_ids, item.class_id)
                                }
                            }>
                                导出错题
                            </Button>
                        </Button.Group>
                        </Card>
                        )
                    })} >
                    </Card>
                </div>
                </Content>
                <Footer style={{ textAlign: 'center', backgroundColor: "#f3faff" }}></Footer>
                <Modal
                    title="学情列表"
                    visible={this.state.visible}
                    onOk={this.handleOk}
                    onCancel={this.handleCancel}
                    width ={250}
                >
                        <Button type='primary' onClick={()=>{this.props.history.push('/admin/testcenter/studybigdata/classreport')}} style={{margin: '5px 10px',}}>班级报告</Button>
                        <Button type='primary' onClick={()=>{this.props.history.push('/admin/testcenter/studybigdata/personalreport')}} style={{margin: '5px 10px',}}>个人报告</Button>
                        <Button type='primary' onClick={()=>{this.props.history.push('/admin/testcenter/studybigdata/schoolreport')}} style={{margin: '5px 10px',}}>学校报告</Button>
                        <Button type='primary' onClick={()=>{this.props.history.push('/admin/testcenter/studybigdata/overallreport')}} style={{margin: '5px 10px',}}>总体报告</Button>
                </Modal>
            </Layout>
        )
    }
}

export default StudyBigData
