import React, { Component } from 'react'
import { Form, Icon, Input, Button } from 'antd'
import {connect} from 'react-redux'
import { loginDispatch } from '../../actions/loginActions'
import { Redirect } from 'react-router-dom'
import './login.less'

const mapStateToProps = state =>   {
  return {
    state
  }
}

@connect(mapStateToProps, {loginDispatch})
@Form.create({ name: 'normal_login' })
class index extends Component {
  handleSubmit = e => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
      if (!err) {
        this.props.loginDispatch(values)
        e.preventDefault();
      }
    });
  };

  render() {
    const { getFieldDecorator } = this.props.form;
    return (
      this.props.state.loginReducer.loginValues.access_token?
      <Redirect to = '/admin'/>
      :
      <div className='login-img'>
        <div className='mx-login'>
          <img src='images/logo1.png' alt="慕学"/>
          <Form  className="login-form">
            <Form.Item>
              {getFieldDecorator('username', {
                rules: [{ required: true, message: '请输入账号' }],
              })(
                <Input
                  style={{ width: '295px', height: '45px'}}
                  prefix={<Icon type="user" style={{ color: 'rgba(0,0,0,.25)' }} />}
                  placeholder="账号"
                />,
              )}
            </Form.Item>
            <Form.Item>
              {getFieldDecorator('password', {
                rules: [{ required: true, message: '请输入密码' }],
              })(
                <Input
                  style={{ width: '295px', height: '45px'}}
                  prefix={<Icon type="lock" style={{ color: 'rgba(0,0,0,.25)' }} />}
                  type="password"
                  placeholder="密码"
                />,
              )}
            </Form.Item>
            <Form.Item>
              <Button
                onClick={this.handleSubmit}
                type="primary"
                htmlType="submit"
                style={{ width: '295px', height: '45px', background: '#00B400'}}
              >
                登录
            </Button>
            </Form.Item>
          </Form>
            <a href='http://mymuxue.com' >返回首页</a>
        </div>
      </div>
    )
  }
}

export default index