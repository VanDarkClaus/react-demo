import React, { Component } from 'react'
import {Card, Form, Table, Button, Modal } from 'antd'
import {roleListRequest} from '../../../../requests'

@Form.create()
class index extends Component {
  constructor() {
    super()
    this.state = {
      visible: false,
      confirmLoading: false,
      dataSource: [
        {
          id: "",
          remark: "",
          role_name: "",
          status: "",
        },
      ]
    }
  }

  showModal = id => {
    this.setState({
      visible: true,
      selectId: id
    });
  };

  handleOk = () => {
    this.setState({
      confirmLoading: true,
    });
    setTimeout(() => {
      this.setState({
        visible: false,
        confirmLoading: false,
        selectId: ''
      });
    }, 2000);
  };

  handleCancel = () => {
    this.setState({
      visible: false,
    });
  };

 
  componentDidMount(){
    
    roleListRequest()
    .then(res => {
      this.setState({
        dataSource: res.body
      })
    })
  }
    render() {
      
      const columns = [
            {
              title: '角色名称',
              dataIndex: 'role_name',
              key:'name'
            }, {
              title: '描述',
              dataIndex: 'remark',
              key: 'description'
            }, {
              title: '操作',
              dataIndex: 'operation',
              key: 'operation',
              render: (text, record) => {
                return(
                    <Button onClick={() =>{
                    this.showModal(record.id)
                    }}  type='primary'>
                      设置权限
                    </Button>
                )
              }
            }
      ]
      const { visible, confirmLoading, ModalText } = this.state;
        return (
            <Card title="角色管理"
                // headStyle={{  padding: '0 10%' }}
                style={{ width: '90%', margin: 'auto', marginTop: '30px' }}
                hoverable={true}
                bordered={false}
            >
            <Table
              dataSource={this.state.dataSource}
              columns={columns}
              rowKey='id'
              bordered
              size="middle"
              pagination = {{
                pageSize: 20
              }}
            />
              <Modal
                title="设置权限"
                visible={visible}
                onOk={this.handleOk}
                confirmLoading={confirmLoading}
                onCancel={this.handleCancel}
              >
                {ModalText}
              </Modal>
            </Card>
        )
    }
}

export default index