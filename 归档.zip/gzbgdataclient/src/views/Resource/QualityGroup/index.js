import React, { Component } from 'react'
import { Layout, Icon, Switch, Card, Input, Descriptions, Radio, Tree, Select, Button } from 'antd'

const { Content, Sider } = Layout
const { Search } = Input
const { TreeNode } = Tree
const { Option } = Select

// 下拉选项切换
function handleChange(value) {
    console.log(`selected ${value}`)
}

export default class QualityGroup extends Component {
    
    constructor() {
        super()
        this.state = {
            // “单选” “多选” 状态，设置初始值为 false
            checked: false
        }
    }

    // 点击 “单选” “多选” 开关改变颜色和状态
    onChange = (checked) => {
        this.setState({
            // checked 状态取反
            checked: !this.state.checked
        })
    }

    // 左侧树形控件选择知识点
    onSelect = (selectedKeys, info) => {
        console.log('selected', selectedKeys, info)
    }

    render() {
        return (
            <Layout>
                <Layout>
                <Sider width={350} style={{ background: "#f3faff" }}>
                    <div style={{
                        width: "255px",
                        height: "105px",
                        marginLeft: "75px",
                        marginRight: "20px",
                        borderBottom: "2px solid #cce3f5",
                        position: "relative"
                    }}>
                    <p style={{
                        position: "absolute",
                        top: "30%",
                        left: 0,
                        color: "#0195ff",
                        fontSize: "16px",
                        fontWeight: 700
                    }}>
                        <Icon type="unordered-list" style={{marginRight: "5px"}}/>
                        知识点目录
                    </p>
                        <div style={{position: "absolute", bottom: "10%", right: "10%",}}>
                            <span style={{marginRight: "5px", color: this.state.checked ? "#9ba9b2" : "#0195ff", fontSize: "14px"}}>单选</span>
                            <Switch onChange={this.onChange} checked={this.state.checked} />
                            <span style={{marginLeft: "5px", color: this.state.checked ? "#0195ff" : "#9ba9b2", fontSize: "14px"}}>多选</span>
                        </div>
                    </div>
                    <Card bordered={false} style={{ background: '#f3faff', paddingLeft: "12%"}}>
                    <Tree showLine  onSelect={this.onSelect}>
                        <TreeNode title="直线运动" key="0-0">
                        <TreeNode title="运动的基本概念" key="0-0-0">
                            <TreeNode title="质点"  key="0-0-0-0" />
                            <TreeNode title="参考系" key="0-0-0-1" />
                            <TreeNode title="时间" key="0-0-0-2" />
                        </TreeNode>
                        <TreeNode title="运动的基本概念" key="0-0-1">
                            <TreeNode title="质点" key="0-0-1-0" />
                            <TreeNode title="质点" key="0-0-1-1" />
                            <TreeNode title="质点" key="0-0-1-2" />
                        </TreeNode>
                        <TreeNode title="运动的基本概念" key="0-0-2">
                            <TreeNode title="参考系" key="0-0-2-0" />
                            <TreeNode title="参考系" key="0-0-2-1" />
                        </TreeNode>
                        </TreeNode>
                    </Tree>
                    <Tree showLine  onSelect={this.onSelect}>
                        <TreeNode title="直线运动" key="0-0">
                        <TreeNode title="运动的基本概念" key="0-0-0">
                            <TreeNode title="质点"  key="0-0-0-0" />
                            <TreeNode title="参考系" key="0-0-0-1" />
                            <TreeNode title="时间" key="0-0-0-2" />
                        </TreeNode>
                        <TreeNode title="运动的基本概念" key="0-0-1">
                            <TreeNode title="质点" key="0-0-1-0" />
                            <TreeNode title="质点" key="0-0-1-1" />
                            <TreeNode title="质点" key="0-0-1-2" />
                        </TreeNode>
                        <TreeNode title="运动的基本概念" key="0-0-2">
                            <TreeNode title="参考系" key="0-0-2-0" />
                            <TreeNode title="参考系" key="0-0-2-1" />
                        </TreeNode>
                        </TreeNode>
                    </Tree>
                    </Card>
                </Sider>
                <Layout style={{ paddingTop: '24px', backgroundColor: "#f3faff"}}>
                    <Content
                    style={{
                        background: '#fff',
                        margin: 0,
                        minHeight: 280,
                    }}
                    >
                    <Card style={{borderBottom: "2px solid #cce3f5", marginLeft: "20px", marginRight: "20px"}} bordered={false}>
                        <Search onSearch={value => console.log(value)} enterButton style={{ width: 300, float:"right"}} />
                    </Card>
                    <Card  bordered={false}>
                    <Descriptions column={1}>
                        <Descriptions.Item><span style={{fontWeight: 700, color: "#5f6064"}}>年级：</span>
                            <Radio.Group defaultValue="a" buttonStyle="solid" style={{marginLeft: "20px"}}>
                                <Radio.Button value="a" style={{marginRight: "50px"}}>全部</Radio.Button>
                                <Radio.Button value="b" style={{marginRight: "50px"}}>七年级</Radio.Button>
                                <Radio.Button value="c" style={{marginRight: "50px"}}>八年级</Radio.Button>
                                <Radio.Button value="d" style={{marginRight: "50px"}}>九年级</Radio.Button>
                            </Radio.Group>
                        </Descriptions.Item>
                        <Descriptions.Item><span style={{fontWeight: 700, color: "#5f6064"}}>题型：</span>
                            <Radio.Group defaultValue="a" buttonStyle="solid" style={{marginLeft: "20px"}}>
                                <Radio.Button value="a" style={{marginRight: "50px"}}>全部</Radio.Button>
                                <Radio.Button value="b" style={{marginRight: "50px"}}>选择题</Radio.Button>
                                <Radio.Button value="c" style={{marginRight: "50px"}}>判断题</Radio.Button>
                                <Radio.Button value="d" style={{marginRight: "50px"}}>技能操作题</Radio.Button>
                            </Radio.Group>
                        </Descriptions.Item>
                        <Descriptions.Item><span style={{fontWeight: 700, color: "#5f6064"}}>难度：</span>
                            <Radio.Group defaultValue="a" buttonStyle="solid" style={{marginLeft: "20px"}}>
                                <Radio.Button value="a" style={{marginRight: "50px"}}>全部</Radio.Button>
                                <Radio.Button value="b" style={{marginRight: "50px"}}>困难</Radio.Button>
                                <Radio.Button value="c" style={{marginRight: "50px"}}>较难</Radio.Button>
                                <Radio.Button value="d" style={{marginRight: "50px"}}>一般</Radio.Button>
                                <Radio.Button value="e" style={{marginRight: "50px"}}>较易</Radio.Button>
                                <Radio.Button value="f" style={{marginRight: "50px"}}>容易</Radio.Button>
                            </Radio.Group>
                        </Descriptions.Item>
                        <Descriptions.Item><span style={{fontWeight: 700, color: "#5f6064"}}>来源：</span>
                            <Radio.Group defaultValue="a" buttonStyle="solid" style={{marginLeft: "20px"}}>
                                <Radio.Button value="a" style={{marginRight: "50px"}}>全部</Radio.Button>
                                <Radio.Button value="b" style={{marginRight: "50px"}}>拓展题</Radio.Button>
                                <Radio.Button value="c" style={{marginRight: "50px"}}>我的收藏</Radio.Button>
                            </Radio.Group>
                        </Descriptions.Item>
                    </Descriptions>
                    </Card>
                    <Card bordered={false}>
                        <Select defaultValue="默认" style={{ width: 120 }} onChange={handleChange}>
                        </Select>
                        <Select defaultValue="组卷次数" style={{ width: 120 }} onChange={handleChange}>
                            <Option value="jack">Jack</Option>
                            <Option value="lucy">Lucy</Option>
                            <Option value="disabled" disabled>
                                Disabled
                            </Option>
                            <Option value="Yiminghe">yiminghe</Option>
                        </Select>
                        <Select defaultValue="作答次数" style={{ width: 120 }} onChange={handleChange}>
                            <Option value="jack">Jack</Option>
                            <Option value="lucy">Lucy</Option>
                            <Option value="disabled" disabled>
                                Disabled
                            </Option>
                            <Option value="Yiminghe">yiminghe</Option>
                        </Select>
                        <Select defaultValue="平均得分率" style={{ width: 120 }} onChange={handleChange}>
                            <Option value="jack">Jack</Option>
                            <Option value="lucy">Lucy</Option>
                            <Option value="disabled" disabled>
                                Disabled
                            </Option>
                            <Option value="Yiminghe">yiminghe</Option>
                        </Select>
                        <Select defaultValue="共204题" style={{ width: 120 }} onChange={handleChange}>
                        </Select>
                    </Card>
                    <Card style={{marginLeft: "25px", marginRight: "25px"}}>
                        <p>[题文]拉大驱蚊器翁群翁群二阿打算打发放鲁大师付扩扩扩扩扩阿达撒是佛偶给人家面膜沙漠都按时买的阿萨德去</p>
                        <div style={{backgroundColor: '#f3faff'}}>
                            <div style={{display: "flex", justifyContent: "space-around", alignItems: "center", height: "58px"}}>
                                <div>组卷<span style={{color: "#35bccf"}}>123</span>次</div>
                                <div>作答<span style={{color: "#35bccf"}}>123</span>次</div>
                                <div>平均得分率<span style={{color: "#35bccf"}}>90%</span></div>
                                <div >
                                    <Radio.Group>
                                        <Radio.Button value="analysis">解析</Radio.Button>
                                        <Radio.Button value="test">考情</Radio.Button>
                                        <Radio.Button value="error">纠错</Radio.Button>
                                    </Radio.Group>
                                </div>
                                <div>
                                    <Button type="primary">加入试卷</Button>
                                </div>
                            </div>
                        </div>
                    </Card>
                    <Card style={{margin: "25px"}}>
                        <p>[题文]拉大驱蚊器翁群翁群二阿打算打发放鲁大师付扩扩扩扩扩阿达撒是佛偶给人家面膜沙漠都按时买的阿萨德去</p>
                        <div style={{backgroundColor: '#f3faff'}}>
                            <div style={{display: "flex", justifyContent: "space-around", alignItems: "center", height: "58px"}}>
                                <div>组卷<span style={{color: "#35bccf"}}>123</span>次</div>
                                <div>作答<span style={{color: "#35bccf"}}>123</span>次</div>
                                <div>平均得分率<span style={{color: "#35bccf"}}>90%</span></div>
                                <div >
                                    <Radio.Group>
                                        <Radio.Button value="analysis">解析</Radio.Button>
                                        <Radio.Button value="test">考情</Radio.Button>
                                        <Radio.Button value="error">纠错</Radio.Button>
                                    </Radio.Group>
                                </div>
                                <div>
                                    <Button type="primary">加入试卷</Button>
                                </div>
                            </div>
                        </div>
                    </Card>
                    <Card style={{marginLeft: "25px", marginRight: "25px"}}>
                        <p>[题文]拉大驱蚊器翁群翁群二阿打算打发放鲁大师付扩扩扩扩扩阿达撒是佛偶给人家面膜沙漠都按时买的阿萨德去</p>
                        <div style={{backgroundColor: '#f3faff'}}>
                            <div style={{display: "flex", justifyContent: "space-around", alignItems: "center", height: "58px"}}>
                                <div>组卷<span style={{color: "#35bccf"}}>123</span>次</div>
                                <div>作答<span style={{color: "#35bccf"}}>123</span>次</div>
                                <div>平均得分率<span style={{color: "#35bccf"}}>90%</span></div>
                                <div >
                                    <Radio.Group>
                                        <Radio.Button value="analysis">解析</Radio.Button>
                                        <Radio.Button value="test">考情</Radio.Button>
                                        <Radio.Button value="error">纠错</Radio.Button>
                                    </Radio.Group>
                                </div>
                                <div>
                                    <Button type="primary">加入试卷</Button>
                                </div>
                            </div>
                        </div>
                    </Card>
                    </Content>
                </Layout>
                <Sider width={250} style={{ background: "#f3faff"}}>
                <Card style={{ width: 220, position: "fixed", top: "207px" }} title="试题框">
                <table style={{border: "null", textAlign: "center"}}>
                    <thead>
                        <tr>
                            <th>已选试题</th>
                            <th>题量</th>
                            <th>分数</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>选择题</td>
                            <td>1</td>
                            <td>1</td>
                        </tr>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td>合计</td>
                            <td>2</td>
                            <td>2</td>
                        </tr>
                    </tfoot>
                </table>
                    <Button type="primary">试卷预览</Button>
                    <Button type="danger">清空</Button>
                </Card>
                </Sider>
                </Layout>
            </Layout>
        )
    }
}
