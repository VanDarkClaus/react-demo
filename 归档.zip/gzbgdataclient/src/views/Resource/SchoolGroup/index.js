import React, { Component } from 'react'
import { testPaperList, analysisPaper } from '../../../requests'
import { downLoadDispatch} from '../../../actions/downLoad'
import { Layout, Card, Button, Select, DatePicker , Modal, List } from 'antd'
import './SchoolGroup.less'
import { connect } from 'react-redux'
import 'echarts/lib/chart/pie'
import ReactEcharts from 'echarts-for-react'

const { Content, Footer } = Layout
const { Option } = Select
const { RangePicker } = DatePicker



// 下拉菜单的选中项
function handleChange(value) {
    console.log(`selected ${value}`);
  }

// 选择日期
function onChangePage(date, dateString) {
  console.log(date, dateString);
}

// 将 state 中保存的通知状态数据映射为组件的属性
const mapStateToProps = (state) => {
    // 返回一个对象
    return {
      schoolgroup: state.schoolgroup
    }
}

// 跳转页面
function onChange(pageNumber) {
    console.log('Page: ', pageNumber);
}

@connect(
    mapStateToProps,
    { downLoadDispatch }
)
class SchoolGroup extends Component {

    constructor() {
        super()
        this.state = {
            textPaperList: [],
            visible: false,
            difficultyAnalysis: [],
            knowledgesAnalysis: [],
            paperAmountDistribution: [],
            data: []
        }
        
    }

    // 显示模态框
    // 分析试卷
    showModal = (se_id) => {
        // 显示模态框
        this.setState({
            visible: true,
        })
        analysisPaper(se_id)
            .then(resp => {
                console.log(resp.body)
                // 解构赋值
                const { difficultyAnalysis, knowledgesAnalysis, paperAmountDistribution } = resp.body
                this.setState({
                    difficultyAnalysis,
                    knowledgesAnalysis,
                    paperAmountDistribution,
                    data: difficultyAnalysis
                })
                console.log(this.state.difficultyAnalysis)
                console.log(this.state.data)
                // 更新 data 数据，改变属性名为 name、value
                this.setState({
                    data: this.state.data.map((item, index) => {
                        return {
                            value: item.number,
                            name: item.difficulty
                        }
                    })
                })
                console.log(this.state.data)
            })
    }

    // 模态框数据可视化展示
    getOption = () => {
        let option = {
        tooltip: {
            trigger: 'item',
            formatter: "{a} <br/>{b}: {c} ({d}%)"
        },
        legend: {
            orient: 'vertical',
            x: 'left',
            data:['容易', '较易', '一般', '较难', '困难']
        },
        series: [
            {
                name:'难度',
                type:'pie',
                radius: ['50%', '70%'],
                avoidLabelOverlap: false,
                label: {
                    normal: {
                        show: false,
                        position: 'center'
                    },
                    emphasis: {
                        show: true,
                        textStyle: {
                            fontSize: '20',
                            fontWeight: 'bold'
                        }
                    }
                },
                labelLine: {
                    normal: {
                        show: false
                    }
                },
                data: this.state.data
            }
        ]
    }
        return option
    }

    // 点击 “确认” 后隐藏模态框
    handleOk = e => {
        console.log(e);
        this.setState({
            visible: false,
        })
    }

    // 点击 “取消” 后隐藏模态框
    handleCancel = e => {
        console.log(e);
        this.setState({
            visible: false,
        })
    }

    // 获取试卷列表数据
    componentDidMount() {
        testPaperList()
            .then(resp => {
                console.log(resp)
                this.setState({
                    textPaperList: resp.body.contents
                })
                console.log(this.state.textPaperList)
            })
    }

    // 下载试卷
    downLoad = (se_id) => {
        console.log(se_id)
       this.props.downLoadDispatch(se_id)
    }



    render() {
        return (
            <Layout className="layout">
                <Content style={{ padding: '0 15%', backgroundColor: "#f3faff" }}>
                <div style={{ background: '#fff', margin: 24, minHeight: 280}}>
                    <div style={{textAlign: "center", paddingTop: 20}}>
                        <Select defaultValue="请选择" style={{ width: 80 }} onChange={handleChange}>
                            <Option value="请选择">请选择</Option>
                            <Option value="lucy">Lucy</Option>
                            <Option value="Yiminghe">yiminghe</Option>
                        </Select>
                        <Select defaultValue="请选择" style={{ width: 80 }} onChange={handleChange}>
                            <Option value="请选择">请选择</Option>
                            <Option value="lucy">Lucy</Option>
                            <Option value="Yiminghe">yiminghe</Option>
                        </Select>
                        <Select defaultValue="请选择" style={{ width: 80 }} onChange={handleChange}>
                            <Option value="请选择">请选择</Option>
                            <Option value="lucy">Lucy</Option>
                            <Option value="Yiminghe">yiminghe</Option>
                        </Select>
                        <Select defaultValue="请选择" style={{ width: 80 }} onChange={handleChange}>
                            <Option value="请选择">全部年级</Option>
                            <Option value="lucy">Lucy</Option>
                            <Option value="Yiminghe">yiminghe</Option>
                        </Select>
                        <Select defaultValue="请选择" style={{ width: 80 }} onChange={handleChange}>
                            <Option value="请选择">语文</Option>
                            <Option value="lucy">Lucy</Option>
                            <Option value="Yiminghe">yiminghe</Option>
                        </Select>
                        <RangePicker onChange={onChange} />
                    </div >
                    <Card bordered={false}>
                    <List
                        itemLayout="vertical"
                        size="large"
                        pagination={{
                        onChange: page => {
                            console.log(page);
                        },
                        pageSize: 5,
                        }}
                        dataSource={this.state.textPaperList}
                        renderItem={item => (
                        <List.Item
                            key={item.se_id}
                            extra={
                                <Button.Group >
                                <Button type="primary">
                                    收藏
                                </Button>
                                <Button type="primary" onClick={
                                    () => {
                                        this.showModal(item.se_id)
                                    }
                                }>
                                    试卷分析
                                </Button >
                                <Modal
                                    title="试卷分析"
                                    visible={this.state.visible}
                                    onOk={this.handleOk}
                                    onCancel={this.handleCancel}
                                    >
                                    <div>
                                        <div style={{width: "50%", float: "left"}}>
                                            <p>总体分布分析</p>
                                            <table style={{border: "1", cellpadding: "0", cellspacing: "0", width:"100%", textAlign: "center"}}>
                                                <thead>
                                                    <tr style={{border:"1px solid #ccc"}}>
                                                        <th style={{border:"1px solid #ccc"}}>题型</th>
                                                        <th style={{border:"1px solid #ccc"}}>题量</th>
                                                        <th style={{border:"1px solid #ccc"}}>分值</th>
                                                        <th style={{border:"1px solid #ccc"}}>分值占比</th>
                                                    </tr>
                                                </thead>
                                            <tbody>
                                                {
                                                    this.state.paperAmountDistribution.map((prod) => {
                                                        return (
                                                            <tr style={{border:"1px solid #ccc"}} key={prod.name}>
                                                                <td style={{border:"1px solid #ccc"}}>{prod.name}</td>
                                                                <td style={{border:"1px solid #ccc"}}>{prod.number}</td>
                                                                <td style={{border:"1px solid #ccc"}}>{prod.score}</td>
                                                                <td style={{border:"1px solid #ccc"}}>{prod.scorePercentage}</td>
                                                            </tr>
                                                        )
                                                    })
                                                }
                                            </tbody>
                                            </table>
                                        </div>
                                        <div style={{width: "50%", float: "right"}}>
                                            <Card>
                                                <ReactEcharts option={this.getOption()} style={{height:'150px'}}/>
                                            </Card>
                                        </div>
                                    </div>
                                    <div>
                                        <p>知识点分析</p>
                                            <table style={{border: "1", cellpadding: "0", cellspacing: "0", width:"100%", textAlign: "center"}}>
                                                <thead>
                                                    <tr style={{border:"1px solid #ccc"}}>
                                                        <th style={{border:"1px solid #ccc"}}>序号</th>
                                                        <th style={{border:"1px solid #ccc"}}>知识点</th>
                                                        <th style={{border:"1px solid #ccc"}}>分值</th>
                                                        <th style={{border:"1px solid #ccc"}}>分值占比</th>
                                                        <th style={{border:"1px solid #ccc"}}>对应题号</th>
                                                    </tr>
                                                </thead>
                                            <tbody>
                                                {
                                                    this.state.knowledgesAnalysis.map((prod, index) => {
                                                        return (
                                                            <tr style={{border:"1px solid #ccc"}} key={prod.name}>
                                                                <td style={{border:"1px solid #ccc"}}>{index+1}</td>
                                                                <td style={{border:"1px solid #ccc"}}>{prod.name}</td>
                                                                <td style={{border:"1px solid #ccc"}}>{prod.score}</td>
                                                                <td style={{border:"1px solid #ccc"}}>{prod.scorePercentage}</td>
                                                                <td style={{border:"1px solid #ccc"}}>{prod.topicSerialNumber}</td>
                                                            </tr>
                                                        )
                                                    })
                                                }
                                            </tbody>
                                        </table>
                                    </div>
                                </Modal>
                                <Button type="primary">
                                    选题组卷
                                </Button>
                                <Button type="primary" onClick={
                                    () => {
                                        this.downLoad(item.se_id)
                                    }
                                }>
                                    下载试卷
                                </Button>
                                </Button.Group>
                                }
                        >
                            <List.Item.Meta
                            title={<a href={item.href}>{item.se_name}</a>}
                            
                            />
                             <div style={{display: "flex", justifyContent: "space-bwtten"}}>
                                <span>考试时间：</span>
                                <span>{
                                    new Date(parseInt(item.created_at) * 1000).toLocaleString().replace(/:\$/)
                                }</span>
                                <span style={{marginLeft: "4%"}}>年级：</span><span>{item.grade_name}</span>
                                <span style={{marginLeft: "4%"}}>科目：</span><span>{item.course_name}</span>
                                <span style={{marginLeft: "4%"}}>浏览：</span><span>121</span>
                            </div>
                        </List.Item>
                        )}
                    />
                    </Card>
                    {/* <Card  className="pagination" bordered={false} title={this.state.textPaperList.map((item) => {
                        return (
                        <Card style={{margin: "20px 20px"}} title={item.se_name} key={item.se_id}>
                            <div style={{display: "flex", justifyContent: "space-bwtten"}}>
                                <span>考试时间：</span>
                                <span>{
                                    new Date(parseInt(item.created_at) * 1000).toLocaleString().replace(/:\$/)
                                }</span>
                                <span style={{marginLeft: "4%"}}>年级：</span><span>{item.grade_name}</span>
                                <span style={{marginLeft: "4%"}}>科目：</span><span>{item.course_name}</span>
                                <span style={{marginLeft: "4%"}}>浏览：</span><span>121</span>
                            </div>
                            <Button.Group style={{marginLeft: "10%", float: "right"}}>
                            <Button type="primary">
                                收藏
                            </Button>
                            <Button type="primary" onClick={
                                () => {
                                    this.showModal(item.se_id)
                                }
                            }>
                                试卷分析
                            </Button >
                            <Modal
                                title="试卷分析"
                                visible={this.state.visible}
                                onOk={this.handleOk}
                                onCancel={this.handleCancel}
                                >
                                <div>
                                    <div style={{width: "50%", float: "left"}}>
                                        <p>总体分布分析</p>
                                        <table style={{border: "1", cellpadding: "0", cellspacing: "0", width:"100%", textAlign: "center"}}>
                                            <thead>
                                                <tr style={{border:"1px solid #ccc"}}>
                                                    <th style={{border:"1px solid #ccc"}}>题型</th>
                                                    <th style={{border:"1px solid #ccc"}}>题量</th>
                                                    <th style={{border:"1px solid #ccc"}}>分值</th>
                                                    <th style={{border:"1px solid #ccc"}}>分值占比</th>
                                                </tr>
                                            </thead>
                                        <tbody>
                                            {
                                                this.state.paperAmountDistribution.map((prod) => {
                                                    return (
                                                        <tr style={{border:"1px solid #ccc"}} key={prod.name}>
                                                            <td style={{border:"1px solid #ccc"}}>{prod.name}</td>
                                                            <td style={{border:"1px solid #ccc"}}>{prod.number}</td>
                                                            <td style={{border:"1px solid #ccc"}}>{prod.score}</td>
                                                            <td style={{border:"1px solid #ccc"}}>{prod.scorePercentage}</td>
                                                        </tr>
                                                    )
                                                })
                                            }
                                        </tbody>
                                        </table>
                                    </div>
                                    <div style={{width: "50%", float: "right"}}>
                                        <Card>
                                            <ReactEcharts option={this.getOption()} style={{height:'150px'}}/>
                                        </Card>
                                    </div>
                                </div>
                                <div>
                                    <p>知识点分析</p>
                                        <table style={{border: "1", cellpadding: "0", cellspacing: "0", width:"100%", textAlign: "center"}}>
                                            <thead>
                                                <tr style={{border:"1px solid #ccc"}}>
                                                    <th style={{border:"1px solid #ccc"}}>序号</th>
                                                    <th style={{border:"1px solid #ccc"}}>知识点</th>
                                                    <th style={{border:"1px solid #ccc"}}>分值</th>
                                                    <th style={{border:"1px solid #ccc"}}>分值占比</th>
                                                    <th style={{border:"1px solid #ccc"}}>对应题号</th>
                                                </tr>
                                            </thead>
                                        <tbody>
                                            {
                                                this.state.knowledgesAnalysis.map((prod, index) => {
                                                    return (
                                                        <tr style={{border:"1px solid #ccc"}} key={prod.name}>
                                                            <td style={{border:"1px solid #ccc"}}>{index+1}</td>
                                                            <td style={{border:"1px solid #ccc"}}>{prod.name}</td>
                                                            <td style={{border:"1px solid #ccc"}}>{prod.score}</td>
                                                            <td style={{border:"1px solid #ccc"}}>{prod.scorePercentage}</td>
                                                            <td style={{border:"1px solid #ccc"}}>{prod.topicSerialNumber}</td>
                                                        </tr>
                                                    )
                                                })
                                            }
                                        </tbody>
                                    </table>
                                </div>
                            </Modal>
                            <Button type="primary">
                                选题组卷
                            </Button>
                            <Button type="primary" onClick={
                                () => {
                                    this.downLoad(item.se_id)
                                }
                            }>
                                下载试卷
                            </Button>
                        </Button.Group>
                        </Card>
                        )
                    })} >
                        <Pagination
                            showQuickJumper
                            defaultCurrent={1}
                            total={this.state.textPaperList.length}
                            onChange={onChangePage}
                            pageSize={10}
                        />
                    </Card> */}
                </div>
                </Content>
                <Footer style={{ textAlign: 'center', backgroundColor: "#f3faff" }}></Footer>
            </Layout>
        )
    }
}

export default SchoolGroup