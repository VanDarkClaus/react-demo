import React, { Component } from 'react'
import { testPaperList } from '../../../requests'
import { Layout, Card, Input, Button } from 'antd'

const { Content, Footer } = Layout
const { Search } = Input

export default class MyGroup extends Component {

    constructor() {
        super()
        this.state = {
            textPaperList: [],
            visible: false 
        }
    }

    // 获取试卷列表数据
    componentDidMount() {
        testPaperList()
            .then(resp => {
                console.log(resp)
                this.setState({
                    textPaperList: resp.body.contents
                })
                console.log(this.state.textPaperList)
            })
    }

    // 下载试卷
    downLoadTextPaper = () => {

    }

    render() {
        return (
            <Layout className="layout">
                <Content style={{ padding: '0 15%', backgroundColor: "#f3faff" }}>
                <div style={{ background: '#fff', margin: 24, minHeight: 280}}>
                <Card style={{ marginLeft: "20px", marginRight: "20px"}} bordered={false}>
                    <Search onSearch={value => console.log(value)} enterButton style={{ width: 300, float:"right"}} placeholder="支持题干搜索" />
                </Card>
                    <Card bordered={false} title={this.state.textPaperList.map((item) => {
                        return (
                        <Card style={{margin: "20px 20px"}} title={item.se_name} key={item.se_id}>
                            <span>手工组卷</span><span style={{marginLeft: 50}}>2018/2/2</span>
                            <Button.Group style={{marginLeft: 400}}>
                            <Button type="primary">
                                复制试卷
                            </Button>
                            <Button type="primary" onClick={this.showModal}>
                                修改试卷
                            </Button >
                            <Button type="primary">
                                下载试卷
                            </Button>
                            <Button type="primary" onClick={this.downLoadTextPaper}>
                                下载答题卡
                            </Button>
                        </Button.Group>
                        </Card>
                        )
                    })} >
                    </Card>
                </div>
                </Content>
                <Footer style={{ textAlign: 'center', backgroundColor: "#f3faff" }}></Footer>
            </Layout>
        )
    }
}
