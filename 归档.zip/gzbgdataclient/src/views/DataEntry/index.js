import React, { Component } from 'react'
import { dataEntryRoutes } from '../../routes'
import {Switch, Redirect, Route} from 'react-router-dom'
import SonFrame from '../../components/SonFrame'

export default class index extends Component {
    render() {
        return (
            <SonFrame>
                <Switch>
                    {
                        dataEntryRoutes.map(item =>{
                            return <Route
                                    path = {item.path}
                                    key = {item.path}
                                    component = {item.component}
                                    exact = {item.exact}
                                    />
                        })
                    }
                    <Redirect from = '/admin/dataentry' to = '/admin/dataentry/examinationprocess' exact/>
                    <Redirect to = '/404'/>
                </Switch>
            </SonFrame>
        )
    }
}
