import React, { Component } from 'react'
import {Form, Select, Modal} from 'antd'
import dictionary from 'utils/dictionary.json'
import { cityAreasRequest, schoolsRequest } from 'requests'

@Form.create()
class createModal extends Component {
    constructor(){
        super()
        this.state = {
            areaData: [],
            areaDataChildren: [],
            cityData: [],
            visible: true,
            confirmLoading: false,  
            modaltitle: ''
        }
    }
    componentDidMount() {
      this.setState({
        modaltitle: this.props.modaltitle,
        visible: this.props.visible
      })
    }
    handleOk = () => {
      this.setState({
        confirmLoading: true,
      });
      setTimeout(() => {
        this.setState({
          confirmLoading: false,
        });
        this.props.handleCancel()
      }, 2000);
    };
  
    handleCancel = () => {
      //点击取消，通过调用父组件的方法删除模态框
      this.props.handleCancel()
    };
    handleSubmit = e => {
        e.preventDefault();
        this.props.form.validateFieldsAndScroll((err, values) => {
          if (!err) {
            console.log('Received values of form: ', values);
          }
        });
      };
    render() {
        const {visible, confirmLoading, modaltitle, areaDataChildren} = this.state
        const {Option} = Select
        const { getFieldDecorator } = this.props.form;
        const formItemLayout = {
            labelCol: {
              xs: { span: 24 },
              sm: { span: 4 },
            },
            wrapperCol: {
              xs: { span: 24 },
              sm: { span: 16 },
            },
          };
        return (
          <Modal
                 title={modaltitle}
                 visible={visible}
                 onOk={this.handleOk}
                 confirmLoading={confirmLoading}
                 onCancel={this.handleCancel}
                >
            {/* <Form {...formItemLayout} onSubmit={this.handleSubmit}>
                 <Form.Item label="省" >
                  {getFieldDecorator('province', {
                    rules: [
                      {
                        required: true,
                        message: '请选择省份',
                      }
                    ],
                  })(<Select
                    showSearch
                    style={{ width: 150 }}
                    // placeholder="请选择省份"
                    optionFilterProp="children"
                    onChange={province_id => {
                      cityAreasRequest(province_id)
                      .then(res => {
                       const cityData = res.body.map(item => {
                          item = {
                            city_id: item.area_id,
                            name: item.name
                          }
                          return item
                        }) 
                        const areaData = {}
                        res.body.map(item => {
                            areaData[item.area_id]= item.nodes
                          return item
                        })
                        this.setState({ province_id, cityData, areaData })
                        //清空市和区
                        this.props.form.setFieldsValue({
                          'city': '',
                          'area': '',
                          "school": ''
                        })
                      })
                    }}
                  >
                    {dictionary.provinceDict.map(item => {
                      return <Option key={item.area_id} value={item.area_id}>{item.name}</Option>
                    })}
                  </Select>)}
                </Form.Item>

                <Form.Item label="市" >
                  {getFieldDecorator('city', {
                    rules: [
                      {
                        required: true,
                        message: '请选择市',
                      }
                    ],
                  })(<Select
                    showSearch
                    allowClear={true}
                    style={{ width: 150 }}
                    // placeholder="请选择市"
                    optionFilterProp="children"
                    onChange={city_id => {
                      this.setState({
                        areaDataChildren: this.state.areaData[city_id]
                      })
                       //通过市id获取到学校
                       schoolsRequest(city_id)
                       .then(res => {
                         this.setState({
                           schoolList: res.body
                         })
                       })
                      //清空区
                      this.props.form.setFieldsValue({
                        'area': '',
                        "school": ''
                      })
                    }}
                  >
                    {this.state.cityData.map(item => {
                      return <Option key={item.city_id} value={item.city_id}>{item.name}</Option>
                    })}
                  </Select>)}
                </Form.Item>
  
                <Form.Item label="区/县" >
                  {getFieldDecorator('area', {
                    rules: [
                    ],
                  })(<Select
                    showSearch
                    style={{ width: 150 }}
                    // placeholder="请选择区/县"
                    optionFilterProp="children"
                    onChange={area_id => {
                      this.setState({ area_id })
                      //通过区县id获取到学校
                      schoolsRequest(area_id)
                      .then(res => {
                        this.setState({
                          schoolList: res.body
                        })
                      })
                    }}
                  >
                    {
                      areaDataChildren.map(item => {
                      return <Option key={item.area_id} value={item.area_id}>{item.name}</Option>
                    })
                    }
                  </Select>)}
                </Form.Item>

                <Form.Item label="学校" >
                {getFieldDecorator('school', {
                    rules: [
                    ],
                  })(<Select
                    showSearch
                    style={{ width: 150 }}
                    optionFilterProp="children"
                    onChange={schoolId => {
                      this.setState({
                        schoolId
                      })
                    }}
                  >
                    {this.state.schoolList.map(item => {
                      return <Option key={item.school_id} value={item.school_id}>{item.name}</Option>
                    })}
                  </Select>)}
                </Form.Item>
            </Form> */}

            </Modal>
        )
    }
}

export default createModal