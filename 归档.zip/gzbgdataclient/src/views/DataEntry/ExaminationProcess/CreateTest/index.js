import React, { Component } from 'react'
import { TestHeader } from '../../../../components'
import { Button, Input, Icon, message, Modal, Form, Select, DatePicker, Card, Col, Row, Badge } from 'antd'
import { examListRequest, schoolsRequest, cityAreasRequest, examCreateRequest, examUpdateRequest, examDeleteRequest } from 'requests'
import dictionary from 'utils/dictionary.json'
import moment from 'moment'

import './examination.less'

@Form.create()
class index extends Component {
  constructor() {
    super()
    this.state = {
      seeVisible: false,
      seeList: {
        me_name: '考试名称',
        province_name: '',
        city_name: '',
        area_name: '',
        school: '',
        me_grade: '',
        me_enter_year: '',
        me_term_code: "",
        course_type: '',
        exam_number_length: '',
        me_gather_time: '',
        exam_singles: [{
          se_full_score: 0
        }],
      },
      deleteVisible: false,

      subjectVisible: false,
      subjectList: [],
      modaltitle: '新增考试期号',
      method: '',
      delete_id: '',
      me_id: '',
      area_id: '',
      visible: false,
      confirmLoading: false,
      checkedMeId: '',
      cityData: [],
      areaData: [],
      areaDataChildren: [],
      schoolList: [],

      page: 1,
      examList: [
        {
          province_id: '',
          area_id: "440306",
          area_name: "宝安区",
          city_id: "440300",
          city_name: "深圳市",
          cloud_read_me_id: "0",
          collection_time_end: "1559150585",
          collection_time_start: "1558286585",
          course_type: "0",
          exam_number_length: "12",
          exam_singles: [{
            course_name: "语文",
            se_course_id: "201",
            se_full_score: "100.00"
          }],
          exam_type: "21",
          me_date: "1556092502",
          me_enter_year: "0",
          me_full_score: "100.00",
          me_gather_time: "0",
          me_grade: "高三",
          me_grade_id: "303",
          me_id: "",
          me_name: "深圳市宝安区高三测试学校0424",
          me_term_code: "1",
          name_suffix: null,
          school: "-",
          school_id: "0",
          united_me_id: "0"
        }
      ]
    }
  }
  //获取到市数据所有区
  cityGetRequest = async (province_id) => {
    //清空市和区
    this.props.form.setFieldsValue({
      'cityAdd': '',
      'areaAdd': '',
      'schoolAdd': ''
    })
    this.setState({
      cityData: [],
      areaData: [],
      schoolList: []
    })
    await cityAreasRequest(province_id)
      .then(res => {
        const cityData = res.body.map(item => {
          item = {
            city_id: item.area_id,
            name: item.name
          }
          return item
        })
        const areaData = {}
        res.body.map(item => {
          areaData[item.area_id] = item.nodes
          return item
        })
        this.setState({ cityData, areaData }, () => {
          this.validateAndName()
        })
      })
  }
  //获取到区数据
  areaGetRequest = (city_id) => {
    //清空区
    this.setState({
      areaDataChildren: [],
      schoolList: []
    })
    this.props.form.setFieldsValue({
      'areaAdd': '',
      'schoolAdd': ''
    })
    this.setState({
      areaDataChildren: this.state.areaData[city_id]
    }, () => {
      this.validateAndName()
    })
    //通过市id获取到学校
    if (this.state.area_id === '') {
      schoolsRequest(city_id)
        .then(res => {
          this.setState({
            schoolList: res.body,
          })
        })
    }
  }
  handleOk = () => {
    this.setState({
      subjectVisible: true
    })
  };
  //删除提交
  deletehandle = () => {
    examDeleteRequest(this.state.delete_id)
      .then(res => {
        message.info(res.message)
        if (res.code === 200) {
          examListRequest(9, 1)
            .then(resp => {
              this.setState({ examList: resp.body.content, deleteVisible: false })
            })
        }
      })
  }
  //最后提交
  sumhandle = () => {
    const subj = this.state.subjectList.map(item => {
      item = item.props.value
      return item
    })
    this.props.form.validateFields([
      'dateColleageAdd',
      'areaAdd',
      'cityAdd',
      'courseAdd',
      'enterYearAdd',
      'gradeAdd',
      'provinceAdd',
      'schoolAdd',
      'semesterAdd',
      'subjectTypeAdd',
      'testDateAdd',
      'testNameAdd',
      'testNumberAdd',
      'testSumAdd',
      'testTypeAdd',
      ...subj
    ],
      (errors, values) => {
        const courseAdd = subj.map(item => {
          item = {
            [`${item}`]: values[item]
          }
          return item
        })
        if (!errors) {
          console.log(this.state.me_id)
          const { schoolAdd = '', gradeAdd = '', testDateAdd = '', testSumAdd = '', semesterAdd = '', enterYearAdd = '', subjectTypeAdd = '', areaAdd = '', cityAdd = '', testNameAdd = '', testTypeAdd = '', testNumberAdd = '', dateColleageAdd = '' } = values
          this.state.method(schoolAdd, gradeAdd, testDateAdd.format('X'), testSumAdd, enterYearAdd, semesterAdd, courseAdd, subjectTypeAdd, areaAdd, cityAdd, testNameAdd, testTypeAdd, testNumberAdd, dateColleageAdd[0].format('X'), dateColleageAdd[1].format('X'), this.state.me_id)
            .then(res => {
              message.info(res.message)
              if (res.code === 200) {
                examListRequest(9, 1)
                  .then(resp => {
                    this.setState({ examList: resp.body.content, subjectVisible: false, visible: false })
                  })
              }
            })
        }
      })
  }

  handleCancel = () => {
    this.setState({
      visible: false,
    });
  };

  componentDidMount() {
    examListRequest(9, this.state.page)
      .then(res => {
        this.setState({ examList: res.body.content, page: this.state.page + 1 })
      })
  }
  //查看点击
  seeHandle = () => {
    this.setState({ seeVisible: true })
  }
  //验证并自动生成名字
  validateAndName = () => {
    const { cityData, areaDataChildren, schoolList } = this.state
    const { provinceDict, grade, semester } = dictionary
    let { provinceAdd = '', cityAdd = '', areaAdd = '', schoolAdd = '', gradeAdd = '', semesterAdd = '', testNameAdd = '' } =
      this.props.form.getFieldsValue(['provinceAdd', 'cityAdd', 'areaAdd', 'schoolAdd', 'gradeAdd', 'semesterAdd', 'testNameAdd'])
    //拿到省
    provinceDict.map(item => {
      if (item.area_id === provinceAdd) provinceAdd = item.name
      return item
    })
    //拿到市
    cityData.map(item => {
      if (item.city_id === cityAdd) cityAdd = item.name
      return item
    })
    //拿到县
    areaDataChildren.map(item => {
      if (item.area_id === areaAdd) areaAdd = item.name
      return item
    })
    //拿到学校
    schoolList.map(item => {
      if (item.school_id === schoolAdd) schoolAdd = item.name
      return item
    })
    //拿到年级
    grade.map(item => {
      if (item.id === gradeAdd && item.id !== '') gradeAdd = item.name
      return item
    })
    //拿到学期
    semester.map(item => {
      if (item.id === semesterAdd) semesterAdd = item.name
      return item
    })
    let value = provinceAdd + cityAdd + areaAdd + schoolAdd + gradeAdd + semesterAdd + testNameAdd
    this.props.form.setFieldsValue({ 'testSumAdd': value })
  }
  //展示增加和查看的模态框
  showModal = e => {
    switch (e.target.getAttribute('datatype')) {
      case 'create': this.setState({ modaltitle: '新增考试期号', method: examCreateRequest })
        //设置初始值
        // this.props.form.setFieldsValue({
        // 'dateColleageAdd': [],
        // 'areaAdd': '',
        // 'cityAdd': '',
        // 'courseAdd': '',
        // 'enterYearAdd': '',
        // 'gradeAdd': '',
        // 'provinceAdd': '',
        // 'schoolAdd': '',
        // 'semesterAdd': '',
        // 'subjectTypeAdd': '',
        // 'testDateAdd': '',
        // 'testNameAdd': '',
        // 'testSumAdd': '',
        // 'testTypeAdd': '',
        // 'testNumberAdd': ''
        // })
        ; break;
      case 'edit':
        this.setState({ modaltitle: '编辑考试期号', method: examUpdateRequest })
        console.log(JSON.parse(e.target.getAttribute('dataitem')))
        let { exam_singles, exam_number_length, area_id, city_id, school_id, me_grade_id, me_enter_year, province_id, collection_time_start, collection_time_end, me_term_code, course_type, me_date, name_suffix, me_name, exam_type, me_id } = JSON.parse(e.target.getAttribute('dataitem'))
        //集成请求数据和赋予初始值 
        const asyncFn = async () => {
          await this.cityGetRequest(province_id)
          await this.setState({ area_id, me_id })
          await this.areaGetRequest(city_id)
          await this.setState({ area_id, schoolList: [] })
          await schoolsRequest(area_id)
            .then(res => {
              this.setState({
                area_id,
                schoolList: res.body
              }, () => { this.validateAndName() })
            })
          let subjectList = exam_singles.map(item => {
            return item = {
              props: {
                value: item.se_course_id,
                children: item.course_name
              }
            }
          })
          await this.setState({ subjectList })
          let subj = {}
          exam_singles = exam_singles.map(item => {
            subj[`${item.se_course_id}`] = item.se_full_score
            item = item.se_course_id
            return item
          })
          //设置初始值
          this.props.form.setFieldsValue({
            'dateColleageAdd': [
              moment(collection_time_start * 1000),
              moment(collection_time_end * 1000)
            ],
            'areaAdd': area_id,
            'cityAdd': city_id,
            'courseAdd': exam_singles,
            'enterYearAdd': me_enter_year,
            'gradeAdd': me_grade_id,
            'provinceAdd': province_id,
            'schoolAdd': school_id,
            'semesterAdd': me_term_code,
            'subjectTypeAdd': course_type,
            'testDateAdd': moment(me_date * 1000),
            'testNameAdd': name_suffix,
            'testSumAdd': me_name,
            'testTypeAdd': exam_type,
            'testNumberAdd': exam_number_length,
            ...subj
          })
        }
        asyncFn(); break;
      default: this.setState({ modaltitle: '新增考试期号' });
    }
    this.setState(
      { visible: true }
    )
  }

  render() {
    const { RangePicker } = DatePicker;
    const { Search } = Input
    const { examList, modaltitle, visible, confirmLoading, areaDataChildren, subjectList, deleteVisible, seeVisible, } = this.state
    let { me_name, province_name, city_name, area_name, school, me_grade, me_enter_year, me_term_code, course_type, exam_number_length, exam_singles, me_gather_time } = this.state.seeList
    me_term_code = me_term_code === '1' ? '上学期' : '下学期'
    course_type = course_type === 0 ? '未分科' : course_type === '1' ? '理科' : '文科'
    let couseText = ''
    exam_singles.map(item => {
      couseText = couseText + ' ' + item.course_name
    })
    exam_singles = exam_singles.reduce((sum, curr) => { return sum += parseInt(curr.se_full_score) }, 0)
    me_gather_time = moment(me_gather_time * 1000).format('YYYY年MM月DD日')
    const { Option } = Select
    const { getFieldDecorator } = this.props.form;

    const formItemLayout = {
      labelCol: {
        xs: { span: 22 },
        sm: { span: 6 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 16 },
      },
    };
    return (
      <>
        <TestHeader img='/images/one.png'>
        </TestHeader>
        <div className='muxue-exam' style={{ position: 'relative' }}>
          <div className='muxue-exam-top'>
            <Button onClick={this.showModal} type="primary" datatype='create' ghost>创建考试期号</Button>
            <Search
              placeholder="请输入考试名称"
              onSearch={value => console.log(value)}
              style={{ width: 290, fontSize: '24px' }}
              enterButton
            />
          </div>
          <div className='muxue-exam-center' style={{ flexWrap: 'wrap' }}>
            {
              examList.map(item => {
                return (
                  <div onClick={() => {
                    console.log(item)
                    this.setState({ checkedMeId: item.me_id })
                  }} key={item.me_id} dataexam={item} className='muxue-exam-center_card' style={{ border: '5px solid #cae4f5', width: '25%', margin: '30px 3%', borderColor: this.state.checkedMeId === item.me_id ? '#0195ff' : '#cae4f5' }}>
                    <div>{item.me_name}</div>
                    <div>
                      <Button onClick={() => {
                        console.log(item)
                        this.setState({ seeVisible: true, seeList: item })
                      }} datatype='lookup' type="primary" ghost style={{ width: '65px', border: '1px solid #0096ff', color: '#0096ff', padding: '0', margin: '0 5px' }}>查看详情</Button>
                      <Button onClick={this.showModal} datatype='edit' dataitem={JSON.stringify(item)} type="primary" ghost style={{ width: '65px', border: '1px solid #0096ff', color: '#0096ff', padding: '0', margin: '0 5px' }}>重新编辑</Button>
                      <Button
                        type="primary"
                        onClick={() => { this.setState({ deleteVisible: true, delete_id: item.me_id }) }}
                        ghost
                        style={{ width: '65px', border: '1px solid #0096ff', color: '#0096ff', padding: '0', margin: '0 5px' }}>
                        <Icon type="delete" />
                      </Button>
                    </div>
                  </div>
                )
              })
            }

          </div>
          <img onClick={() => {
            //请求数据并合并数据
            examListRequest(9, this.state.page)
              .then(res => {
                this.setState({ examList: [...this.state.examList, ...res.body.content], page: this.state.page + 1 })
              })
          }
          } style={{ marginLeft: '50%', transform: 'translate(-50%)', marginTop: '30px', display: 'flex' }} src='/images/downicon.png' alt='downicon' />
          <Button onClick={() => {
            //如果已选中则下一步才能跳转
            if (this.state.checkedMeId !== '') {
              this.props.history.push(`/admin/dataentry/examinationprocess/datacollection?me_id=${this.state.checkedMeId}`)
            } else {
              message.info('请选择一个考试')
            }
          }} style={{ width: '105px', height: '40px', position: 'absolute', right: '6%' }} type='primary'>下一步</Button>
          {
            //创建考试模态框
            <Modal
              title={modaltitle}
              visible={visible}
              onOk={this.handleOk}
              confirmLoading={confirmLoading}
              onCancel={this.handleCancel}
            >
              <Form {...formItemLayout}>
                <Form.Item label="省" >
                  {getFieldDecorator('provinceAdd', {
                    rules: [
                      {
                        required: true,
                        message: '请选择省份',
                      }
                    ],
                  })(<Select
                    showSearch
                    style={{ width: 250 }}
                    optionFilterProp="children"
                    onChange={province_id => {
                      this.cityGetRequest(province_id)
                    }}
                  >
                    {dictionary.provinceDict.map(item => {
                      return <Option key={item.area_id} value={item.area_id}>{item.name}</Option>
                    })}
                  </Select>)}
                </Form.Item>
                <Form.Item label="市" >
                  {getFieldDecorator('cityAdd', {
                    rules: [
                      {
                        required: true,
                        message: '请选择市',
                      }
                    ],
                  })(<Select
                    showSearch
                    allowClear={true}
                    style={{ width: 250 }}
                    optionFilterProp="children"
                    onChange={city_id => {
                      this.areaGetRequest(city_id)
                    }}
                  >
                    {this.state.cityData.map(item => {
                      return <Option key={item.city_id} value={item.city_id}>{item.name}</Option>
                    })}
                  </Select>)}
                </Form.Item>
                <Form.Item label="区/县" >
                  {getFieldDecorator('areaAdd', {
                    rules: [
                    ],
                  })(<Select
                    showSearch
                    style={{ width: 250 }}
                    // placeholder="请选择区/县"
                    optionFilterProp="children"
                    onChange={area_id => {
                      this.props.form.setFieldsValue({
                        'schoolAdd': ''
                      })
                      this.setState({ area_id, schoolList: [] })
                      //通过区县id获取到学校
                      schoolsRequest(area_id)
                        .then(res => {
                          this.setState({
                            area_id,
                            schoolList: res.body
                          }, () => { this.validateAndName() })
                        })
                    }}
                  >
                    {
                      areaDataChildren.map(item => {
                        return <Option key={item.area_id} value={item.area_id}>{item.name}</Option>
                      })
                    }
                  </Select>)}
                </Form.Item>
                <Form.Item label="学校" >
                  {getFieldDecorator('schoolAdd', {
                    rules: [
                      {
                        required: true,
                        message: '请选择学校',
                      }
                    ],
                  })(<Select
                    showSearch
                    style={{ width: 250 }}
                    optionFilterProp="children"
                    onChange={schoolId => {
                      this.setState({
                        schoolId
                      }, () => { this.validateAndName() })
                    }}
                  >
                    {this.state.schoolList.map(item => {
                      return <Option key={item.school_id} value={item.school_id}>{item.name}</Option>
                    })}
                  </Select>)}
                </Form.Item>
                <Form.Item label="年级" >
                  {getFieldDecorator('gradeAdd', {
                    rules: [
                      {
                        required: true,
                        message: '请输入年级'
                      }
                    ],
                  })(<Select
                    showSearch
                    style={{ width: 250 }}
                    optionFilterProp="children"
                    onChange={grade => {
                      this.setState({}, () => {
                        this.validateAndName()
                      })
                    }}
                  >
                    {dictionary.grade.map(item => {
                      return <Option key={item.id} value={item.id}>{item.name}</Option>
                    })}
                  </Select>)}
                </Form.Item>
                <Form.Item label="学期" >
                  {getFieldDecorator('semesterAdd', {
                    rules: [
                      {
                        required: true,
                        message: '请输入学期'
                      }
                    ],
                  })(<Select
                    showSearch
                    style={{ width: 250 }}
                    optionFilterProp="children"
                    onChange={grade => {
                      this.setState({}, () => { this.validateAndName() })
                    }}
                  >
                    {dictionary.semester.map(item => {
                      return <Option key={item.id} value={item.id}>{item.name}</Option>
                    })}
                  </Select>)}
                </Form.Item>
                <Form.Item label="考试名附加" >
                  {getFieldDecorator('testNameAdd', {
                  })(<Input onChange={() => {
                    this.setState({}, () => { this.validateAndName() })
                  }} style={{ width: '250px' }} />)}
                </Form.Item>
                <Form.Item label="考试名称" >
                  {getFieldDecorator('testSumAdd', {
                  })(<textarea disabled={true} style={{ width: '250px', borderRadiusBase: '4px', borderColor: '#d9d9d9' }} />)}
                </Form.Item>
                <Form.Item label="考试类型" >
                  {getFieldDecorator('testTypeAdd', {
                    rules: [
                      {
                        required: true,
                        message: '请输入考试类型'
                      }
                    ],
                  })(<Select
                    showSearch
                    style={{ width: 250 }}
                    optionFilterProp="children"
                    onChange={grade => {
                    }}
                  >
                    {dictionary.testType.map(item => {
                      return <Option key={item.id} value={item.id}>{item.name}</Option>
                    })}
                  </Select>)}
                </Form.Item>
                <Form.Item label="科目类型" >
                  {getFieldDecorator('subjectTypeAdd', {
                    rules: [
                      {
                        required: true,
                        message: '请输入科目类型'
                      }
                    ],
                  })(<Select
                    showSearch
                    style={{ width: 250 }}
                    optionFilterProp="children"
                    onChange={grade => {
                    }}
                  >
                    {dictionary.subjectType.map(item => {
                      return <Option key={item.id} value={item.id}>{item.name}</Option>
                    })}
                  </Select>)}
                </Form.Item>
                <Form.Item label="科目" >
                  {getFieldDecorator('courseAdd', {
                    rules: [
                    ],
                  })(<Select
                    mode="multiple"
                    showSearch
                    style={{ width: 250 }}
                    optionFilterProp="children"
                    onChange={(grade, option) => {
                      option = option.map(item => {
                        item = {
                          props: item.props
                        }
                        return item
                      })
                      this.setState({ subjectList: option })
                    }}
                  >
                    {dictionary.course.map(item => {
                      return <Option key={item.id} value={item.id}>{item.name}</Option>
                    })}
                  </Select>)}
                </Form.Item>
                <Form.Item label="考号长度" >
                  {getFieldDecorator('testNumberAdd', {
                    rules: [
                      {
                        message: '考号1-25位',
                        pattern: /(^1[0-9]$)|(^[1-9]|[^2[0-5]$])$/
                      }
                    ]
                  })(<Input style={{ width: '250px' }} />)}
                </Form.Item>
                <Form.Item label="入学年份" >
                  {getFieldDecorator('enterYearAdd', {
                    rules: [{
                      message: '请输入4位数字',
                      pattern: /^[0-9]{4}$/
                    }]
                  })(<Input style={{ width: '250px' }} />)}
                </Form.Item>
                <Form.Item label="考试时间" >
                  {getFieldDecorator('testDateAdd', {
                    rules: [{
                      required: true,
                      message: '请输入考试时间'
                    }]
                  })(<DatePicker style={{ width: '250px' }} showTime />)}
                </Form.Item>
                <Form.Item label="数据采集时间" >
                  {getFieldDecorator('dateColleageAdd', {
                    rules: [{
                      required: true,
                      message: '请输入数据采集时间'
                    }]
                  })(
                    <RangePicker
                      style={{ width: '250px' }}
                      showTime={{ format: 'HH:mm' }}
                      format="YYYY-MM-DD HH:mm"
                      placeholder={['开始时间', '结束时间']}
                    />
                  )}
                </Form.Item>
              </Form>

            </Modal>
          }
          {/* 选中科目后弹出的模态框 */}
          <Modal
            title='科目分数'
            visible={this.state.subjectVisible}
            onOk={this.sumhandle}
            onCancel={() => { this.setState({ subjectVisible: false }) }}
          >
            <Form {...formItemLayout}>
              {subjectList.map(item => {
                return (
                  <Form.Item label={item.props.children} key={item.props.value} >
                    {getFieldDecorator(item.props.value, {
                      rules: [{
                        message: '请输入',
                        required: true
                      }]
                    })(<Input style={{ width: '250px' }} />)}
                  </Form.Item>
                )
              })}
            </Form>
          </Modal>

          {/* 删除模态框 */}
          <Modal
            title='删除考试'
            visible={deleteVisible}
            onOk={this.deletehandle}
            onCancel={() => { this.setState({ deleteVisible: false }) }}
          >
            确定删除吗？
            </Modal>
          {/* 查看详情模态框 */}
          <Modal
            className='create-see'
            keyboard
            width={815}
            closable={false}
            visible={seeVisible}
            // visible = {true}
            onOk={() => { this.setState({ seeVisible: false }) }}
            onCancel={() => { this.setState({ seeVisible: false }) }}
          >
            <Card
              title={me_name}
              headStyle={{ textAlign: 'center' }}
              bordered={false}
              style={{ fontSize: "16px" }}
            >
              <Row gutter={16} style={{ borderBottom: '1px dashed #dedede', marginBottom: '5px' }}>
                <Col span={24}>
                  <div status="processing" style={{ fontSize: '20px' }} >
                    <Badge status="processing" />
                    <span>考试名称</span>
                  </div>
                  <div>
                    {me_name}
                  </div>
                </Col>
              </Row>
              <Row gutter={16} style={{ borderBottom: '1px dashed #dedede', marginBottom: '5px' }}>
                <Col span={8}>
                  <div status="processing" style={{ fontSize: '20px' }} >
                    <Badge status="processing" />
                    <span>省/市/区县</span>
                  </div>
                  {province_name + ' ' + city_name + ' ' + area_name}
                </Col>
                <Col span={8}>
                  <div status="processing" style={{ fontSize: '20px' }} >
                    <Badge status="processing" />
                    <span>学校/年级</span>
                  </div>
                  {school + ' ' + me_grade}
                </Col>
                <Col span={8}>
                  <div status="processing" style={{ fontSize: '20px' }} >
                    <Badge status="processing" />
                    <span>入学年份/学期</span>
                  </div>
                  {me_enter_year + '' + me_term_code}
                </Col>
              </Row>
              <Row gutter={16} style={{ borderBottom: '1px dashed #dedede', marginBottom: '5px' }}>
                <Col span={8}>
                  <div status="processing" style={{ fontSize: '20px' }} >
                    <Badge status="processing" />
                    <span>科目类型</span>
                  </div>
                  {course_type}
                </Col>
                <Col span={8}>
                  <div status="processing" style={{ fontSize: '20px' }} >
                    <Badge status="processing" />
                    <span>考号长度</span>
                  </div>
                  {exam_number_length}
                </Col>
                <Col span={8}>
                  <div status="processing" style={{ fontSize: '20px' }} >
                    <Badge status="processing" />
                    <span>总分</span>
                  </div>
                  {exam_singles}
                </Col>
              </Row>
              <Row gutter={16} style={{ borderBottom: '1px dashed #dedede', marginBottom: '5px' }}>
                <Col span={16}>
                  <div status="processing" style={{ fontSize: '20px' }} >
                    <Badge status="processing" />
                    <span>科目</span>
                  </div>
                  {couseText}
                </Col>
                <Col span={8}>
                  <div status="processing" style={{ fontSize: '20px' }} >
                    <Badge status="processing" />
                    <span>考试时间</span>
                  </div>
                  {me_gather_time}
                </Col>
              </Row>
            </Card>
          </Modal>
        </div>
      </>
    )
  }
}

export default index