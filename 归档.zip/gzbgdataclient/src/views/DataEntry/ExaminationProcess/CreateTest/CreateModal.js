import React, { Component } from 'react'
import {Form, Select, Modal, Cascader} from 'antd'
import dictionary from 'utils/dictionary.json'
import { cityAreasRequest, schoolsRequest } from 'requests'

@Form.create()
class createModal extends Component {
    constructor(){
        super()
        this.state = {
            areaData: [],
            areaDataChildren: [],
            cityData: [],
            visible: true,
            confirmLoading: false,  
            modaltitle: '',
            schoolList: []
        }
    }
    componentDidMount() {
      this.setState({
        modaltitle: this.props.modaltitle,
        visible: this.props.visible
      })
    }
    handleOk = e => {
      this.setState({
        confirmLoading: true,
      });
      e.preventDefault();
      this.props.form.validateFieldsAndScroll((err, values) => {
        if (!err) {
          console.log('Received values of form: ', values);
        }
      });
    };
  
    handleCancel = () => {
      //点击取消，通过调用父组件的方法删除模态框
      this.props.handleCancel()
    };
    render() {
        const {visible, confirmLoading, modaltitle, areaDataChildren} = this.state
        const {Option} = Select
        const { getFieldDecorator } = this.props.form;
        const formItemLayout = {
            // labelCol: {
            //   xs: { span: 24 },
            //   sm: { span: 4 },
            // },
            // wrapperCol: {
            //   xs: { span: 24 },
            //   sm: { span: 16 },
            // },
          };
        return (
          <Modal
                 title={modaltitle}
                 visible={visible}
                 onOk={this.handleOk}
                 confirmLoading={confirmLoading}
                 onCancel={this.handleCancel}
                >
            <Form {...formItemLayout}>
              <Form.Item>
                {getFieldDecorator('province',{rules: [
                      {
                        required: true,
                        message: '请选择省份',
                      }
                    ]
                  })(
                    <Cascader
                    style={{color: 'blue', zIndex: '55555'}}
                    defaultValue={['zhejiang', 'hangzhou', 'xihu']}
                    options={options}
                    onChange={()=>{}}
                  />
                )}
              </Form.Item>
            </Form>

            </Modal>
        )
    }
}

export default createModal