import React, { Component } from 'react'
import {TestHeader} from 'components'
import {Radio, DatePicker, Button, message} from 'antd'
import moment from 'moment'

class index extends Component {
    state = { mode: 'time', dateString:'',date:'', value:'1' };

    handleOpenChange = (open) => {
      if (open) {
        this.setState({ mode: 'time' });
      }
    };
  
    handlePanelChange = (value, mode) => {
      this.setState({ mode});
    };
    render() {
        return (
            <>
                <TestHeader img='/images/three.png'/>
                <div style = {{ margin: 'auto', width: '75.5%', background: '#fff', height: '660px'}}>
                    <img src='/images/publishreportsThree.png' alt='发布报告' style={{display: 'block', margin: 'auto', paddingTop: '44px',marginBottom: '44px'}}/>
                    <div style={{width: '84%', margin: 'auto', borderTop:'1px dashed #dedede'}}>
                        <div style={{width:'100%', display:'flex',justifyContent:'flex-end',margin: '20px', }}>
                            <Radio.Group name="radiogroup" defaultValue={1}>
                                <Radio style={{fontSize: '20px'}} value={1} onChange={value=>{this.setState({value: value.target.value})}}>立即发布</Radio>
                                <Radio style={{fontSize: '20px'}} value={2} onChange={value=>{this.setState({value: value.target.value})}}>定时发布</Radio>
                            </Radio.Group>
                            <span style={{width: '300px', fontSize: '20px'}}>{this.state.dateString}</span>
                        </div>
                        <div style={{width:'100%', display:'flex',justifyContent:'flex-end'}}>
                
                                        <DatePicker
                                            style={{marginRight:'200px'}}
                                            mode={this.state.mode}
                                            showTime
                                            onOpenChange={this.handleOpenChange}
                                            onPanelChange={this.handlePanelChange}
                                            onChange={(date, dateString)=>{
                                                this.setState({date: date.format('X'), dateString: '('+ dateString + ')'})
                                            }}
                                        />
                        </div>
                        <div style={{width: '100%',textAlign:'center', marginTop:'150px'}}>
                            <Button style={{width: '140px',height:'60px'}} type='primary' size='large' onClick={()=>{
                                const date = this.state.value===1?'': this.state.date
                                console.log(date)
                                //这里还需要一个发布报告的借口
                            }}>发布报告</Button>
                        </div>
                    </div>
                </div>
            </>
        )
    }
}

export default index
