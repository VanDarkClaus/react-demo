import React, { Component } from 'react'
import {TestHeader} from '../../../../components'
import { getSchoolList, getStudentsList, exportSchoolList, downSchoolList, checkStudents, checkFileList, deleteFileList, examListRequest, creatDetail, searchStudent } from 'requests'
import { Layout, Tabs, Table, Button, Modal, Upload, message, Icon, Input, Card, Radio, Message, Row, Col, Form } from 'antd'
import { relative } from 'path';

const { Content } = Layout
const { TabPane } = Tabs
const { Search } = Input

function callback(key) {
    console.log(key)
}

@Form.create()
class DataCollection extends Component {

    constructor() {
        super()
        this.state = {
            h_se_id: '',
            //渲染学科的列表
            h_subjectList: [],
            //上传文件内容
            h_fileList: [
                {
                  uid: '-1',
                  name: 'xxx.png',
                  status: 'done',
                  url: 'http://www.baidu.com/xxx.png',
                },
              ],
        
            hVisible: false,
            //编辑框
            h_edit_visible: false,
            h_student: {
                q_list: []
            },

            visible: false,
            visible2: false,
            visible3: false,
            body: [],
            student_list: [],
            list: [],
            exam_at: [],
            file_name: '',
            page: 1,
            c_subjectList: [],
            display_yuwen: 'none',
            display_shuxue: 'none',
            display_yingyu: 'none',
            display_huaxue: 'none',
            display_wuli: 'none',
            display_shengwu: 'none',
            display_zhengzhi: 'none',
            display_dili: 'none',
            // course_images: [
            //     {
            //         name: yuwen,
                    
            //     }
            // ]
        }
    }
    //点击确定
    h_handleOk = () => {
        
    }
    //编辑确定
    h_edit_handleOk = () => {

    }

    // 上传学生列表
    uploadData = {
        name: 'file',
        // 上传地址
        action: 'http://192.168.1.60:8084/v2/upload/put-student-by-excel' || 'http://www.mymuxue.com/v2/upload/put-student-by-excel',
        // 请求头部
        headers: {
            Authorization: (JSON.parse(sessionStorage.getItem('token'))).access_token,
        },
        data: {
            me_id: window.location.search.slice(7)
        },
        onChange(info) {
            if (info.file.status !== 'uploading') {
                console.log(info.file, info.fileList);
            }
            if (info.file.status === 'done') {
                message.success(`${info.file.name} 上传成功`);
                
            } else if (info.file.status === 'error') {
                message.error(`${info.file.name} 上传失败`);
            }
        },
    }

        // 上传试卷
    uploadText = {
        name: 'file',
        // 上传地址
        action: 'http://192.168.1.60:8084/v2/exam-paper/upload-doc' || 'http://www.mymuxue.com/v2/exam-paper/upload-doc',
        // 请求头部
        headers: {
            Authorization: (JSON.parse(sessionStorage.getItem('token'))).access_token,
        },
        data: {
            me_id: window.location.search.slice(7)
        },
        onChange(info) {
            if (info.file.status !== 'uploading') {
                console.log(info.file, info.fileList);
            }
            if (info.file.status === 'done') {
                message.success(`${info.file.name} 上传成功`);
                
            } else if (info.file.status === 'error') {
                message.error(`${info.file.name} 上传失败`);
            }
        },
        showUploadList: false,
    }

    // 学校列表
    columns1 = [
        {
            title: '学校',
            dataIndex: 'school_name',
        },
        {
            title: '导入数量',
            dataIndex: 'all_num',
        },
        {
            title: '检查通过数量',
            dataIndex: 'examming_num',
        },
    ]

    // 检查文件列表
    columns2 = [
        {
            title: '序号',
            render: (text, record, index) => {
                console.log(text, record, index)
                return this.dataIndex = index+1
            }
        },
        {
            title: '检查时间',
            render: (text, record, index) => {
                return this.dataIndex = new Date(parseInt(record.exam_at) * 1000).toLocaleString().replace(/:\$/)
            }
        },
        {
            title: '源文件名',
            dataIndex: 'file_name',
        },
        {
            title: '状态',
            render: (text, record, index) => {
                return this.dataIndex = record.state
            }
        },
        {
            title: '操作',
            dataIndex: 'chaozuo',
            render:(text, record, index) => {
                return (
                    <Button.Group style={{display: "flex"}}>
                        {
                            (() => {
                                console.log(record.state)
                                if(record.state === '未录入'){
                                    return (
                                        <Upload {...this.uploadData} >
                                        <Button>导入</Button>
                                        </Upload>
                                    )
                                }
                            })()
                        }
                        <Button onClick={this.exportSchoolListHandler}>导出</Button>
                        <Button type="danger" onClick={
                            () => {
                                this.setState({
                                    list: this.state.list.filter(item => item.id !== record.id)
                                })
                                deleteFileList(record.id)
                                    .then(resp =>{
                                        console.log(resp)
                                        if(resp.code === 200) {
                                            alert('删除成功')
                                        }
                                    })
                            }
                        }>删除</Button>
                    </Button.Group>
                )
            }
        }
    ]
    // 学生列表
    columns3 = [
        {
            title: '学籍号',
            dataIndex: 'student_id',
        },
        {
            title: '考号',
            dataIndex: 'student_id',
        },
        {
            title: '姓名',
            dataIndex: 'student_name',
        },
        {
            title: '学校',
            dataIndex: 'school_name',
        },
        {
            title: '年级',
            dataIndex: 'grade_name',
        },
        {
            title: '班级',
            dataIndex: 'class_name',
        },
    ]

    // 显示学生信息模态框
    showModal = (school_id, me_id) => {
        console.log(school_id, me_id)
        this.setState({
            visible: true,
        })
        // 获取学生信息列表
        getStudentsList(school_id, me_id, this.page)
            .then(resp => {
                console.log(resp)
                console.log(resp.body.content)
                this.setState({
                    student_list: resp.body.content
                })
            })
    }
    
    handleOk = e => {
        console.log(e);
        this.setState({
            visible: false,
        })
    }
    
    handleCancel = e => {
        console.log(e);
        this.setState({
            visible: false,
        })
    }

     // 显示检查文件列表模态框
     showModal2= () => {
        this.setState({
            visible2: true,
        })
        const me_id = window.location.search.slice(7)
        console.log(me_id)
        checkFileList(me_id)
            .then(resp => {
                console.log(resp.body.content)
                this.setState({
                    list: resp.body.content
                })
                console.log(this.state.list.map(item => item.state))
                this.setState({
                    state: this.state.list.map(item => {
                        console.log(item.state)
                        if(item.state == 0) {
                            return item.state = '未检测'
                        }
                        if(item.state == 1) {
                            return item.state = '未录入'
                        }
                        if(item.state == 2) {
                            return item.state = '录入完毕'
                        }
                        if(item.state == 3) {
                            return item.state = '出错'
                        }
                    })
                })
                
                console.log(this.state.list)
               
            })
    }
    
    handleOk2 = e => {
        console.log(e);
        this.setState({
            visible2: false,
        })
    }
    
    handleCancel2 = e => {
        console.log(e);
        this.setState({
            visible2: false,
        })
    }

    // 获取数据
    componentDidMount() {
        this.getSchoolId()

        creatDetail(window.location.search.slice(7))
            .then(resp => {
                console.log(resp)
                resp.body.map(item => {
                    switch(item.course_name) {
                        case '地理': item.img = '/images/subjectIcon/地理.png';break;
                        case '化学': item.img = '/images/subjectIcon/化学.png';break;
                        case '理综': item.img = '/images/subjectIcon/理综.png';break;
                        case '历史': item.img = '/images/subjectIcon/历史.png';break;
                        case '生物': item.img = '/images/subjectIcon/生物.png';break;
                        case '数学': item.img = '/images/subjectIcon/数学.png';break;
                        case '文科': item.img = '/images/subjectIcon/文科.png';break;
                        case '物理': item.img = '/images/subjectIcon/物理.png';break;
                        case '英语': item.img = '/images/subjectIcon/英语.png';break;
                        case '语文': item.img = '/images/subjectIcon/语文.png';break;
                        default: item.img = '/images/subjectIcon/政治.png'
                    }
                    return item
                })
                this.setState({
                    c_subjectList: resp.body
                })
            })
    }

    // 根据考号搜索学生
    searchStudent(value) {
        const newList = []
        this.state.student_list.forEach(item => {
            if(item.student_id.indexOf(value) !== -1) {
                newList.push(item)
                this.setState({
                    student_list: newList
                })
            }
        })
    }

    // 获取学校列表id信息
    getSchoolId() {
        // 传入me_id
        getSchoolList(this.props.location.search.slice(7))
            .then(resp => {
                console.log(resp)
                // const { school_name, school_id, all_num, examming_num } = resp.body
                this.setState({
                    body: resp.body
                })
            })
    }

    // 导出学校列表
    exportSchoolListHandler() {
        const me_id = window.location.search.slice(7)
        console.log(me_id)
        exportSchoolList(me_id)
            .then(resp => {
                if(resp.code === 200) {
                    message.success('导出完成')
                }
                console.log(resp)
            })
    }

    // 学生列表模板下载
    downSchoolListHandler() {
        downSchoolList()
            .then(resp => {
                console.log(resp)
                alert('下载学生模板')
            })
    }

    // 学生信息导入--检查校验
    checkStudentsHandler() {
        const me_id = window.location.search.slice(7)
        checkStudents(me_id)
            .then(resp => {
                console.log(resp)
                if(resp.code === 200) {
                    message.success('校验完成')
                }
            })
    }

    // 显示语文试卷录入的按钮
    display_yuwen = () => {
        //编辑按钮的单击事件，修改状态机display_name的取值
        if (this.state.display_yuwen == 'none') {
            this.setState({
                display_yuwen: 'block',
                display_shuxue: 'none',
                display_yingyu: 'none',
                display_wuli: 'none',
                display_huaxue: 'none',
                display_shengwu: 'none',
                display_zhengzhi: 'none',
                display_dili: 'none',

            })
        }
        else if (this.state.display_yuwen == 'block') {
            this.setState({
                display_yuwen: 'none',
            })
        }
    }
    // 显示数学试卷录入的按钮
    display_shuxue = () => {
        //编辑按钮的单击事件，修改状态机display_name的取值
        if (this.state.display_shuxue == 'none') {
            this.setState({
                display_shuxue: 'block',
                display_yuwen: 'none',
                display_yingyu: 'none',
                display_wuli: 'none',
                display_huaxue: 'none',
                display_shengwu: 'none',
                display_zhengzhi: 'none',
                display_dili: 'none',
            })
        }
        else if (this.state.display_shuxue == 'block') {
            this.setState({
                display_shuxue: 'none',
            })
        }
    }
    // 显示英语试卷录入的按钮
    display_yingyu = () => {
        //编辑按钮的单击事件，修改状态机display_name的取值
        if (this.state.display_yingyu == 'none') {
            this.setState({
                display_yingyu: 'block',
                display_shuxue: 'none',
                display_yuwen: 'none',
                display_wuli: 'none',
                display_huaxue: 'none',
                display_shengwu: 'none',
                display_zhengzhi: 'none',
                display_dili: 'none',
            })
        }
        else if (this.state.display_yingyu == 'block') {
            this.setState({
                display_yingyu: 'none',
            })
        }
    }
    // 显示物理试卷录入的按钮
    display_wuli = () => {
        //编辑按钮的单击事件，修改状态机display_name的取值
        if (this.state.display_wuli == 'none') {
            this.setState({
                display_wuli: 'block',
                display_yingyu: 'none',
                display_shuxue: 'none',
                display_yuwen: 'none',
                display_huaxue: 'none',
                display_shengwu: 'none',
                display_zhengzhi: 'none',
                display_dili: 'none',
            })
        }
        else if (this.state.display_wuli == 'block') {
            this.setState({
                display_wuli: 'none',
            })
        }
    }
    // 显示化学试卷录入的按钮
    display_huaxue = () => {
        //编辑按钮的单击事件，修改状态机display_name的取值
        if (this.state.display_huaxue == 'none') {
            this.setState({
                display_huaxue: 'block',
                display_yingyu: 'none',
                display_shuxue: 'none',
                display_yuwen: 'none',
                display_shengwu: 'none',
                display_zhengzhi: 'none',
                display_dili: 'none',
                display_wuli: 'none',
            })
        }
        else if (this.state.display_huaxue == 'block') {
            this.setState({
                display_huaxue: 'none',
            })
        }
    }
    // 显示生物试卷录入的按钮
    display_shengwu = () => {
        //编辑按钮的单击事件，修改状态机display_name的取值
        if (this.state.display_shengwu == 'none') {
            this.setState({
                display_shengwu: 'block',
                display_yingyu: 'none',
                display_shuxue: 'none',
                display_yuwen: 'none',
                display_huaxue: 'none',
                display_zhengzhi: 'none',
                display_dili: 'none',
                display_wuli: 'none',
            })
        }
        else if (this.state.display_shengwu == 'block') {
            this.setState({
                display_shengwu: 'none',
            })
        }
    }
    // 显示政治试卷录入的按钮
    display_zhengzhi = () => {
        //编辑按钮的单击事件，修改状态机display_name的取值
        if (this.state.display_zhengzhi == 'none') {
            this.setState({
                display_zhengzhi: 'block',
                display_yingyu: 'none',
                display_shuxue: 'none',
                display_yuwen: 'none',
                display_huaxue: 'none',
                display_shengwu: 'none',
                display_dili: 'none',
                display_wuli: 'none',
            })
        }
        else if (this.state.display_zhengzhi == 'block') {
            this.setState({
                display_zhengzhi: 'none',
            })
        }
    }
    // 显示地理试卷录入的按钮
    display_dili = () => {
        //编辑按钮的单击事件，修改状态机display_name的取值
        if (this.state.display_dili == 'none') {
            this.setState({
                display_dili: 'block',
                display_yingyu: 'none',
                display_shuxue: 'none',
                display_yuwen: 'none',
                display_huaxue: 'none',
                display_shengwu: 'none',
                display_zhengzhi: 'none',
                display_wuli: 'none',
            })
        }
        else if (this.state.display_dili == 'block') {
            this.setState({
                display_dili: 'none',
            })
        }
    }

    render() {
            //成绩录入上传文件配置
        const h_upload = {
            name: 'file',
            action: 'http://192.168.1.60:8084/v2/upload/put-score-by-excel' || 'http://www.mymuxue.com/v2/upload/put-score-by-excel',
            // 请求头部
            headers: {
                Authorization: (JSON.parse(sessionStorage.getItem('token'))).access_token,
            },
            data: {
                se_id: this.state.h_se_id
            },
            onChange(info) {
                console.log(info)
                if (info.file.status !== 'uploading') {
                    console.log(info.file, info.fileList);
                }
                if (info.file.status === 'done') {
                    message.success(`${info.file.name} 上传成功`);
                    
                } else if (info.file.status === 'error') {
                    message.error(`${info.file.name} 上传失败`);
                }
            },
            multiple: true,
        }
        const { getFieldDecorator } = this.props.form;
        return (
            <Layout className="layout" style={{ backgroundColor: "#f3faff" }}>
                <TestHeader img='/images/two.png'>
                </TestHeader>
                <Content style={{ padding: '24px 10%' }}>
                    <div style={{ background: '#fff', margin: 24, minHeight: 280 }}>
                        <div >
                        <Tabs onChange={callback} type="card" >
                            <TabPane tab="考生信息录入" key="1" >
                            <Table
                                rowKey="school_id"
                                columns={this.columns1}
                                dataSource={this.state.body}
                                bordered
                                pagination={false}
                                footer={
                                    () => {
                                        return (
                                            <div style={{display: "flex", justifyContent: "space-around" }}>
                                                <Button type="primary" style={{ width: 100}} onClick={this.showModal2}>导入</Button>
                                                <Button type="primary" style={{ width: 100}} onClick={this.exportSchoolListHandler}>导出</Button>
                                                <Button type="primary" style={{ width: 100}} onClick={this.downSchoolListHandler}>模板下载</Button>
                                                <Button type="primary" style={{ width: 100}} onClick={this.checkStudentsHandler}>检查效验</Button>
                                            </div>
                                        )
                                    }
                                }
                                style={{width: 600, margin: '0 auto'}}
                                onRow={(record) => {
                                    return {
                                    // 点击行跳出模态框
                                    onClick: (event) => {
                                        event.preventDefault()
                                        const me_id = this.props.location.search.slice(7)
                                        if(record.school_id !== 0) {
                                            this.showModal(record.school_id, me_id)
                                        }
                                        console.log(record)
                                        console.log(me_id)
                                    }
                                    }
                                }}
                                
                            />
                            {/* 导入学生列表模态框 */}
                            <div>
                                <Modal
                                title="导入学生基础信息"
                                visible={this.state.visible2}
                                onOk={this.handleOk2}
                                onCancel={this.handleCancel2}
                                width={1000}
                                >
                                <Upload {...this.uploadData} >
                                <Button type="primary">浏览</Button>
                                </Upload>
                                <Table
                                        rowKey="school_id"
                                        columns={this.columns2}
                                        dataSource={this.state.list}
                                        bordered
                                        pagination={false}
                                        style={{width: 900, margin: '0 auto', marginTop: 20}}
                                    />
                                </Modal>
                            </div>
                            {/* 点击学生列表模态框 */}
                            <div>
                                <Modal
                                title="学生信息录入"
                                visible={this.state.visible}
                                onOk={this.handleOk}
                                onCancel={this.handleCancel}
                                width={1000}
                                >
                                    <div>
                                        <Search
                                        placeholder="输入考号"
                                        onSearch={this.searchStudent}
                                        enterButton
                                        style={{width: 300}}
                                    />
                                    </div>
                                    <Table
                                        rowKey="school_id"
                                        columns={this.columns3 }
                                        dataSource={this.state.student_list}
                                        bordered
                                        pagination={true}
                                        footer={
                                            () => {
                                                return (
                                                    <>
                                                        <Button type="primary" style={{ marginRight: "2%", width: 100}} onClick={this.showModal2}>导入</Button>
                                                        <Button type="primary" style={{ marginRight: "2%", width: 100}} onClick={this.exportSchoolListHandler}>导出</Button>
                                                        <Button type="primary" style={{ marginRight: "2%", width: 100}} onClick={this.downSchoolListHandler}>模板下载</Button>
                                                        <Button type="primary" style={{ marginRight: "2%", width: 100}} onClick={this.checkStudentsHandler}>检查效验</Button>
                                                    </>
                                                )
                                            }
                                        }
                                        style={{width: 800, margin: '0 auto', marginTop: 20}}
                                    />
                                </Modal>
                            </div>
                            </TabPane>
                            <TabPane tab="试卷录入" key="2">
                                <div className="gutter-example">
                                    <Row gutter={16}>
                                        <div>
                                        {
                                            this.state.c_subjectList.map(item => {
                                                return(
                                                    <Col className="gutter-row" span={6} key={item.se_id}>
                                                        <Card title={item.course_name} style={{textAlign: "center", height: 470}} bordered={false}>
                                                            <img src="../../../../../images/地理.png" alt="" onClick={this.display_yuwen} style={{border: "2px solid #ccc", borderRadius: "10px"}}  />
                                                            <div style={{display: this.state.display_yuwen}}>
                                                                <div style={{display: "flex",  flexWrap: "wrap", justifyContent: "space-around"}}>
                                                                    <div>
                                                                    <Upload {...this.uploadText} >
                                                                        <Button type="primary" style={{margin: '10px 10px'}}>
                                                                            导入试卷
                                                                        </Button>
                                                                    </Upload>
                                                                    </div>
                                                                    <div>
                                                                    <Button type="primary" style={{margin: '10px 10px'}}>划题标注</Button>
                                                                    </div>
                                                                    <div>
                                                                    <Button type="primary" style={{margin: '10px 10px'}}>查看试卷</Button>
                                                                    </div>
                                                                    <div>
                                                                    <Button type="primary" style={{margin: '10px 10px'}}>删除试卷</Button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </Card>
                                                    </Col>
                                                )
                                            })
                                        }
                                        </div>
                                    
                                    {/* <Col className="gutter-row" span={6}>
                                    <Card style={{textAlign: "center", height: 370}} bordered={false}>
                                        <img src="../../../../../images/shuxue.png" onClick={this.display_shuxue} style={{border: "2px solid #ccc", borderRadius: "10px"}} />
                                        <div style={{display: this.state.display_shuxue}}>
                                        <div style={{display: "flex",  flexWrap: "wrap", justifyContent: "space-around"}}>
                                            <div>
                                            <Upload {...this.uploadText} >
                                                <Button type="primary" style={{margin: '10px 10px'}}>
                                                    导入试卷
                                                </Button>
                                            </Upload>
                                            </div>
                                            <div>
                                            <Button type="primary" style={{margin: '10px 10px'}}>划题标注</Button>
                                            </div>
                                            <div>
                                            <Button type="primary" style={{margin: '10px 10px'}}>查看试卷</Button>
                                            </div>
                                            <div>
                                            <Button type="primary" style={{margin: '10px 10px'}}>删除试卷</Button>
                                            </div>
                                        </div>
                                        </div>
                                    </Card>
                                    </Col>
                                    <Col className="gutter-row" span={6}>
                                    <Card  style={{textAlign: "center", height: 370}} bordered={false}>
                                        <img src="../../../../../images/yingyu.png" onClick={this.display_yingyu} style={{border: "2px solid #ccc", borderRadius: "10px"}} />
                                        <div style={{display: this.state.display_yingyu}}>
                                        <div style={{display: "flex",  flexWrap: "wrap", justifyContent: "space-around"}}>
                                            <div>
                                            <Upload {...this.uploadText} >
                                                <Button type="primary" style={{margin: '10px 10px'}}>
                                                    导入试卷
                                                </Button>
                                            </Upload>
                                            </div>
                                            <div>
                                            <Button type="primary" style={{margin: '10px 10px'}}>划题标注</Button>
                                            </div>
                                            <div>
                                            <Button type="primary" style={{margin: '10px 10px'}}>查看试卷</Button>
                                            </div>
                                            <div>
                                            <Button type="primary" style={{margin: '10px 10px'}}>删除试卷</Button>
                                            </div>
                                        </div>
                                        </div>
                                    </Card>
                                    </Col>
                                    <Col className="gutter-row" span={6}>
                                    <Card  style={{textAlign: "center", height: 370}} bordered={false}>
                                        <img src="../../../../../images/wuli.png" onClick={this.display_wuli} style={{border: "2px solid #ccc", borderRadius: "10px"}} />
                                        <div style={{display: this.state.display_wuli}}>
                                        <div style={{display: "flex",  flexWrap: "wrap", justifyContent: "space-around"}}>
                                            <div>
                                            <Upload {...this.uploadText} >
                                                <Button type="primary" style={{margin: '10px 10px'}}>
                                                    导入试卷
                                                </Button>
                                            </Upload>
                                            </div>
                                            <div>
                                            <Button type="primary" style={{margin: '10px 10px'}}>划题标注</Button>
                                            </div>
                                            <div>
                                            <Button type="primary" style={{margin: '10px 10px'}}>查看试卷</Button>
                                            </div>
                                            <div>
                                            <Button type="primary" style={{margin: '10px 10px'}}>删除试卷</Button>
                                            </div>
                                        </div>
                                        </div>
                                    </Card>
                                    </Col> */}
                                    </Row>
                                </div>
                                {/* <div style={{ display: "flex", flexFlow: "row wrap", justifyContent: "space-around", textAlign: "center", margin: "2% 10%"}}>
                                    <div style={{position: "relative", width: "55%", height: 250}}>
                                        <img src="../../../../../images/yuwen.png" onClick={this.display_yuwen} style={{border: "2px solid #ccc", borderRadius: "10px"}}  />
                                        <div style={{ width: 400, position: "absolute", marginTop: 10, display: this.state.display_yuwen, left: "50%",marginLeft: 200}}>
                                            <div style={{display: "flex"}}>
                                            <Upload {...this.uploadText} >
                                                <Button type="primary" style={{marginLeft: 10}}>
                                                    导入试卷
                                                </Button>
                                            </Upload>
                                            <Button type="primary" style={{marginLeft: 10}}>划题标注</Button>
                                            <Button type="primary" style={{marginLeft: 10}}>查看试卷</Button>
                                            <Button type="primary" style={{marginLeft: 10}}>删除试卷</Button>
                                            </div>
                                        </div>
                                    </div>
                                     <div style={{ width: "25%", height: 250}}>
                                        <img src="../../../../../images/shuxue.png" onClick={this.display_shuxue} style={{border: "2px solid #ccc", borderRadius: "10px"}} />
                                        <div style={{display: this.state.display_shuxue, position: "absolute", left: "22%", marginTop: 10}}>
                                            <div style={{display: "flex"}}>
                                            <Upload {...this.uploadText} >
                                                <Button type="primary" style={{marginLeft: "3%"}}>
                                                    导入试卷
                                                </Button>
                                            </Upload>
                                            <Button type="primary" style={{marginLeft: "3%"}}>划题标注</Button>
                                            <Button type="primary" style={{marginLeft: "3%"}}>查看试卷</Button>
                                            <Button type="primary" style={{marginLeft: "3%"}}>删除试卷</Button>
                                            </div>
                                        </div>
                                    </div>
                                    <div style={{ width: "25%", height: 250}}>
                                        <img src="../../../../../images/yingyu.png" onClick={this.display_yingyu} style={{border: "2px solid #ccc", borderRadius: "10px"}} />
                                        <div style={{display: this.state.display_yingyu, position: "absolute", left: "42%", marginTop: 10}}>
                                            <div style={{display: "flex"}}>
                                            <Upload {...this.uploadText} >
                                                <Button type="primary" style={{marginLeft: "3%"}}>
                                                    导入试卷
                                                </Button>
                                            </Upload>
                                            <Button type="primary" style={{marginLeft: "3%"}}>划题标注</Button>
                                            <Button type="primary" style={{marginLeft: "3%"}}>查看试卷</Button>
                                            <Button type="primary" style={{marginLeft: "3%"}}>删除试卷</Button>
                                        </div>
                                        </div>
                                    </div>
                                    <div style={{ width: "25%", height: 250}}>
                                        <img src="../../../../../images/wuli.png" onClick={this.display_wuli} style={{border: "2px solid #ccc", borderRadius: "10px"}} />
                                        <div style={{display: this.state.display_wuli, position: "absolute", left: "62%", marginTop: 10}}>
                                        <div style={{display: "flex"}}>
                                            <Upload {...this.uploadText} >
                                                <Button type="primary" style={{marginLeft: "3%"}}>
                                                    导入试卷
                                                </Button>
                                            </Upload>
                                            <Button type="primary" style={{marginLeft: "3%"}}>划题标注</Button>
                                            <Button type="primary" style={{marginLeft: "3%"}}>查看试卷</Button>
                                            <Button type="primary" style={{marginLeft: "3%"}}>删除试卷</Button>
                                        </div>
                                        </div>
                                    </div>
                                    <div style={{ width: "25%", height: 250}}>
                                        <img src="../../../../../images/huaxue.png" onClick={this.display_huaxue} style={{border: "2px solid #ccc", borderRadius: "10px"}} />
                                        <div style={{display: this.state.display_huaxue, position: "absolute", left: "2%", marginTop: 10}}>
                                        <div style={{display: "flex"}}>
                                            <Upload {...this.uploadText} >
                                                <Button type="primary" style={{marginLeft: "3%"}}>
                                                    导入试卷
                                                </Button>
                                            </Upload>
                                            <Button type="primary" style={{marginLeft: "3%"}}>划题标注</Button>
                                            <Button type="primary" style={{marginLeft: "3%"}}>查看试卷</Button>
                                            <Button type="primary" style={{marginLeft: "3%"}}>删除试卷</Button>
                                        </div>
                                        </div>
                                    </div>
                                    <div style={{ width: "25%", height: 250}}>
                                        <img src="../../../../../images/shengwu.png" onClick={this.display_shengwu} style={{border: "2px solid #ccc", borderRadius: "10px"}} />
                                        <div style={{display: this.state.display_shengwu, position: "absolute", left: "22%", marginTop: 10}}>
                                        <div style={{display: "flex"}}>
                                            <Upload {...this.uploadText} >
                                                <Button type="primary" style={{marginLeft: "3%"}}>
                                                    导入试卷
                                                </Button>
                                            </Upload>
                                            <Button type="primary" style={{marginLeft: "3%"}}>划题标注</Button>
                                            <Button type="primary" style={{marginLeft: "3%"}}>查看试卷</Button>
                                            <Button type="primary" style={{marginLeft: "3%"}}>删除试卷</Button>
                                        </div>
                                        </div>
                                    </div>
                                    <div style={{ width: "25%", height: 250}}>
                                        <img src="../../../../../images/zhengzhi.png" onClick={this.display_zhengzhi} style={{border: "2px solid #ccc", borderRadius: "10px"}} />
                                        <div style={{display: this.state.display_zhengzhi, position: "absolute", left: "42%", marginTop: 10}}>
                                        <div style={{display: "flex"}}>
                                            <Upload {...this.uploadText} >
                                                <Button type="primary" style={{marginLeft: "3%"}}>
                                                    导入试卷
                                                </Button>
                                            </Upload>
                                            <Button type="primary" style={{marginLeft: "3%"}}>划题标注</Button>
                                            <Button type="primary" style={{marginLeft: "3%"}}>查看试卷</Button>
                                            <Button type="primary" style={{marginLeft: "3%"}}>删除试卷</Button>
                                        </div>
                                        </div>
                                    </div>
                                    <div style={{ width: "25%", height: 250}}>
                                        <img src="../../../../../images/dili.png" onClick={this.display_dili} style={{border: "2px solid #ccc", borderRadius: "10px"}} />
                                        <div style={{display: this.state.display_dili, position: "absolute", left: "62%", marginTop: 10}}>
                                        <div style={{display: "flex"}}>
                                            <Upload {...this.uploadText} >
                                                <Button type="primary" style={{marginLeft: "3%"}}>
                                                    导入试卷
                                                </Button>
                                            </Upload>
                                            <Button type="primary" style={{marginLeft: "3%"}}>划题标注</Button>
                                            <Button type="primary" style={{marginLeft: "3%"}}>查看试卷</Button>
                                            <Button type="primary" style={{marginLeft: "3%"}}>删除试卷</Button>
                                        </div>
                                        </div>
                                    </div> 
                                </div> */}
                            </TabPane>
                            <TabPane tab="成绩录入" key="3">
                                <div style={{padding: '30px 17.5%' ,width:'100%', display:'flex',flexWrap: 'wrap',justifyContent:'space-between'}}>
                                   { 
                                    this.state.c_subjectList.map(item =>{
                                        return(
                                            <div key={item.se_id} style={{width:'24%', display:'flex',justifyContent:'center',alignItems:'center', flexDirection:'column'}}>
                                                <img src={item.img}  alt={item.course_name} style={{width:'170px',height:'170px', border:'2px solid rgb(204, 204, 204)', borderRadius:'5px'}}/>
                                                <div>{item.course_name}</div>
                                                <div style={{margin:'10px 0', marginBottom:'20px'}}>
                                                    <Button onClick={()=>{this.setState({hVisible: true, h_se_id: item.se_id})}} type='primary' style={{marginRight:'10px'}}>导入成绩</Button>
                                                    <Button onClick={()=>{this.setState({h_edit_visible: true, h_se_id: item.se_id})}}  type='primary'>编辑成绩</Button>
                                                </div>
                                            </div>
                                         )
                                     })
                                     }
                                </div>
                                {/* 导入成绩弹出模态框 */}
                                {
                                    <Modal
                                    title="请选择文件"
                                    visible={this.state.hVisible}
                                    onOk={this.h_handleOk}
                                    onCancel={()=>{this.setState({hVisible: false})}}
                                    >
                                         <Upload {...h_upload} fileList={this.state.fileList}>
                                            <Button>
                                            <Icon type="upload" /> 点击上传
                                            </Button>
                                        </Upload>
                                    </Modal>
                                }
                                {/* 编辑成绩弹出模态框 */}
                                {
                                    <Modal
                                    title="编辑成绩"
                                    visible={this.state.h_edit_visible}
                                    onOk={this.h_edit_handleOk}
                                    width={820}
                                    onCancel={()=>{this.setState({h_edit_visible: false})}}
                                    >
                                        <div style={{display:'flex', justifyContent:'center', alignItems: 'center', width: '100%', flexDirection: 'column'}}>
                                            <Search
                                                placeholder="input search text"
                                                onSearch={value => 
                                                    searchStudent(value, this.state.h_se_id)
                                                    .then(res => {
                                                        console.log(res.body)
                                                        this.setState({h_student: res.body})
                                                    })
                                                }
                                                style={{ width: 300 }}
                                            />
                                        </div>
                                        <div>
                                            <div>基础信息</div>
                                            <div>姓名: {this.state.h_student.student_name}</div>
                                            <div>学校: {this.state.h_student.school_name}    <span>班级: {this.state.h_student.class_name}</span></div>
                                        </div>
                                        <div>
                                            {console.log(this.state)}
                                        <div>成绩信息</div>
                                            <div>科目: {this.state.h_student.course_name}    <span>得分:{this.state.h_student.ess_score}</span></div>
                                           {/* {this.state.h_student.q_list.map(item => {
                                               return(
                                                   <Form.Item label={item.school_name}></Form.Item>
                                               )
                                           })} */}
                                        </div>
                                    </Modal>
                                 }
                            </TabPane>
                        </Tabs>
                        </div>
                    </div>
                </Content>
            </Layout>
        )
    }
}

export default DataCollection