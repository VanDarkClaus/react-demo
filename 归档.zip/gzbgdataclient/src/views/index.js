// import Loadable from '../utils/Loadable'
import {lazy} from 'react'

const NotFound = lazy(()=>import('./NotFound'))
const Login = lazy(()=>import('./Login'))

//my
const ManageBackstage = lazy(()=>import('./My/ManageBackstage'))
const PersonalCenter = lazy(()=>import('./My/PersonalCenter'))

//my->managebackstage
const LoginLog = lazy(()=>import('./My/ManageBackstage/LoginLog'))
const OperationLog = lazy(()=>import('./My/ManageBackstage/OperationLog'))
const RoleManage = lazy(()=>import('./My/ManageBackstage/RoleManage'))
const UserManage = lazy(()=>import('./My/ManageBackstage/UserManage'))

//四个大路由组件
const DataEntry = lazy(()=>import('./DataEntry'))
const Homework = lazy(()=>import('./Homework'))
const Resource = lazy(()=>import('./Resource'))
const TestCenter = lazy(()=>import('./TestCenter'))

//资源中心的组件
const MyGroup = lazy(() => import('./Resource/MyGroup'))
const QualityGroup = lazy(() => import('./Resource/QualityGroup'))
const SchoolGroup = lazy(() => import('./Resource/SchoolGroup'))
const SpecialGroup = lazy(() => import('./Resource/SpecialGroup'))
const StudyGroup = lazy(() => import('./Resource/StudyGroup'))
const TopGroup = lazy(() => import('./Resource/TopGroup'))

//考试中心数据
const CloundScore = lazy(() => import('./TestCenter/CloudScore'))
const StudyBigData = lazy(() => import('./TestCenter/StudyBigData'))

//数据采集
const BasicData = lazy(() => import('./DataEntry/BasicData'))
const ExaminationProcess = lazy(() => import('./DataEntry/ExaminationProcess'))
const ThirdData = lazy(() => import('./DataEntry/ThirdData'))

//examinationProcess下的路由
const CreateTest = lazy(() => import('./DataEntry/ExaminationProcess/CreateTest'))
const DataCollection = lazy(() => import('./DataEntry/ExaminationProcess/DataCollection'))
const PublishReports = lazy(() => import('./DataEntry/ExaminationProcess/PublishReports'))

//考试中心下的学情大数据下的四个报告
const ClassReport = lazy(() => import('views/TestCenter/StudyBigData/ClassReport'))
const OverallReport = lazy(() => import('views/TestCenter/StudyBigData/OverallReport'))
const PersonalReport = lazy(() => import('views/TestCenter/StudyBigData/PersonalReport'))
const SchoolReport = lazy(() => import('views/TestCenter/StudyBigData/SchoolReport'))

export {
    NotFound,
    Login,

    ManageBackstage,
    PersonalCenter,

    LoginLog,
    OperationLog,
    RoleManage,
    UserManage,

    DataEntry,
    Homework,
    Resource,
    TestCenter,

    MyGroup,
    QualityGroup,
    SchoolGroup,
    SpecialGroup,
    StudyGroup,
    TopGroup,

    CloundScore,
    StudyBigData,

    BasicData,
    ExaminationProcess,
    ThirdData,

    CreateTest,
    DataCollection,
    PublishReports,

    ClassReport,
    OverallReport,
    PersonalReport,
    SchoolReport
}