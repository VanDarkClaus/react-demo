import React, { Component } from 'react'
import {Route, Redirect, Switch } from 'react-router-dom'

import { adminRoutes,myRoutes } from './routes'
import { Frame } from './components'
import { connect } from 'react-redux'

const mapStateToProps = state => {
    return ({
        state
    })
}

@connect(mapStateToProps)
class App extends Component {
    render() {
        return (
                this.props.state.loginReducer.loginValues.access_token?
                <Frame>
                        <Switch>
                            {
                                adminRoutes.map(item => {
                                    return(
                                        <Route
                                            path = {item.path}
                                            key = {item.path}
                                            component = {item.component}
                                            exact = {item.exact}
                                        />
                                    )
                                })
                            }
                            {
                                myRoutes.map(item => {
                                    return(
                                        <Route
                                            path = {item.path}
                                            key = {item.path}
                                            component = {item.component}
                                            exact = {item.exact}
                                        />
                                    )
                                })
                            }
                            <Redirect from = '/admin' to = '/admin/resource' exact/>
                            <Redirect to = '/404'/>
                        </Switch>
                </Frame>
                :
                <Redirect to = '/login'/>
        )
    }
}

export default App