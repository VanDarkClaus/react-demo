import React, { Component } from 'react'
import { Layout, Menu } from 'antd'
import { resourceRoutes, testRoutes, dataEntryRoutes, homeworkRoutes, manageBackstageRoutes } from '../../routes'
import { withRouter } from 'react-router-dom'
import { connect } from 'react-redux'
import './sonframe.less'



const { Header, Content } = Layout
const mapStateToProps = state => ({
    state
})

@withRouter
@connect(mapStateToProps)
class index extends Component {
    constructor() {
        super()
        this.state = {
            route: resourceRoutes
        }
    }
    static getDerivedStateFromProps(props, state) {
        let pathnameArr = props.history.location.pathname.split('/')
        let pathname = '/'+pathnameArr[1]+'/'+pathnameArr[2] + '/'+pathnameArr[3] || '' 
        var route
        switch(pathnameArr[2]){
            case 'resource': route = resourceRoutes; break;
            case 'testcenter': route = testRoutes; break;
            case 'dataentry': route = dataEntryRoutes; break;
            case 'homwork': route = homeworkRoutes; break;
            case 'managebackstage': route = manageBackstageRoutes; break;
            default: route = resourceRoutes;
        }
        return{
            pathname,
            route
        }
    }
    //编辑导航跳转功能
    menHandle = item => {
        //判断是否是云阅卷
        if(item.key === '/admin/testcenter/cloundscore'){
            window.location.href='http://yuejuan.mymuxue.com/qiq/navigator/ExamMark_UE_OR/ExamMark_UE_OR.html'
        }else{
            this.props.history.push(item.key)
        }
    }
    render() {
        return (
                <Layout className="layout">
                    <Header style={{display: 'flex', padding: '0'}}>
                        <Menu
                            theme="dark"
                            mode="horizontal"
                            selectedKeys={[this.state.pathname]}
                            style={{ lineHeight: '64px',marginLeft:'24.4%' }}
                            onClick={this.menHandle}
                        >
                            {   
                                this.state.route.map(item => {
                                    return <Menu.Item  key={item.path} path={item.path}>
                                                {item.title}
                                            </Menu.Item>
                                })
                            }
                        </Menu>
                    </Header>
                    <Content style={{width:'100%', background:'#f3faff'}}>
                        {this.props.children}
                    </Content>
                </Layout>
        )
    }
}

export default index
