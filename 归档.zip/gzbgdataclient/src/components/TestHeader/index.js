import React, { Component } from 'react'

import './testheader.less'

export default class index extends Component {
    render() {
        return (
            <div className='muxue-testheader'>
                <div className='muxue-testheader-top'>
                    <div>
                        <img src='/images/createTest.png' alt='创建考试'/>
                        <div>创建考试</div>
                    </div>
                    <div>
                        <img  src='/images/datasync.png' alt='数据采集'/> 
                        <div>数据采集</div>
                    </div>
                    <div>
                        <img  src='/images/publishreports.png' alt='发布报告'/> 
                        <div>发布报告</div>
                    </div>
                </div>
                <img src={this.props.img} alt='考试流程two'/>
            </div>
        )
    }
}
