import React, { Component } from 'react'
import { Layout, Menu, Dropdown, Avatar,Icon } from 'antd'
import { adminRoutes, myRoutes } from '../../routes'
import { withRouter } from 'react-router-dom'
import { connect } from 'react-redux'
import { loginoutDispatch } from '../../actions/loginActions'


const { Header, Content } = Layout
const mapStateToProps = state => ({
    state
})

@withRouter
@connect(mapStateToProps, {loginoutDispatch})
class index extends Component {
    constructor(){
        super()
        this.state={}
    }
    menu = () =>{
        return(
            <Menu onClick={this.menHandle}>
                <Menu.Item key="/admin/personalcenter">个人中心</Menu.Item>
                <Menu.Item key="/admin/managebackstage">管理后台</Menu.Item>
                <Menu.Item key="/admin">回到首页</Menu.Item>
                <Menu.Item key="loginout">退出登录</Menu.Item>
            </Menu>
        )
    }
    static getDerivedStateFromProps (props, state){
        let pathnameArr = props.history.location.pathname.split('/')
        let pathname = '/'+pathnameArr[1]+'/'+pathnameArr[2] || ''  
        let route = adminRoutes
        if(pathnameArr[2] === 'personalcenter' || pathnameArr[2] === 'managebackstage'){
            route = myRoutes
        }
        return{
            pathname,
            route
        }
    }
    //编辑导航跳转功能
    menHandle = ({key}) => {
        if(key === 'loginout'){
            this.props.loginoutDispatch()
        } else {
            this.props.history.push(key)
        }
    }
    render() {
        return (
                <Layout className="layout">
                    
                    <Header style={{display: 'flex',width:'100%', background: '#fff', height: '120px', padding: '50px 0 0', paddingLeft: '9.4%', paddingRight:'9.4%',boxSizing: 'border-box', justifyContent: 'space-between'}}>
                        <div style={{display: 'flex'}}>
                            <img src='/images/WechatIMG4.png' alt='慕学大数据logo' style={{marginRight: '1%',height: '61px',width: 'auto', marginLeft: '-5px'}}/>
                            <Menu
                                theme="#fff"
                                mode="horizontal"
                                selectedKeys={[this.state.pathname]}
                                style={{ lineHeight: '32px', border:'none' }}
                                onClick={this.menHandle}
                            >
                            {
                                this.state.route.map(item => {
                                    return <Menu.Item key={item.path} path={item.path}>
                                                    <div style={{fontSize:'16px'}}>{item.title}</div>
                                                    <div style={{fontSize:'12px'}}>{item.Etitle}</div>
                                            </Menu.Item>
                                })
                            }
                            </Menu>
                        </div>
                        <Dropdown overlay={this.menu} trigger={['click','hover']}>
                            <div>
                                <Avatar style={{ backgroundColor: '#87d068' }} icon="user" trigger={['hover','click']}/>
                                <span>欢迎你:{this.props.state.loginReducer.loginValues.user_info.nick}</span>
                                <Icon type="down" />
                            </div>
                        </Dropdown>
                    </Header>
                    <Content style={{width: '100%', backgroundColor: '#f3faff'}}>
                        {this.props.children}
                    </Content>
                </Layout>
        )
    }
}

export default index
