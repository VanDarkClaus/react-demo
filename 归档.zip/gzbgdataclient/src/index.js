import React,{Suspense} from 'react'
import { hydrate } from 'react-dom'
import App from './App'
//国际化
import {ConfigProvider, Spin} from 'antd'
import zhCN from 'antd/es/locale/zh_CN';
//引入store,并将参数挂载到全局
import store from './store'
import { Provider } from 'react-redux'

import {BrowserRouter as Router, Route, Switch, Redirect} from 'react-router-dom'
import { mainRoutes } from './routes'

hydrate(
<Suspense fallback={<Spin size="large"/>}>
    <Provider store={store}>
        <ConfigProvider locale={zhCN}>
            <Router>
                <Switch>
                    <Route path='/admin' component={App}/>  
                    {
                        mainRoutes.map(item=> {
                            return(
                                <Route
                                    component = {item.component}
                                    key = {item.path}
                                    path = {item.path}
                                    exact = {item.exact}
                                />
                            )
                        })    
                    }
                    <Redirect from = '/' to = '/admin' exact/>
                    <Redirect to = '/404'/>
                </Switch>
            </Router>
        </ConfigProvider>
    </Provider>
    </Suspense>
    ,
    document.getElementById("root")
)