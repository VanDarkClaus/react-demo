export const isShowByRoot = (componentName) =>{
    if(JSON.parse(sessionStorage.getItem('token')).permission_list.some(item => item === componentName)){
        return {
            display: 'none'
        }
    }
}
export const addNewRoleShow = id => {
    if (!(id === 13 || id === 16 || id === 17 || id === 18 || id === 19 || id === 20 || id === 21)){
        return {
            display: 'none'
        }
    }else {
        return {
            display: 'block'
        }
    }
}
