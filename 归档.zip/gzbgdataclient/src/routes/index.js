import {
    Login,
    NotFound,

    ManageBackstage,
    PersonalCenter,

    LoginLog,
    OperationLog,
    RoleManage,
    UserManage,

    DataEntry,
    Homework,
    Resource,
    TestCenter,

    MyGroup,
    QualityGroup,
    SchoolGroup,
    SpecialGroup,
    StudyGroup,
    TopGroup,
    
    CloundScore,
    StudyBigData,

    BasicData,
    ExaminationProcess,
    ThirdData,

    CreateTest,
    DataCollection,
    PublishReports,

    ClassReport,
    OverallReport,
    PersonalReport,
    SchoolReport
}   from '../views'

//该路由不需要权限
export  const mainRoutes = [
    {
        path: '/login',
        component: Login
    }, {
        path: '/404',
        component: NotFound
    }
]

//该路由为登录后的四个大路由
export const adminRoutes = [
    {
        path: '/admin/resource',
        component: Resource,
        title: '资源中心',
        Etitle: 'Resource'
    }, {
        path: '/admin/testcenter',
        component: TestCenter,
        title: '考试中心',
        Etitle: 'Text center'
    }, {
        path: '/admin/homework',
        component: Homework,
        title: '作业中心',
        Etitle: 'Homework'
    }, {
        path: '/admin/dataentry',
        component: DataEntry,
        title: '数据采集',
        Etitle: 'Data entry'
    }
]

//myroutes

export const myRoutes = [
    {
        path: '/admin/personalcenter',
        component: PersonalCenter,
        title: '个人中心',
        Etitle: 'Personal Center'
    }, {
        path: '/admin/managebackstage',
        component: ManageBackstage,
        title: '管理后台',
        Etitle: 'Manage Backstage'
    }
]

//my-managebackstage-routes
export const manageBackstageRoutes = [
    {
        path: '/admin/managebackstage/rolemanage',
        component: RoleManage,
        title: '角色管理'
    },{
        path: '/admin/managebackstage/usermanage',
        component: UserManage,
        title: '用户管理'
    }, {
        path: '/admin/managebackstage/operationlog',
        component: OperationLog,
        title: '操作日志'
    }, {
        path: '/admin/managebackstage/loginlog',
        component: LoginLog,
        title: '登录日志'
    }
]


//资源中心下的子路由
export const resourceRoutes = [
    {
        path: '/admin/resource/qualitygroup',
        component: QualityGroup,
        title: '优质组卷'
    }, 

    // 暂时隐藏'学情组卷'、'专项组卷'、'精品组卷'
    // {
    //     path: '/admin/resource/studygroup',
    //     component: StudyGroup,
    //     title: '学情组卷'
    // }, {
    //     path: '/admin/resource/specialgroup',
    //     component: SpecialGroup,
    //     title: '专项组卷'
    // }, {
    //     path: '/admin/resource/topgroup',
    //     component: TopGroup,
    //     title: '精品组卷'
    // }, 
    {
        path: '/admin/resource/schoolgroup',
        component: SchoolGroup,
        title: '校本组卷'
    }, {
        path: '/admin/resource/mygroup',
        component: MyGroup,
        title: '我的组卷'
    }
]

export const testRoutes = [
    {
        path: '/admin/testcenter/studybigdata',
        component: StudyBigData,
        title: '学情大数据'
    }, {
        path: '/admin/testcenter/cloundscore',
        component: CloundScore,
        title: '云阅卷'
    }
]

export const dataEntryRoutes = [
    {
        path: '/admin/dataentry/examinationprocess',
        component: ExaminationProcess,
        title: '考试流程'
    },{
        path: '/admin/dataentry/basicdata',
        component: BasicData,
        title: '基础数据管理'
    },  {
        path: '/admin/dataentry/thirddata',
        component: ThirdData,
        title: '第三方数据'
    }
]

export const homeworkRoutes = [
    {

    }
]

//考试流程下的路由
export const examinationRoutes = [
    {
        path: '/admin/dataentry/examinationprocess/createtest',
        component: CreateTest
    }, {
        path: '/admin/dataentry/examinationprocess/datacollection',
        component: DataCollection
    }, {
        path: '/admin/dataentry/examinationprocess/publishreports',
        component: PublishReports
    }
]

//考试中心下的的报告路由
export const reportRoutes = [
    {
        path: '/admin/testcenter/studybigdata/classreport',
        component: ClassReport
    }, {
        path: '/admin/testcenter/studybigdata/overallreport',
        component:OverallReport
    }, {
        path: '/admin/testcenter/studybigdata/personalreport',
        component: PersonalReport
    }, {
        path: '/admin/testcenter/studybigdata/schoolreport',
        component: SchoolReport
    }
]